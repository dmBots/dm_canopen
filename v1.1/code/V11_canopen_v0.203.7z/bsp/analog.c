#include "bsp.h"
#include "stdio.h"

void ADC12_Init(void)
{
  /** ADC1 GPIO Configuration ***
  PA0   ------> ADC1_IN0  ------> Iu
  PA1   ------> ADC1_IN1  ------> VBAT
	PA2   ------> ADC1_IN2  ------> HS1
	
	*** ADC2 GPIO Configuration ***
  PA4   ------> ADC12_IN4  ------> Iv
	PA5  	------> ADC12_IN5  ------> MOSTemp
	PB1  	------> ADC123_IN9 ------> HS2
	
	*** ADC3 GPIO Configuration ***
  PA6   ------> ADC123_IN6 ------> Iw
	PA7  	------> ADC123_IN7 ------> RTemp
	PB0  	------> ADC3_IN11  ------> Vref(~1.10V)
	
	tconv = td+sigma(tconv)+ted
	td = 1*pclk4 + 4*adcclk
	tconv = (13+sstr)*n
	ted = 1*pclk4 + 3*adcclk
	so if sample 5 chanel per uinit,it will use 3.46us
	   if sample 4 chanel per uinit,it will use 2.80us
		 if sample 3 chanel per uinit,it will use 2.14us
  */
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	CM_GPIO->PCRA0 = 1<<15;	//	Disable Digital function,ADC1_IN0
	CM_GPIO->PCRA1 = 1<<15;	//	Disable Digital function,ADC1_IN1
	CM_GPIO->PCRA2 = 1<<15;	//	Disable Digital function,ADC1_IN2
	CM_GPIO->PCRA4 = 1<<15;	//	Disable Digital function,ADC12_IN4
	CM_GPIO->PCRA5 = 1<<15;	//	Disable Digital function,ADC12_IN5
	CM_GPIO->PCRA6 = 1<<15;	//	Disable Digital function,ADC123_IN6
	CM_GPIO->PCRA7 = 1<<15;	//	Disable Digital function,ADC123_IN7
//	CM_GPIO->PCRB0 = 1<<15;	//	Disable Digital function,ADC123_IN8
	CM_GPIO->PCRB1 = 1<<15;	//	Disable Digital function,ADC123_IN9
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock

	CM_PWC->FPRC |= 0xA502;	//	ENABLE_CLOCK1_REG_WRITE
  CM_CMU->PERICKSEL = 0;// AD/TRNG clock source is pclk2(50MHz,convert)/pclk4(100MHz,logic).
	CM_PWC->PWRC4=0x80;//ADBUFE[7]=1,Enable reference voltage sample function,about 1.10V
	CM_ADC3->EXCHSELR = 1;//EXCHSEL=1,Choose inner analog channel
	CM_PWC->FPRC 	= (0xA500 | (CM_PWC->FPRC & 0xFFFD));	//	DISABLE_CLOCK1_REG_WRITE
	
	/* ADC1 and ADC2 use the same configuration in sync mode. */		
	CM_PWC->FCG3	&= (~(1<<2|1<<1|1<<0));	//	Enable ADC1,2,3 Clock
	
	CM_ADC1->SYNCCR = 0;	// Disable synchronous mode first
	/*
		DFMT[7]=0,Right Alignment
		CLREN[6]=0,Diable Auot Clear
		ACCSEL[5:4]=0,12bit Resolution
		MS[2:0]=0,Sequence A works single sample
	*/
	CM_ADC1->STR 		= 0;	// Stop ADC conversion.
	CM_ADC1->CR0 = 0<<7|0<<6|0<<4|0;
	CM_ADC1->CHMUXR0	=	0x3210;	//	CH0:ADC1_IN0
															//	CH1:ADC1_IN1
															//	CH2:ADC1_IN2
	CM_ADC1->CHSELRA 	= (1<<0|1<<1|1<<2);	//	ADC1_CH0,ADC1_CH1,ADC1_CH2
	CM_ADC1->SSTR0		=	20;	// 20 ADCCLK for sampling time
  CM_ADC1->SSTR1		=	20;	// 20 ADCCLK for sampling time
	CM_ADC1->SSTR2		=	20;	// 20 ADCCLK for sampling time

	/*
		DFMT[7]=0,Right Alignment
		CLREN[6]=0,Diable Auot Clear
		ACCSEL[5:4]=0,12bit Resolution
		MS[2:0]=0,Sequence A works single sample
	*/
	CM_ADC2->STR 			= 0;	// Stop ADC conversion.
	CM_ADC2->CR0 = 0<<7|0<<6|0<<4|0;
	CM_ADC2->CHMUXR0	=	0x3510;	//	CH0:ADC12_IN4
															//	CH1:ADC12_IN5
															//	CH2:ADC123_IN9
	CM_ADC2->CHSELRA 	= (1<<0|1<<1|1<<2);	//	ADC2_CH0,ADC2_CH1,ADC2_CH2
	CM_ADC2->SSTR0		=	20;	// 20 ADCCLK for sampling time
	CM_ADC2->SSTR1		=	20;	// 20 ADCCLK for sampling time
	CM_ADC2->SSTR2		=	20;	// 20 ADCCLK for sampling time

	/*
		DFMT[7]=0,Right Alignment
		CLREN[6]=0,Diable Auot Clear
		ACCSEL[5:4]=0,12bit Resolution
		MS[2:0]=0,Sequence A works single sample
	*/
	CM_ADC3->STR 			= 0;	// Stop ADC conversion
	CM_ADC3->CR0 = 0<<7|0<<6|0<<4|0;
	CM_ADC3->CHMUXR0	=	0x3B76;	//	CH0:ADC123_IN6
															//	CH1:ADC123_IN7
															//	CH2:Inner analog channel
	CM_ADC3->CHSELRA 	= (1<<0|1<<1|1<<2);	//	ADC2_CH0,ADC2_CH1,ADC2_CH2
	CM_ADC3->SSTR0		=	20;	// 20 ADCCLK for sampling time
	CM_ADC3->SSTR1		=	20;	// 20 ADCCLK for sampling time
	CM_ADC3->SSTR2		=	20;	// 20 ADCCLK for sampling time
}

void ADC_CAL(float *u)
{
volatile uint16_t i,i_u,i_v,i_w,v_b,vt_mos,vt_coil;
	float sum_u=0.0f,sum_v=0.0f,sum_w=0.0f,sum_b=0.0f;
	
    for(i=0;i<1000;i++)
    {
			CM_ADC1->STR = 1;	//	ADC1 start of conversion
			CM_ADC2->STR = 1;	//	ADC2 start of conversion
			CM_ADC3->STR = 1;	//	ADC3 start of conversion
			while((CM_ADC1->ISR&0x01)==0)
					;// wait until ADC1 conversions complete
			i_u 	= CM_ADC1->DR0;
			v_b 	= CM_ADC1->DR1;
			while((CM_ADC2->ISR&0x01)==0)
					;// wait until ADC1 conversions complete
			i_v 	= CM_ADC2->DR0;
			vt_mos 	= CM_ADC2->DR1;
			while((CM_ADC3->ISR&0x01)==0)
					;// wait until ADC1 conversions complete
			i_w 	= CM_ADC3->DR0;
			vt_coil 	= CM_ADC3->DR1;

			sum_u += (float)i_u;
			sum_v += (float)i_v;
			sum_w += (float)i_w;
			sum_b += (float)v_b;
			
			CM_ADC1->ISCLRR = 0x01;
			CM_ADC2->ISCLRR = 0x01;
    }
    *u 			= sum_u/1000.0f;
    *(u+1) 	= sum_v/1000.0f;
    *(u+2) 	= sum_w/1000.0f;
		*(u+3) 	= sum_b/1000.0f;
}

uint8_t MOS_Check1(void)
{
	uint16_t i_u,i_v,i_w;
	uint8_t istate=0;
	/******* TIM6 GPIO Configuration    
    PB13     ------> TIM4_1_OUL
    PB14     ------> TIM4_1_OVL
    PB15     ------> TIM4_1_OWL
    PA8      ------> TIM4_1_OUH,FUNC2
    PA9      ------> TIM4_1_OVH
    PA10     ------> TIM4_1_OWH
   ********************************/
	//Port config
{
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	/* 
		DDIS[15]=0,Enable Digital function
		DRV[4]=1,Mid level drive strength
		POUTE[1]=1,Enable output
	*/
	CM_GPIO->PCRB13 = 0<<15|1<<4|1<<4;	//	Enable Digital function
	CM_GPIO->PCRB14 = 0<<15|1<<4|1<<4;	//	Enable Digital function
	CM_GPIO->PCRB15 = 0<<15|1<<4|1<<4;	//	Enable Digital function
	CM_GPIO->PCRA8 	= 0<<15|1<<4|1<<4;	//	Enable Digital function
	CM_GPIO->PCRA9 	= 0<<15|1<<4|1<<4;	//	Enable Digital function
	CM_GPIO->PCRA10 = 0<<15|1<<4|1<<4;	//	Enable Digital function
	
	CM_GPIO->PORRB				 |= (1<<13|1<<14|1<<15);	//  PB13,14,15 	= 0
	CM_GPIO->PORRA				 |= (1<<8 |1<<9 |1<<10);	//  PA 8, 9,10	= 0
	
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock
	Delay_us(20);
}
	/*UL MOS TEST */
{
	CM_GPIO->POSRA |= 0x0100;//SET PA8,OPEN U_H
	Delay_us(10);
	CM_ADC1->STR = 1;	//	ADC1 start of conversion
	CM_ADC2->STR = 1;	//	ADC2 start of conversion
	CM_ADC3->STR = 1;	//	ADC3 start of conversion
	while((CM_ADC1->ISR&0x01)==0)
		;// wait until ADC1 conversions complete
	CM_ADC1->ISCLRR = 0x01;
	CM_ADC2->ISCLRR = 0x01;
	CM_ADC3->ISCLRR = 0x01;
	 i_u = CM_ADC1->DR0;
	if(i_u<1000||i_u>3000) 
		istate = 0x01;//u phase low side mos break
	CM_GPIO->PORRA |= 0x0100;//CLOSE U_H
	Delay_us(20);
}	
	/*VL MOS TEST */
{
	CM_GPIO->POSRA |= 0x0200;//SET PA9,OPEN V_H
	Delay_us(10);
	CM_ADC1->STR = 1;	//	ADC1 start of conversion
	CM_ADC2->STR = 1;	//	ADC2 start of conversion
	CM_ADC3->STR = 1;	//	ADC3 start of conversion
	while((CM_ADC2->ISR&0x01)==0)
		;//	wait until ADC2 conversions complete
	CM_ADC1->ISCLRR = 0x01;
	CM_ADC2->ISCLRR = 0x01;
	CM_ADC3->ISCLRR = 0x01;
	 i_v = CM_ADC2->DR0;
	if(i_v<1000||i_v>3000) 
		istate |= 0x04;//v phase low side mos break
	CM_GPIO->PORRA |= 0x0200;//CLOSE V_H
	Delay_us(20);
}	
	/*WL MOS TEST */
{
	CM_GPIO->POSRA |= 0x0400;//SET PA10,OPEN W_H
	Delay_us(10);
	CM_ADC1->STR = 1;	//	ADC1 start of conversion
	CM_ADC2->STR = 1;	//	ADC2 start of conversion
	CM_ADC3->STR = 1;	//	ADC3 start of conversion
	while((CM_ADC3->ISR&0x01)==0)
		;// wait until ADC1 conversions complete
	CM_ADC1->ISCLRR = 0x01;
	CM_ADC2->ISCLRR = 0x01;
	CM_ADC3->ISCLRR = 0x01;
	 i_w = CM_ADC3->DR0;
	if(i_w<1000||i_w>3000) 
		istate |= 0x10;//w phase low side mos break
	CM_GPIO->PORRA |= 0x0400;//CLOSE W_H
  Delay_us(20);
}	
	/*UH MOS TEST */
{
	CM_GPIO->POSRB |= 0x2000;//SET PB13,OPEN U_L
	Delay_us(10);
	CM_ADC1->STR = 1;	//	ADC1 start of conversion
	CM_ADC2->STR = 1;	//	ADC2 start of conversion
	CM_ADC3->STR = 1;	//	ADC3 start of conversion
	while((CM_ADC1->ISR&0x01)==0)
		;// wait until ADC1 conversions complete
	CM_ADC1->ISCLRR = 0x01;
	CM_ADC2->ISCLRR = 0x01;
	CM_ADC3->ISCLRR = 0x01;
	 i_u = CM_ADC1->DR0;
	if(i_u<1000||i_u>3000) 
		istate |= 0x02;//u phase high side mos break
	CM_GPIO->PORRB |= 0x2000;//CLOSE U_L
	Delay_us(20);
}	
		/*VH MOS TEST */
{
	CM_GPIO->POSRB = 0x4000;//SET PB14,OPEN V_L
	Delay_us(10);
	CM_ADC1->STR = 1;	//	ADC1 start of conversion
	CM_ADC2->STR = 1;	//	ADC2 start of conversion
	CM_ADC3->STR = 1;	//	ADC3 start of conversion
	while((CM_ADC2->ISR&0x01)==0)
		;// wait until ADC1 conversions complete
	CM_ADC1->ISCLRR = 0x01;
	CM_ADC2->ISCLRR = 0x01;
	CM_ADC3->ISCLRR = 0x01;
	 i_v = CM_ADC2->DR0;
	if(i_v<1000||i_v>3000) 
		istate |= 0x08;//v phase high side mos break
	CM_GPIO->PORRB |= 0x4000;//CLOSE V_L
	Delay_us(20);
}	
		/*WH MOS TEST */
{
	CM_GPIO->POSRB |= 0x8000;//SET PB15,OPEN W_L
	Delay_us(10);
	CM_ADC1->STR = 1;	//	ADC1 start of conversion
	CM_ADC2->STR = 1;	//	ADC2 start of conversion
	CM_ADC3->STR = 1;	//	ADC3 start of conversion
	while((CM_ADC3->ISR&0x01)==0)
		;// wait until ADC1 conversions complete
	CM_ADC1->ISCLRR = 0x01;
	CM_ADC2->ISCLRR = 0x01;
	CM_ADC3->ISCLRR = 0x01;
	 i_w = CM_ADC3->DR0;
	if(i_w<1000||i_w>3000) 
		istate |= 0x20;//w phase high side mos break
	CM_GPIO->PORRB |= 0x8000;//CLOSE W_L
	Delay_us(20);
}	
	return istate;//PASS
}

void mos_check(void)
{
	uint8_t mos_state;
	char str[]="W  | W  | V  | V  | U  | U ";
	mos_state=MOS_Check1();
 	if(mos_state)
	{
    USART1_Init(921600);
		str[0]=((mos_state&0x20)>>5)+0x30;
		str[5]=((mos_state&0x10)>>4)+0x30;
		str[10]=((mos_state&0x08)>>3)+0x30;
		str[15]=((mos_state&0x04)>>2)+0x30;
		str[20]=((mos_state&0x02)>>1)+0x30;
		str[25]=((mos_state&0x01)>>0)+0x30;
		while(1)
		{ 
			printf("MOSFET ERROR,  WH | WL | VH | VL | UH | UL\r\n");
			printf("               %s\r\n",str);
			printf("\r\n");
			LED_G_Tog();
			Delay_ms(500);
		}
	}
}

const float TempTable[256]={
 273.15000000f, 239.36434352f, 196.85433352f, 175.02163304f, 160.66659962f, 150.10888404f, 141.82422544f, 135.04185584f, 129.32075420f, 124.38623516f, 120.05625307f, 116.20428579f, 112.73903103f, 109.59256112f, 106.71304564f, 104.06008638f, 101.60161857f, 99.31178927f, 97.16946659f, 95.15716801f, 93.26027458f, 91.46644456f, 89.76516876f, 88.14742871f, 86.60543049f, 85.13239499f, 83.72239091f, 82.37020060f, 81.07121119f, 79.82132555f, 78.61688904f, 77.45462862f,
 76.33160210f, 75.24515543f, 74.19288663f, 73.17261523f, 72.18235602f, 71.22029673f, 70.28477862f, 69.37427983f, 68.48740081f, 67.62285170f, 66.77944124f, 65.95606706f, 65.15170711f, 64.36541209f, 63.59629877f, 62.84354402f, 62.10637954f, 61.38408707f, 60.67599420f, 59.98147055f, 59.29992434f, 58.63079934f, 57.97357204f, 57.32774917f, 56.69286540f, 56.06848126f, 55.45418128f, 54.84957224f, 54.25428161f, 53.66795613f, 53.09026046f, 52.52087601f, 51.95949983f,
 51.40584355f, 50.85963251f, 50.32060482f, 49.78851063f, 49.26311134f, 48.74417894f, 48.23149537f, 47.72485195f, 47.22404881f, 46.72889439f, 46.23920496f, 45.75480420f, 45.27552279f, 44.80119799f, 44.33167333f, 43.86679824f, 43.40642775f, 42.95042220f, 42.49864694f, 42.05097212f, 41.60727239f, 41.16742672f, 40.73131816f, 40.29883362f, 39.86986373f, 39.44430260f, 39.02204771f, 38.60299970f, 38.18706224f, 37.77414189f, 37.36414795f, 36.95699234f, 36.55258947f,
 36.15085616f, 35.75171145f, 35.35507659f, 34.96087486f, 34.56903154f, 34.17947377f, 33.79213048f, 33.40693233f, 33.02381159f, 32.64270210f, 32.26353918f, 31.88625956f, 31.51080134f, 31.13710387f, 30.76510777f, 30.39475479f, 30.02598781f, 29.65875075f, 29.29298855f, 28.92864710f, 28.56567319f, 28.20401446f, 27.84361939f, 27.48443721f, 27.12641786f, 26.76951199f, 26.41367088f, 26.05884641f, 25.70499104f, 25.35205775f, 25.00000000f, 24.64877172f, 24.29832724f,
 23.94862130f, 23.59960896f, 23.25124563f, 22.90348697f, 22.55628892f, 22.20960760f, 21.86339935f, 21.51762064f, 21.17222807f, 20.82717832f, 20.48242813f, 20.13793427f, 19.79365348f, 19.44954248f, 19.10555790f, 18.76165626f, 18.41779396f, 18.07392721f, 17.73001199f, 17.38600407f, 17.04185891f, 16.69753167f, 16.35297714f, 16.00814974f, 15.66300342f, 15.31749169f, 14.97156752f, 14.62518334f, 14.27829097f, 13.93084159f, 13.58278566f, 13.23407291f, 12.88465229f,
 12.53447187f, 12.18347884f, 11.83161941f, 11.47883877f, 11.12508103f, 10.77028914f, 10.41440484f, 10.05736856f, 9.69911937f, 9.33959489f, 8.97873118f, 8.61646271f, 8.25272221f, 7.88744059f, 7.52054685f, 7.15196794f, 6.78162867f, 6.40945155f, 6.03535670f, 5.65926169f, 5.28108135f, 4.90072768f, 4.51810964f, 4.13313296f, 3.74569995f, 3.35570932f, 2.96305591f, 2.56763047f, 2.16931942f, 1.76800453f, 1.36356266f, 0.95586541f, 0.54477878f,
 0.13016280f, -0.28812889f, -0.71024947f, -1.13635946f, -1.56662718f, -2.00122938f, -2.44035181f, -2.88418994f, -3.33294970f, -3.78684825f, -4.24611495f, -4.71099228f, -5.18173694f, -5.65862109f, -6.14193363f, -6.63198170f, -7.12909232f, -7.63361420f, -8.14591979f, -8.66640761f, -9.19550474f, -9.73366980f, -10.28139617f, -10.83921574f, -11.40770311f, -11.98748042f, -12.57922288f, -13.18366513f, -13.80160855f, -14.43392985f, -15.08159090f, -15.74565043f, -16.42727770f,
 -17.12776872f, -17.84856558f, -18.59127960f, -19.35771936f, -20.14992477f, -20.97020885f, -21.82120955f, -22.70595445f, -23.62794265f, -24.59124943f, -25.60066196f, -26.66185774f, -27.78164320f, -28.96827865f, -30.23193028f, -31.58531429f, -33.04464094f, -34.63104464f, -36.37283745f, -38.30923400f, -40.49688657f, -43.02225796f, -46.02755047f, -49.77340924f, -54.82811820f, -62.92764207f,
};
