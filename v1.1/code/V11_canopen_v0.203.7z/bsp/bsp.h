#ifndef __BSP_H
#define __BSP_H

/****
Version:V5.0
Create Time:2024/03/16
Author:Kelvin.Liu
Item:create for DM4310(F448)
2023/11/04: create for F448,combine classical can&FDCAN in a file
						modify TIM,from overflow trig SPI to underflow
						change delay timer from systick to tmr_A1
2024/01/17: modify crc32,from hardware to software
2024/01/29: V4,0,based on V3.1,use tri-ADCs to sample
2024/03/16: V4.1,based on V4.0,modify deadtime,frim 200ns to 400ns
2024/03/19: V5.0,based on V4.1,add CMP & DAC & EMB use for bkin
*/

#include "hc32f448.h"

extern __IO uint32_t uwTick;

/************** System config & Delay **************/
void SYS_Init(void);
void Delay(uint32_t tick);
void Delay_us(uint32_t ticku);
void Delay_ms(uint32_t tickm);

/************** GPIO **************/
/* LED_G PC13   LED_R PH2		*/
#define LED_G_ON()    {CM_GPIO->PORRC |= 0x2000;CM_GPIO->POSRH |= 0x0004;}
#define LED_G_OFF()   {CM_GPIO->POSRC |= 0x2000;CM_GPIO->PORRH |= 0x0004;}
#define LED_G_Tog()   {CM_GPIO->POTRC |= 0x2000;CM_GPIO->POSRH |= 0x0004;}
#define LED_R_Tog()   {CM_GPIO->POSRC |= 0x2000;CM_GPIO->POTRH |= 0x0004;}
uint8_t GPIO_Init(void);

/************** CRC **************/
void CRC_Init(void);
void CRC_DeInit(void);
uint16_t CRC16_Get(uint8_t *ptr,uint32_t len);
uint32_t CRC32_Get(uint8_t *ptr,uint32_t len);

/************** SPI **************/
extern uint16_t SPI_DATA[4];
extern uint8_t ma_reg[10];
void MA7xx_Init(void);

/************** CAN **************/
/*
0: 	1Mbps
1:	500Kbps
2:	250Kpbs
3:	125Kpbs
*/
#define CAN_BR_10K  0
#define CAN_BR_20K  1
#define CAN_BR_50K  2
#define CAN_BR_125K 3
#define CAN_BR_200K	4
#define CAN_BR_250K 5
#define CAN_BR_500K 6
#define CAN_BR_800K 7
#define CAN_BR_1M 	8
#define CAN_BR_2M 	9
#define CAN_BR_2M5 	10
#define CAN_BR_3M2 	11
#define CAN_BR_4M 	12
#define CAN_BR_5M	13
extern uint8_t DLCtoBytes[16];
extern uint8_t can_tx[64];
void CAN_Init(uint16_t baud,uint16_t filt_id);
uint8_t CAN_send_buf(uint8_t *pbuf,uint16_t MSG_ID,uint8_t data_len);
void FDCAN_Init(uint16_t baud,uint16_t filt_id);
uint8_t FDCAN_NoBRS_Send(uint8_t *pbuf,uint16_t MSG_ID,uint8_t data_len);
void FDCAN_BRS_Send(uint8_t *pbuf,uint16_t MSG_ID,uint8_t dlen);
void MCAN1_GetRxMessage(uint8_t *rx_data, uint16_t *msg_id, uint8_t *dlc_len);
/************** ADC & MOS Check **************/
void ADC12_Init(void);
void ADC_CAL(float *u);
void mos_check(void);
extern const float TempTable[256];
/************** TIM **************/
// fpwm=20KHz
void PWM_Init(void);
void Timer01_Init(void);
void SVPWM(float ual,float ube);
void sing(void);
/************** USART1 **************/
#define RCV_LEN 200
extern uint8_t RXD_BUF[RCV_LEN];
void USART1_Init(uint32_t baud);
void USART1_send_buf(uint8_t *pbuf,uint16_t data_len);

/************** FLASH **************
Function: Push src to Flash
Attention: dst address should start form the start address of a new page
*/
void Push_ROM(uint32_t* dst,uint32_t* src,uint32_t len);
void Clr_ROM(uint32_t* dst);

/************** CMP & DAC & EMB ***************/
void CMP_Init(void);
void DAC_Init(float volt);
void EMB_Init(void);
void bkin_check(void);


uint32_t HAL_GetTick(void);

/*********************
0.Clock
HSE:8MHz
PLLP = 200MHz
PLLQ =  80MHz,can baud clk
PLLR = 200MHz
	// 	HCLK[26:24]		=	SYSCLK		=	200MHz,max=200MHz,CPU,DMA,EFM,SRAM0/H,MPU,GPIO,DCU,INTC,QSPI	
	//	ExCLK[22:20]	= SYSCLK/2 	=	100MHz,max=100MHz,SMC(EXMC)
	//	PCLK4[18:16]	= SYSCLK/2 	=	100MHz,max=100MHz,ADC(Logic),DAC,TRNG
	//	PCLK3[14:12]	=	SYSCLK/4	=	 50MHz,max=50MHz,RTC,WDT,SWDT,WKTM,FCM,CTC
	//	PCLK2[10:8]		=	SYSCLK/4	=	 50MHz,max=60MHz,ADC convert
	//	PCLK1[6:4]		=	SYSCLK/2	=	100MHz,max=100MHz,USART,SPI,Timer0,A5,EMB,CRC,HASH,AES,MCAN(Logic)
	//	PCLK0[2:0]		=	SYSCLK		=	200MHz,max=200MHz,TIM6,TIM4,TIMA,I2C,CMP
Delay tick:TMRA_1
Systick: 200MHz
1.ADC pairs
         CH1             CH2		  		  CH3
ADC1: IN0(Iu)--PA0	IN1(Vbat)--PA1	IN2(HS1)--PA2
ADC2: IN4(Iv)--PA4  IN5(Tmos)--PA5	IN9(HS2)--PB1
ADC3:	IN6(Iw)--PA6	IN7(Tcoil)--PA7	IN8(xxx)--PB0
2.PWM output:			
UH  ---------- PA8   ---------- TIM4_1_OUH
UL  ---------- PB13  ---------- TIM4_1_OUL
VH  ---------- PA9   ---------- TIM4_1_OVH
VL  ---------- PB14  ---------- TIM4_1_OVL
WH  ---------- PA10  ---------- TIM4_1_OWH
WL  ---------- PB15  ---------- TIM4_1_OWL

3.USART1:
PA11   ---------- USART1_TX
PA12   ---------- USART1_RX

4.CAN:
TXD ----------  PB7
RXD ----------  PB6

5.GPIO:
Red    ---------- PH2
Green  ---------- PC13
PC14,PC15 Input

6.SPI3--MA702:
SPI3_SCK   ----------  PB9
SPI3_MOSI  ----------  PB8
SPI3_CSN   ----------  PB5
SPI3_MISO  ----------  PB4

*7.SPI1--Osensor:
SPI1_SCK   ----------  PB0
SPI1_MOSI  ----------  PB1
SPI1_CSN   ----------  PB2
SPI1_MISO  ----------  PB10

*8.CMP
CMP1_INP1  ----------  PA0
CMP3_INP4  ----------  PA4
CMP2_INP3  ----------  PA6
*********************/

#endif
