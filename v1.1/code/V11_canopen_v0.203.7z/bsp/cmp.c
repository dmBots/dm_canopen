#include "bsp.h"
#include "stdio.h"


void CMP_Init(void)
{
	/** ADC1 GPIO Configuration ***
  PA3   ------> CMP1_INP4  ------> Iu
  PB1   ------> CMP3_INP2  ------> Iv
	PA6   ------> CMP2_INP3  ------> Iw
	**/
	
	CM_GPIO->PWPR = 0xA501;		//	Port_Unlock
	CM_GPIO->PCRA3 = 0x8000;	//  CMP1_INP4
	CM_GPIO->PCRB1 = 0x8000;	//  CMP3_INP2
	CM_GPIO->PCRA6 = 0x8000;	//  CMP2_INP3
	CM_GPIO->PWPR = 0xA500;		//	Port_Lock
	
	/* Enable peripheral CMP1 and CMP2 and CMP3 clock */
	CM_PWC->FCG3 &= ~PWC_FCG3_CMP12;
	CM_PWC->FCG3 &= ~PWC_FCG3_CMP34;
	
	/* Set CMP1 mode */
	CM_CMP1->PMSR = 0x80004;	
	CM_CMP1->FIR  = 0x06;
	Delay_us(1);
	CM_CMP1->OCR  = 0x05;
	
	/* Set CMP2 mode */
	CM_CMP2->PMSR = 0x40004;		
	CM_CMP2->FIR  = 0x06;
	Delay_us(1);
	CM_CMP2->OCR  = 0x05;		
	
	/* Set CMP3 mode */
	CM_CMP3->PMSR = 0x20004;		
	CM_CMP3->FIR  = 0x06; 
	Delay_us(1);
	CM_CMP3->OCR  = 0x05;
	
	Delay_us(1);
	CM_CMP1->MDR  = 0x01;	
	CM_CMP2->MDR  = 0x01;			
	CM_CMP3->MDR  = 0x01;	

	/* PMSR: CMP P and V input selection register
	CVSL[19:16]=1000, Select INP4 as the P voltage
	RVSL[3:0]  =0100, Select INM3 as the N voltage DAC1
	*/
	
	/* MDR: CMP operating mode register
	CENA[0]=1, CMP enable
	*/
	
	/* FIR: CMP filtering and interrupt register
	FCKS[2:0]=110, pclk/32 sampling filtering
	CIEN[3]  =0, 	 Disable CMP interrupt
	EDGS[5:4]=00,  Detecting high levels
	*/
	
	/* OCR: CMP operating mode register
	COEN[0]=1, Enable CMP output
	COPS[1]=0, CMP inverted output
	COPE[2]=1, Enable Vcout output
	*/
}




