#include "bsp.h"
#include "stdio.h"


void DAC_Init(float volt)
{
	/* Enable peripheral DAC clock */
	CM_PWC->FCG3 &= ~PWC_FCG3_DAC;
	
	/* DACR: dac control register
	DAE[0]=1, Channel 1 and 2 enable
	DA1E[1]=0, Enable Channel 1, effective when DAE[0]=0
	DA1E[2]=0, Enable Channel 2, effective when DAE[0]=0
	DPSEL[8]=0,Right aligned data register format
	*/
	
	/* DAOCR: DAC Analog Output Control Register
	DAODIS2[15]=1, Prohibit DAC OUT2 port from outputting analog voltage
	DAODIS1[14]=1, Prohibit DAC OUT1 port from outputting analog voltage
	*/
	
	/* DAADPCR: A/D conversion priority control register */
	CM_DAC->DACR  = 0x01;
	CM_DAC->DAOCR = 0xC000;
	CM_DAC->DAADPCR = 0;
	
	/* DADRx: Data Register
	DADR[1], Set dac2 output voltage
	DADR[0], Set dac1 output voltage
	*/
	CM_DAC->DADR1 = 4096.0f*0.303030303030303f*volt;
	CM_DAC->DADR2 = 4096.0f*0.303030303030303f*volt;
}




