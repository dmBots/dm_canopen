#include "bsp.h"
#include "stdio.h"

void EMB_Init(void)
{
	/* Enable peripheral EMB clock */
	CM_PWC->FCG2 &= ~PWC_FCG2_EMB;
	
	/* CTL1: EMB control register
	CMPEN[3:0]=0111, Enable CMP 1 2 3 output ctrl
	*/
	/* INTEN: Interrupt permission register
	CMPINTEN[2]=0, Disable CMP result control interrupt 
	*/
	/* RLSSEL: Set EMB release PWM condition for the specified event
	CMPRSEL[2]=1, EMB_STATx.CMPST=0 PWM output
	*/
	CM_EMB1->CTL1 = 0x07;
	CM_EMB1->INTEN  = 0x00;
	CM_EMB1->RLSSEL  = 0x04;
}

void bkin_check(void)
{
	 if (CM_CMP1->MDR & 0X80)
		 printf("A phase Error\r\n");
	 if (CM_CMP2->MDR & 0X80)
		 printf("C phase Error\r\n");
	 if (CM_CMP3->MDR & 0X80)
		 printf("B phase Error\r\n");
}

