#include "bsp.h"

__RAM_FUNC void Push_ROM(uint32_t* dst,uint32_t* src,uint32_t len)
{
	uint32_t cache_tmp;
	uint32_t* pbuf;
	uint32_t i;
	uint32_t sec;
	pbuf = dst;
	sec = (uint32_t)pbuf>>13;//8KB/page
	CM_EFM->FAPRT	= 0x0123;
	CM_EFM->FAPRT	= 0x3210;// unclock flash access protection
	CM_EFM->KEY1 = 0x01234567;
	CM_EFM->KEY1 = 0xFEDCBA98; // unclock EFM_KEY1
	
	cache_tmp	=	CM_EFM->FRMC&0x00070000;	//	read back CACHE
	CM_EFM->FRMC &= 0xFFF0FFFF;	//	Diable ICACHE,DCACHE,PREFETE
	CM_EFM->FSCLR	=	0x0000003F;	//	CLear the error flag
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
		;//wait until flash is idle

	CM_EFM->FWMC = (CM_EFM->FWMC&0xFFFFFFF8)|4;	//	PEMOD[2:0]=4,Set sector erase mode
	CM_EFM->F0NWPRT = 1<<sec;// remove writing protection lock
	*pbuf	=	0;
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
		;//wait until flash is idle
	CM_EFM->FSCLR	=	0x00000010;	//	Clear the OPTEND flag
	
 /* Sequence program. */
	CM_EFM->FWMC = (CM_EFM->FWMC&0xFFFFFFF8)|3;	//	PEMOD[2:0]=3,Set continuously program
	/* program data. */
	for(i=0;i<len;i++)
	{
	 *pbuf++	=	*src++;
		while((CM_EFM->FSR&0x00000010)==0)// OPTEND[4]=0,programming is not end
			;//wait until operation is end
		CM_EFM->FSCLR	=	0x00000010;	//	Clear the OPTEND flag
	}
	
	CM_EFM->FWMC &= 0xFFFFFFF8;//pemod[2:0]=0,read-only mode
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
	CM_EFM->FSCLR	=	0x00000010;	//	Clear the EOP flag
	CM_EFM->F0NWPRT = 0;// writing protection
	/* recover CACHE */
	CM_EFM->FRMC |= cache_tmp;
	/*	EFM LOCK	*/
	CM_EFM->FWMC |= 0x00010000;// lock EFM_KEY1 register
	CM_EFM->FAPRT	=0x3210;
}

__RAM_FUNC void Clr_ROM(uint32_t* dst)
{
	uint32_t cache_tmp;
	uint32_t* pbuf;
	uint32_t sec;
	
	pbuf = dst;
	sec = (uint32_t)pbuf>>13;//8KB/page
	CM_EFM->FAPRT	= 0x0123;
	CM_EFM->FAPRT	= 0x3210;// unclock flash access protection
	CM_EFM->KEY1 = 0x01234567;
	CM_EFM->KEY1 = 0xFEDCBA98; // unclock EFM_KEY1
	
	cache_tmp	=	CM_EFM->FRMC&0x00070000;	//	read back CACHE
	CM_EFM->FRMC &= 0xFFF0FFFF;	//	Diable ICACHE,DCACHE,PREFETE
	CM_EFM->FSCLR	=	0x0000003F;	//	CLear the error flag
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
		;//wait until flash is idle

	CM_EFM->FWMC = (CM_EFM->FWMC&0xFFFFFFF8)|4;	//	PEMOD[2:0]=4,Set sector erase mode
	CM_EFM->F0NWPRT = 1<<sec;// remove writing protection lock
	*pbuf	=	0;
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
		;//wait until flash is idle
	CM_EFM->FSCLR	=	0x00000010;	//	Clear the OPTEND flag

	/* recover CACHE */
	CM_EFM->FRMC |= cache_tmp;
	/*	EFM LOCK	*/
	CM_EFM->FWMC |= 0x00010000;// lock EFM_KEY1 register
	CM_EFM->FAPRT	=0x3210;
}
