#include "bsp.h"

uint8_t GPIO_Init(void)
{ 
	uint8_t hw_ver;
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	/* 
		DDIS[15]=0,Enable Digital function
		DRV[4]=0,Low level drive strength
		POUTE[1]=1,Enable output
	*/
	CM_GPIO->PCRH2 = 0<<15|0<<4|1<<1;
	CM_GPIO->PCRC13 = 0<<15|0<<4|1<<1;
	/* 
		DDIS[15]=0,Enable Digital function
		PUU[6]=1,Inner pull-up
	*/
	CM_GPIO->PCRC14 = 0<<15|1<<6;
	CM_GPIO->PCRC15 = 0<<15|1<<6;
	
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock
	
	LED_G_OFF();
	
	hw_ver = (CM_GPIO->PIDRC&0xC000)>>14;
	return hw_ver;
}
