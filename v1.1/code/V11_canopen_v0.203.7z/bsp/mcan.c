#include "bsp.h"

/* CAN init function */
void CAN_Init(uint16_t baud,uint16_t filt_id)
{
   /**	CAN GPIO Configuration    
    PB6   ------> CAN_RXD
    PB7   ------> CAN_TXD
    */
	uint16_t i;
	uint32_t brp,seg1,seg2,sjw;
	uint32_t* pRAM;
	
	CM_PWC->FCG1	&= (~(1<<0));	//	Enable MCAN1 Clock
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	CM_GPIO->PFSRB6	=	51;	//	MCAN1_RXD
	CM_GPIO->PFSRB7	=	50;	//	MCAN1_TXD
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock
	
	//	Can bit time config,fcanclk=PLL_Q=80MHz
	CM_PWC->FPRC |= 0xA501;	//	ENABLE CANCKCFGR write
	CM_CMU->CANCKCFGR = (CM_CMU->CANCKCFGR&0x00F0)|8;// CAN1 CLK =PLL_Q=800/10=80MHz
	CM_PWC->FPRC 	= (0xA500 | (CM_PWC->FPRC & 0xFFFD));	//	DISABLE_CANCKCFGR_WRITE
	/* Exit from Sleep mode */
	CM_MCAN1->CCCR &= (~(1<<4));//CSR[4]=0
	while((CM_MCAN1->CCCR)&0x00000008)//wait for No clock stop acknowledged(CSA[3]=0)
		;
	/* Request initialisation */
	CM_MCAN1->CCCR |= (1<<0);//INIT[0]=1,Initialization is started
	while((CM_MCAN1->CCCR&0x0000001)==0)
		;
	/* Enable configuration change */
	CM_MCAN1->CCCR |= (1<<1);//CCE=1,Configuration Change Enable
	if(baud>CAN_BR_1M)
		baud = CAN_BR_1M;
	switch(baud)
	{//Baud=80M/brp/(1+seg1+seg2)
		case CAN_BR_10K:	brp=100;seg1=59;seg2=20;sjw=20;//Baud=80M/100/(1+59+20)=10Kbps
												break;
		case CAN_BR_20K:	brp=50;seg1=59;seg2=20;sjw=20;//Baud=80M/50/(1+59+20)=20Kbps
												break;
		case CAN_BR_50K:	brp=20;seg1=59;seg2=20;sjw=20;//Baud=80M/8/(1+59+20)=50Kbps
												break;
		case CAN_BR_125K:	brp=8;seg1=59;seg2=20;sjw=20;//Baud=80M/8/(1+59+20)=125Kbps
												break;
		case CAN_BR_200K: brp=5;seg1=59;seg2=20;sjw=20;//Baud=80M/5/(1+59+20)=200Kbps
												break;
		case CAN_BR_250K:	brp=4;seg1=59;seg2=20;sjw=20;//Baud=80M/4/(1+59+20)=250Kbps
												break;
		case CAN_BR_500K:	brp=2;seg1=59;seg2=20;sjw=20;//Baud=80M/2/(1+59+20)=500Kbps
												break;
		case CAN_BR_800K:	brp=1;seg1=69;seg2=30;sjw=30;//Baud=80M/1/(1+69+30)=800Kbps
												break;
		case CAN_BR_1M:		brp=1;seg1=59;seg2=20;sjw=20;//Baud=80M/1/(1+59+20)=1Mbps
												break;
		default:					brp=1;seg1=59;seg2=20;sjw=20;//Baud=80M/1/(1+59+20)=1Mbps
												break;
	}
	
	CM_MCAN1->CCCR &= (~(1<<6)); //DAR[6]=0,Automatic retransmission disabled
	CM_MCAN1->CCCR &= (~(1<<14));//TXP=0
	CM_MCAN1->CCCR |= (1<<12); //PXHD=1,Protocol exception handling disabled
	/* Set FDCAN Frame Format */
	CM_MCAN1->CCCR &= (~(1<<8|1<<9));//BRSE=0,FDOE=0 ------FDCAN_FRAME_CLASSIC
	/*
		NSJW[31:25]		NBRP[24:16] NTSEG1[15:8]	NTSEG2[6:0]
	*/
	CM_MCAN1->NBTP =((sjw-1)<<25|(brp-1)<<16|(seg1-1)<<8|(seg2-1)<<0);
	/* If FD operation with BRS is selected, set the data bit timing register */
	/*
		TDC[23] DBRP[20:16]	DTSEG1[12:8]	DTSEG2[7:4]	DSJW[3:0]
	*/
	//CM_MCAN1->DBTP =(0<<0 |7<<16|3<<8|4<<4);
	/* Note THAT:the address is the word address,not the byte address */
	CM_MCAN1->RXESC = 7<<8|7<<4|7;//RBDS[10:8]=7,F1DS[6:4]=7,F0DS[2:0]=7,MAX 64Bytes
	CM_MCAN1->TXESC = 7;//TBDS[2:0]=7,MAX 64Bytes
	CM_MCAN1->SIDFC = 0x00;//0x0000<<2|2<<16;  // 2/16 standard frame elements,start address=0x0000
	CM_MCAN1->XIDFC = 0x0010<<2|0<<16;  // 0/8 extend frame elements,start address=0x0040
	CM_MCAN1->RXF0C = 0x80000000|0x0020<<2|3<<16; // F0OM=1,Overwrite mode 0x80A0030;//
																								// 3/3 RXFIFO0 elements,start address=0x0080
	CM_MCAN1->RXF1C = 0x80000000|0x0056<<2|3<<16; // F1OM=1,Overwrite mode 0x870A00D0;//
																								// 3/3 RXFIFO1 elements,start address=0x0158
	CM_MCAN1->RXBC  = 0x008C<<2;				// 3/3 RX Buffer elements,start address=0x0230 0x00000170;//
	CM_MCAN1->TXEFC = 0x00C2<<2|3<<16;	// 4/4 TX event FIFO elements,start address=0x0308 0x000C01D0;//
	CM_MCAN1->TXBC  = 0x00CA<<2|8<<16|8<<24;  // 3/3 TX BUF elements,start address=0x0328 0x060C0230;//
	CM_MCAN1->TXBTIE= 0x0003FFFF;

	pRAM = (uint32_t*)SRAMCAN;
	for(i=0;i<256;i++)
	 *pRAM++=0x00000000;
		/* Configure global filter */
	//ANFS[5:4]=2,Reject Non-matching Frames Standard
	//ANFE[3:2]=2,Reject Non-matching Frames Extended
	//RRFS[1]=0,Reject all remote frames with 11-bit standard IDs
	//RRFE[0]=0,Reject all remote frames with 29-bit extended IDs
	CM_MCAN1->GFC = 0x00;//((CM_MCAN1->GFC)&(~(3<<4|3<<2|1<<1|1<<0)))|(2<<4|2<<2|1<<1|1<<0);
	/* Config Receive CAN MSG& Interrupt */
	//ID1[26:16]=0x3FB
	//ID2[10:0]=0x400
	//SFEC[29:27]=1,Store in RX FIFO0 if filter matches
	//SFT[31:30]=1,SFID1 or SFID2
	filt_id = filt_id&0x7FF;
	SRAMCAN->FLSSA[0][0] = 0x40000000|1<<27|filt_id<<16|0x7FF;

	/* Enable Interrupt lines */
	//The configuration of IE controls whether an interrupt is generated. 
	//The configuration of ILS controls on which interrupt line an interrupt is signaled.
	CM_MCAN1->IE   = 0x02001211;//  RF0NE&RF1NE=1,RX FIFO 0&1 New Message Interrupt Enable
	CM_MCAN1->ILS  = 0x02001200;//	RF0NL[0]=1,RxFIFO0 assigned to fdcan_intr1_it(interrupt line1)
													  //	RF1NL[4]=0,RxFIFO1 assigned to fdcan_intr0_it(interrupt line0)
	CM_MCAN1->ILE  = 0x00000003;//enable interrupt line fdcan_intr0_it & fdcan_intr1_it
   Delay(0xF);
	/* Request leave initialisation */
	CM_MCAN1->CCCR &= (~(1<<0));//INIT=0,Normal Operation
	while(CM_MCAN1->CCCR&0x0000001)
		;
	CM_MCAN1->IR = 0xFFFFFFFF;
	
	CM_INTC->INTSEL3	=	INT_SRC_MCAN1_INT0;	// MCAN1_INT0
	NVIC_SetPriority(CAN_IRQn1, 3); // 0x3FB ~ 0x400
	NVIC_ClearPendingIRQ(CAN_IRQn1);
  NVIC_EnableIRQ(CAN_IRQn1);
	
	CM_INTC->INTSEL7	=	INT_SRC_MCAN1_INT1;	// MCAN1_INT1
	NVIC_SetPriority(CAN_IRQn2, 3); // 0x3FB ~ 0x400
	NVIC_ClearPendingIRQ(CAN_IRQn2);
  NVIC_EnableIRQ(CAN_IRQn2);
}

/* CAN-FD init function */
void FDCAN_Init(uint16_t baud,uint16_t filt_id)
{
   /**	CAN GPIO Configuration    
    PB6   ------> CAN_RXD
    PB7   ------> CAN_TXD
    */
	uint16_t i;
	uint32_t brp,seg1,seg2,sjw;
	uint32_t* pRAM;
	
	CM_PWC->FCG1	&= (~(1<<0));	//	Enable MCAN1 Clock
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	/*
		DDIS[15]=0,Enable Digital function
		DRV[4]=2,Mid level drive strength
	*/
	CM_GPIO->PCRB6 = 0<<15|2<<4;
	CM_GPIO->PCRB7 = 0<<15|2<<4;
	CM_GPIO->PFSRB6	=	51;	//	MCAN1_RXD
	CM_GPIO->PFSRB7	=	50;	//	MCAN1_TXD
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock
	
	//	Can bit time config,fcanclk=PLL_Q=80MHz
	CM_PWC->FPRC |= 0xA501;	//	ENABLE CANCKCFGR write
	CM_CMU->CANCKCFGR = (CM_CMU->CANCKCFGR&0x00F0)|8;// CAN1 CLK =PLL_Q=800/10=80MHz
	CM_PWC->FPRC 	= (0xA500 | (CM_PWC->FPRC & 0xFFFD));	//	DISABLE_CANCKCFGR_WRITE
	/* Exit from Sleep mode */
	CM_MCAN1->CCCR &= (~(1<<4));//CSR[4]=0
	while((CM_MCAN1->CCCR)&0x00000008)//wait for No clock stop acknowledged(CSA[3]=0)
		;
	/* Request initialisation */
	CM_MCAN1->CCCR |= (1<<0);//INIT[0]=1,Initialization is started
	while((CM_MCAN1->CCCR&0x0000001)==0)
		;
	/* Enable configuration change */
	CM_MCAN1->CCCR |= (1<<1);//CCE[1]=1,Configuration Change Enable
	CM_MCAN1->CCCR &= (~(1<<6)); //DAR[6]=0,Automatic retransmission Enabled
	CM_MCAN1->CCCR &= (~(1<<14));//TXP[14]=0
	CM_MCAN1->CCCR &= (~(1<<12)); //PXHD=0,Protocol exception handling Enabled
	/* Set FDCAN Frame Format */
	CM_MCAN1->CCCR |= (1<<8|1<<9);//BRSE=1,FDOE=1 ------FDCAN_FRAME_FD_BRS
	/* Reset FDCAN Operation Mode */
	/* Set FDCAN Operating Mode:
               | Normal | Restricted |    Bus     | Internal | External
               |        | Operation  | Monitoring | LoopBack | LoopBack
     CCCR.TEST |   0    |     0      |     0      |    1     |    1
     CCCR.MON  |   0    |     0      |     1      |    1     |    0
     TEST.LBCK |   0    |     0      |     0      |    1     |    1
     CCCR.ASM  |   0    |     1      |     0      |    0     |    0
  */
	//ASM[2]=0,Normal operation
	//MON[5]=0,disable bus monitoring
	//TEST[7]=0,normal operation,register TEST holds reset values
	CM_MCAN1->CCCR &= (~(1<<7|1<<5|1<<2));
	CM_MCAN1->TEST &= (~(1<<4));//LBCK[4]=0,reset value,Loop Back mode is disable
	/*
		NSJW[31:25]		NBRP[24:16] NTSEG1[15:8]	NTSEG2[6:0]
	*/
	CM_MCAN1->NBTP =((20-1)<<25|(1-1)<<16|(59-1)<<8|(20-1)<<0);//Baud=80M/1/(1+59+20)=1Mbps
	if(baud<CAN_BR_1M)
		baud = CAN_BR_1M;
	switch(baud)
	{//Baud=80M/brp/(1+seg1+seg2),80% sampling time
		// seg1:	1-32
		// seg2: 	2-15
		// brp :	1-31,when TDC=1,Dbrp should be 1 or 2
		case CAN_BR_1M:		brp=2;seg1=31;seg2=8;sjw=8;//Baud=80M/2/(1+31+8)=1Mbps
												break;
		case CAN_BR_2M: 	brp=1;seg1=31;seg2=8;sjw=8;//Baud=80M/1/(1+31+8)=2Mbps
												break;
		case CAN_BR_2M5:	brp=1;seg1=25;seg2=6;sjw=6;//Baud=80M/1/(1+25+6)=2.5Mbps,81.25% sampling time
												break;
		case CAN_BR_3M2:	brp=1;seg1=19;seg2=5;sjw=5;//Baud=80M/1/(1+19+5)=3.2Mbps
												break;
		case CAN_BR_4M:		brp=1;seg1=15;seg2=4;sjw=4;//Baud=80M/1/(1+15+4)=4Mbps
												break;
		case CAN_BR_5M:		brp=1;seg1=12;seg2=3;sjw=3;//Baud=80M/1/(1+12+3)=5Mbps,81.25% sampling time
												break;
		default:					brp=2;seg1=31;seg2=8;sjw=8;//Baud=80M/2/(1+31+8)=1Mbps
												break;
	}
	/*
		TDC[23] DBRP[20:16]	DTSEG1[12:8]	DTSEG2[7:4]	DSJW[3:0]
	*/
	CM_MCAN1->DBTP =((brp-1)<<16|(seg1-1)<<8|(seg2-1)<<4|(sjw-1));
		/* Configure and enable Tx Delay Compensation, required for BRS mode.
     TdcOffset default recommended value: DataTimeSeg1 * DataPrescaler
     TdcFilter default recommended value: 0 */
	CM_MCAN1->TDCR  = (brp*seg1)<<8 | 0<<0;
	if(baud>CAN_BR_2M)
		CM_MCAN1->DBTP |= 1<<23;//Transceiver delay compensation enabled
	
	/* Note THAT:the address is the word address,not the byte address */
	CM_MCAN1->RXESC = 7<<8|7<<4|7;//RBDS[10:8]=7,F1DS[6:4]=7,F0DS[2:0]=7,MAX 64Bytes
	CM_MCAN1->TXESC = 7;//TBDS[2:0]=7,MAX 64Bytes
	CM_MCAN1->SIDFC = 0x0000<<2|2<<16;  // 2/16 standard frame elements,start address=0x0000
	CM_MCAN1->XIDFC = 0x0010<<2|0<<16;  // 0/8 extend frame elements,start address=0x0040
	CM_MCAN1->RXF0C = 0x80000000|0x0020<<2|3<<16; // F0OM=1,Overwrite mode
																								// 3/3 RXFIFO0 elements,start address=0x0080
	CM_MCAN1->RXF1C = 0x80000000|0x0056<<2|3<<16; // F1OM=1,Overwrite mode
																								// 3/3 RXFIFO1 elements,start address=0x0158
	CM_MCAN1->RXBC  = 0x008C<<2;				// 3/3 RX Buffer elements,start address=0x0230
	CM_MCAN1->TXEFC = 0x00C2<<2|4<<16;	// 4/4 TX event FIFO elements,start address=0x0308
	CM_MCAN1->TXBC  = 0x00CA<<2|3<<16;  // 3/3 TX BUF elements,start address=0x0328

	pRAM = (uint32_t*)SRAMCAN;
	for(i=0;i<256;i++)
	 *pRAM++=0x00000000;
		/* Configure global filter */
	//ANFS[5:4]=2,Reject Non-matching Frames Standard
	//ANFE[3:2]=2,Reject Non-matching Frames Extended
	//RRFS[1]=0,Reject all remote frames with 11-bit standard IDs
	//RRFE[0]=0,Reject all remote frames with 29-bit extended IDs
	CM_MCAN1->GFC = ((CM_MCAN1->GFC)&(~(3<<4|3<<2|1<<1|1<<0)))|(2<<4|2<<2|1<<1|1<<0);
	/* Config Receive CAN MSG& Interrupt */
	//ID1[26:16]=0x3FB
	//ID2[10:0]=0x400
	//SFEC[29:27]=1,Store in RX FIFO0 if filter matches
	//SFT[31:30]=1,SFID1 or SFID2
	filt_id = filt_id&0x7FF;
	SRAMCAN->FLSSA[0][0] = 0x40000000|1<<27|filt_id<<16|0x7FF;
	
	/* Enable Interrupt lines */
	//The configuration of IE controls whether an interrupt is generated. 
	//The configuration of ILS controls on which interrupt line an interrupt is signaled.
	CM_MCAN1->IE   = 0x00000011;//  RF0NE&RF1NE=1,RX FIFO 0&1 New Message Interrupt Enable
	CM_MCAN1->ILS  = 0x00000001;//	RF0NL[0]=1,RxFIFO0 assigned to fdcan_intr1_it(interrupt line1)
													  //	RF1NL[4]=0,RxFIFO1 assigned to fdcan_intr0_it(interrupt line0)
	CM_MCAN1->ILE  = 0x00000003;//enable interrupt line fdcan_intr0_it & fdcan_intr1_it
   Delay(0xF);
	/* Request leave initialisation */
	CM_MCAN1->CCCR &= (~(1<<0));//INIT=0,Normal Operation
	while(CM_MCAN1->CCCR&0x0000001)
		;
	CM_MCAN1->IR = 0xFFFFFFFF;
	
	CM_INTC->INTSEL3	=	INT_SRC_MCAN1_INT1;	// MCAN1_INT0
	NVIC_SetPriority(CAN_IRQn1, 3); // 0x3FB ~ 0x400
	NVIC_ClearPendingIRQ(CAN_IRQn1);
  NVIC_EnableIRQ(CAN_IRQn1);
}



uint8_t DLCtoBytes[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 12, 16, 20, 24, 32, 48, 64};
__RAM_FUNC uint8_t FDCAN_NoBRS_Send(uint8_t *pbuf,uint16_t MSG_ID,uint8_t data_len)
{
	uint32_t PutIndex;
	uint8_t dlc,i;
	uint32_t *TxAdd;
	/* Check that the Tx FIFO/Queue is not full */
	PutIndex = (CM_MCAN1->TXFQS & MCAN_TXFQS_TFQPI)>>16;/* Retrieve the Tx FIFO PutIndex */
	/* Add the message to the Tx FIFO/Queue */
	if(data_len<9)
		dlc=data_len;
	else if(data_len<=12)
		dlc=9;
	else if(data_len<=16)
		dlc=10;
	else if(data_len<=20)
		dlc=11;
	else if(data_len<=24)
		dlc=12;
	else if(data_len<=32)
		dlc=13;
	else if(data_len<=48)
		dlc=14;
	else if(data_len<=64)
		dlc=15;
	SRAMCAN->TBSA[PutIndex][0] = (MSG_ID<<18)|(0<<29)|(0<<30);//ID[28:18],RTR[29]=0,XTD[30]=0
	SRAMCAN->TBSA[PutIndex][1] = (dlc<<16)|0<<20|1<<21|0<<23;//BRS[20]=1,FDF[21]=1,EFC=0
	TxAdd = (uint32_t*)&(SRAMCAN->TBSA[PutIndex][2]);
	for(i=0;i<data_len;i+=4)
	{
		*TxAdd = (*(pbuf+i)<<0)|(*(pbuf+i+1)<<8)|(*(pbuf+i+2)<<16)|(*(pbuf+i+3)<<24);
		 TxAdd++;
	}
	/* Activate the corresponding transmission request */
  CM_MCAN1->TXBAR = ((uint32_t)1 << PutIndex);
	
	if(CM_MCAN1->TXFQS == 0x00) {
		return 1;
	}
	else
		return 0;
}

__RAM_FUNC void FDCAN_BRS_Send(uint8_t *pbuf,uint16_t MSG_ID,uint8_t dlen)
{
	uint32_t PutIndex;
	uint8_t dlc,i;
	uint32_t *TxAdd;
	/* Check that the Tx FIFO/Queue is not full */
	PutIndex = (CM_MCAN1->TXFQS & MCAN_TXFQS_TFQPI)>>16;/* Retrieve the Tx FIFO PutIndex */
	/* Add the message to the Tx FIFO/Queue */
	if(dlen<9)
		dlc=dlen;
	else if(dlen<=12)
		dlc=9;
	else if(dlen<=16)
		dlc=10;
	else if(dlen<=20)
		dlc=11;
	else if(dlen<=24)
		dlc=12;
	else if(dlen<=32)
		dlc=13;
	else if(dlen<=48)
		dlc=14;
	else if(dlen<=64)
		dlc=15;
	SRAMCAN->TBSA[PutIndex][0] = (MSG_ID<<18)|(0<<29)|(0<<30);//ID[28:18],RTR[29]=0,XTD[30]=0
	SRAMCAN->TBSA[PutIndex][1] = (dlc<<16)|1<<20|1<<21|0<<23;//BRS[20]=1,FDF[21]=1,EFC=0
	TxAdd = (uint32_t*)&(SRAMCAN->TBSA[PutIndex][2]);
	for(i=0;i<dlen;i+=4)
	{
		*TxAdd = (*(pbuf+i)<<0)|(*(pbuf+i+1)<<8)|(*(pbuf+i+2)<<16)|(*(pbuf+i+3)<<24);
		 TxAdd++;
	}
	/* Activate the corresponding transmission request */
  CM_MCAN1->TXBAR = ((uint32_t)1 << PutIndex);
}

uint8_t CAN_send_buf(uint8_t *pbuf,uint16_t MSG_ID,uint8_t data_len)
{
		uint32_t PutIndex;
	/* Check that the Tx FIFO/Queue is not full */
	PutIndex = (CM_MCAN1->TXFQS & MCAN_TXFQS_TFQPI)>>16;/* Retrieve the Tx FIFO PutIndex */
	/* Add the message to the Tx FIFO/Queue */
	SRAMCAN->TBSA[PutIndex][0] = (MSG_ID<<18)|(0<<29)|(0<<30);//ID[28:18],RTR=0,XTD=0
	SRAMCAN->TBSA[PutIndex][1] = (data_len<<16)|0<<20|0<<21|0<<23;//BRS=0,FDF=0,EFC=0
	SRAMCAN->TBSA[PutIndex][2] = (*(pbuf+0)<<0)|(*(pbuf+1)<<8)|(*(pbuf+2)<<16)|(*(pbuf+3)<<24);
	SRAMCAN->TBSA[PutIndex][3] = (*(pbuf+4)<<0)|(*(pbuf+5)<<8)|(*(pbuf+6)<<16)|(*(pbuf+7)<<24);
	
	/* Activate the corresponding transmission request */
  CM_MCAN1->TXBAR = ((uint32_t)1 << PutIndex);
	
	if((CM_MCAN1->TXFQS & MCAN_TXFQS_TFQF) != 0x00) {
		return 1;
	}
	if((CM_MCAN1->TXBC & MCAN_TXBC_TFQS) == 0x00) {
		return 1;
	}
	else
		return 0;
}

void MCAN1_GetRxMessage(uint8_t *rx_data, uint16_t *msg_id, uint8_t *dlc_len)
{
	uint32_t RevIndex;
	volatile uint32_t R0,R1,R2,R3;
	
	RevIndex=((CM_MCAN1->RXF0S)&MCAN_RXF0S_F0GI)>>8;
	R0=SRAMCAN->F0SA[RevIndex][0];
	R1=SRAMCAN->F0SA[RevIndex][1];
	R2=SRAMCAN->F0SA[RevIndex][2];
	R3=SRAMCAN->F0SA[RevIndex][3];

	*msg_id     =(uint16_t)((R0&0x1FFC0000)>>18);
	*dlc_len    = (uint8_t)((R1 >> 16) & 0xFF);
	rx_data[0] = (uint8_t)(R2 & 0xFF);
	rx_data[1] = (uint8_t)((R2 >> 8) & 0xFF);
	rx_data[2] = (uint8_t)((R2 >> 16) & 0xFF);
	rx_data[3] = (uint8_t)((R2 >> 24) & 0xFF);

	rx_data[4] = (uint8_t)(R3 & 0xFF);
	rx_data[5] = (uint8_t)((R3 >> 8) & 0xFF);
	rx_data[6] = (uint8_t)((R3 >> 16) & 0xFF);
	rx_data[7] = (uint8_t)((R3 >> 24) & 0xFF);

	CM_MCAN1->RXF0A = RevIndex;
}



