#include "bsp.h"

uint16_t SPI_DATA[4];
//uint8_t ma_reg[10];
void SPI_DMA_Init(void)
{
/*************** DMA Config	***************/
	CM_PWC->FCG0PC = 0xA5A50001;	//	ENABLE_FCG0_REG_WRITE
	CM_PWC->FCG0 &= (~(1<<15));	//	Enable DMA2 Clock
	CM_PWC->FCG0PC = 0xA5A50000;	//	DISABLE_FCG0_REG_WRITE
	CM_DMA2->EN	=	1;	//	Enable DMA2
	/* Initialize DMA. */
	CM_DMA2->SAR0	=	(uint32_t)(&CM_SPI3->DR);	//	SAR=SPI3.DR
	CM_DMA2->DAR0	=	(uint32_t)SPI_DATA;	//	DAR=buf
	/*
		BLKSIZE[9:0]=1,One data one transfer
		CNT[31:16]=1
	*/
	CM_DMA2->DTCTL0	=	1|1<<16;
		/*
		IE[12]=1,Enable CH1 interrupt
		LLPRUN[11]=0,don't transfer immediately,wait for next transfer,if link transfer enabled
		LLPEN[10]=0,Disable link transfer
		HSIZE[9:8]=1,16 bit length
		DNSEQEN[7]=0,don't allow dest	 add discontinous transfer
		SNSEQEN[6]=0,don't allow source add discontinous transfer
		DRPTEN[5]=0,Disable dest repeat
		SRPTEN[4]=0,Disable source repeat
		DINC[3:2]=0,Dest ADD increase
		SINC[1:0]=0,Source ADD fix
	*/	
	CM_DMA2->CHCTL0 =	1<<12|0<<11|0<<10|1<<8|0<<7|0<<6|0<<5|0<<4|0<<2|0;
	CM_DMA2->CHEN	=	1;	//	Enable DMA2_CH0
	/* Clear DMA flag. */
	CM_DMA2->INTCLR0	=	0x000F000F;	// clear REQERR,TRNERR flag
	CM_DMA2->INTCLR1	=	0x000F000F;	// clear BTC,TC flag
	/*
		MSKREQERR[21:16]=1,Mask CH0 request error interrupt
		MSKTRNERR[5:0]=1,Mask CH0 transfer error interrupt
	*/
	CM_DMA2->INTMASK0 = 1<<16|1;
	/*
	MSKBTC[21:16]=1,Mask CH0 Block transfer complete interrupt
	MSKTC[5:0]=0,Don't mask CHO transfer complete interrupt
	*/
	CM_DMA2->INTMASK1 = 1<<16|0;

	CM_PWC->FCG0PC = 0xA5A50001;	//	ENABLE_FCG0_REG_WRITE
	CM_PWC->FCG0 &= (~(1<<17));	//	Enable AOS Clock
	CM_AOS->DMA2_TRGSEL0	=	EVT_SRC_SPI3_SPRI;
	CM_PWC->FCG0PC = 0xA5A50000;	//	DISABLE_FCG0_REG_WRITE
	
	CM_INTC->INTSEL2	=	INT_SRC_DMA2_TC0;	// DMA2_TC0
	NVIC_SetPriority(DMA2_CH0_IRQn, 2);	//Default Priority for IRQ, Possible values are 0 (high priority) to 15 (low priority)
	NVIC_ClearPendingIRQ(DMA2_CH0_IRQn);
	NVIC_EnableIRQ(DMA2_CH0_IRQn);
}

void SPI_Init(void)
{
	/************************
		SPI3_SCK   ----------  PB9
		SPI3_MOSI  ----------  PB8
		SPI3_CSN   ----------  PB5
		SPI3_MISO  ----------  PB4
	*************************/
	CM_PWC->FCG1	&= (~(1<<18));	//	Enable SPI3 Clock
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	/*
		DDIS[15]=0,Enable Digital function
		DRV[4]=2,Mid level drive strength
	*/
	CM_GPIO->PCRB9 = 0<<15|2<<4;
	CM_GPIO->PCRB8 = 0<<15|2<<4;
	CM_GPIO->PCRB5 = 0<<15|2<<4;
	CM_GPIO->PSPCR &= 0x03;//Disable nTRST,JTDI,JTDO_TRACESWO
	CM_GPIO->PFSRB9 = 43;//SPI3_SCK
	CM_GPIO->PFSRB8 = 40;//SPI3_MOSI
	CM_GPIO->PFSRB5 = 42;//SPI3_SS0
	CM_GPIO->PFSRB4 = 41;//SPI3_MISO
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock

	/************************ SPI3 Configuration *************************/
	/*
		MSSIE[15]=1,Master SCK delay time determined by SCKDL
		MSSDLE[14]=1,Master SS delay time determined by SSDL
		MIDIE[13]=1,Next delay time determined by NXTDL
		LSBF[12]=0,MSB first
		DSIZE[11:8]=12,16bit width
		SSA[7:5]=0,SS0
		MBR[3:2]=2,4 divider,F_bps=F_base/4=50/4=12.5MHz
		CPOL[1]=0,
		CPHA[0]=0,
	*/
	CM_SPI3->CFG2 = 1<<15|1<<14|1<<13|0<<12|12<<8|0<<5|2<<2|0<<1|0;
	/*
		MIDI[30:28]=5,Next fetch data idle time is 6+2 SCK
		MSSDL[26:24]=0,SS inactive time is 1 SCK time
		MSSI[22:20]=0,SS idle time is 1SCK
		CLKDIV[14:12]=0,F_base=PCLK1/2=50MHz
		SS0PV[8]=0,SS0 Active is Low
		SPRDTD[6]=0,DR read receive buf
		FTHLV[1:0]=0,1 frame
	*/
	CM_SPI3->CFG1 = 5<<28|0<<24|0<<20|0<<8|0<<6|0;

	/* Configure control register */
	/*
		PAE[15]=0,no parity
		PAOE[14]=0,Even parity of send and receive
		PATE[13]=0,parity auto detection is not allowed
		MODFE[12]=0,Disable mode fault detected
		CSUSPE[7]=0,Disable communication suspend
		MSTR[3]=1,Master mode
		TXMDS[1]=0,full-duplex mode
		SPIMDS[0]=0,4 wire SPI
	*/
	CM_SPI3->CR = 0<<15|0<<14|0<<13|0<<12|0<<7|1<<3|0<<1|0;
	CM_SPI3->CR	|= 0x00000040;	//	spe[6],Enable SPI3
}

uint16_t SPI_RW(uint16_t x)
{
  while((CM_SPI3->SR&0x00000020)==0);// TDEF[5]=1,wait until TX buffer empty
	CM_SPI3->DR = x;
	while((CM_SPI3->SR&0x00000080)==0);// RDFF[7]=1,wait until RX buffer not empty
	return CM_SPI3->DR;
}

uint8_t reg_rd[11];
void MA7xx_Init(void)
{
	uint8_t i;
	uint8_t reg_map[11]={0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x09,0x0E,0x10,0x1B};
	uint16_t reg_add,rd_val;
	/* Read out all registers value */
	SPI_Init();
	for(i=0;i<11;i++)
	{
		reg_add = 0x4000|reg_map[i]<<8;
		SPI_RW(reg_add);
		Delay_ms(1);
		rd_val=SPI_RW(0x0000);
		reg_rd[i]=rd_val>>8;
		Delay_ms(25);
	}
	
	/* Verify registers value*/
	for(i=0;i<10;i++)
	{
		if(reg_rd[i]!=ma_reg[i])
		{
			reg_add = 0x8000|reg_map[i]<<8|ma_reg[i];
			SPI_RW(reg_add);
			Delay_ms(25);
			rd_val=SPI_RW(0x0000);
			reg_rd[i]=rd_val>>8;
			Delay_ms(5);
		}
	}
	/* After Register writing,then enables DMA to get angle from ma732 */
	SPI_DMA_Init();
}
