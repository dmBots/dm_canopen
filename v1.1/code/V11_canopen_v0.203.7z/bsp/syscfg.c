#include "bsp.h"
#include "stdio.h"
#include "string.h"

/*M divider,1~4,PFD=[8,25MHz]*/
#define PLL_M 1
/*N Multiplier,25~150,VCO[600,1200MHz] */
#define PLL_N 100
/*P,Q,R divider,2~16*/
#define PLL_P 4
#define PLL_Q 10
#define PLL_R 4

void SYS_Init(void)
{
	uint16_t timeout;
	uint32_t fcg0 = CM_PWC->FCG0;
  uint32_t fcg1 = CM_PWC->FCG1;
  uint32_t fcg2 = CM_PWC->FCG2;
  uint32_t fcg3 = CM_PWC->FCG3;
	/* Set bus clk div. */
	CM_PWC->FCG0PC = 0xA5A50001; // Enable FCG0 reg write
		/* Only current system clock source is MPLL need to close fcg0~fcg3 and
	open fcg0~fcg3 during switch system clock division.
	We need to backup fcg0~fcg3 before close them. */
	if(CM_CMU->CKSWR == 5)
	{
			/* Close fcg0~fcg3. */
			CM_PWC->FCG0 = 0xFFFFFA0E;
			CM_PWC->FCG1 = 0xFFFFFFFF;
			CM_PWC->FCG2 = 0xFFFFFFFF;
			CM_PWC->FCG3 = 0xFFFFFFFF;

			/* Wait stable after close fcg. */
			do
			{
					timeout++;
			}while(timeout < 0x200);
	}
	
	CM_PWC->FPRC |= 0xA501;// Enable clock reg write,PWC_FPRC.FPRCB0
	// 	HCLK[26:24]		=	SYSCLK		=	200MHz,max=200MHz,CPU,DMA,EFM,SRAM0/H,MPU,GPIO,DCU,INTC,QSPI	
	//	ExCLK[22:20]	= SYSCLK/2 	=	100MHz,max=100MHz,SMC(EXMC)
	//	PCLK4[18:16]	= SYSCLK/2 	=	100MHz,max=100MHz,ADC(Logic),DAC,TRNG
	//	PCLK3[14:12]	=	SYSCLK/4	=	 50MHz,max=50MHz,RTC,WDT,SWDT,WKTM,FCM,CTC
	//	PCLK2[10:8]		=	SYSCLK/4	=	 50MHz,max=60MHz,ADC convert
	//	PCLK1[6:4]		=	SYSCLK/2	=	100MHz,max=100MHz,USART,SPI,Timer0,A5,EMB,CRC,HASH,AES,MCAN(Logic)
	//	PCLK0[2:0]		=	SYSCLK		=	200MHz,max=200MHz,TIM6,TIM4,TIMA,I2C,CMP
	CM_CMU->SCFGR = ( 0 << 24 | 1 << 20 | 1 << 16 | 2 << 12 | 2 << 8 | 1 << 4 | 0 );
	CM_PWC->FPRC = (0xA500 | (CM_PWC->FPRC & 0xFFFE)); // disbalbe clock reg write
	timeout=0;
	do
	{
			timeout++;
	}while(timeout < 0x200);
        /* Open fcg0~fcg3. */
        CM_PWC->FCG0 = fcg0;
        CM_PWC->FCG1 = fcg1;
        CM_PWC->FCG2 = fcg2;
        CM_PWC->FCG3 = fcg3;
	CM_PWC->FCG0PC = 0xA5A50000; // Disbale FCG0 Reg write
	/* Wait stable after open fcg. */
        timeout = 0;
        do
        {
            timeout++;
        }while(timeout < 0x200);
	
   /* Config Xtal */				
	CM_PWC->FPRC |= 0xA501;// Enable clock reg write
	/*
				B7:write 1
				XTALMS[6] = 0, 0:osc 1:exclk
				XTALDRV[5:4] = 2, 0:High(20~25M)
													1:Mid(16~20M)
													2:Low(8~16M)
													3:uLow(4~8M)
	*/
	CM_CMU->XTALCFGR = 1<<7|0<<6|2<<4;
  CM_PWC->FPRC = (0xA500 | (CM_PWC->FPRC & 0xFFFE)); // disbalbe clock reg write

   /* Enable Xtal */
  CM_PWC->FPRC |= 0xA501;// Enable clock reg write
	CM_CMU->XTALCR = 0;	//	XTALSTP=0,Start XTAL
	while((CM_CMU->OSCSTBSR&0x08)==0) // XTALSTBF[3]=0,XTAL stop or unstable
		;// wait for XTAL Ready
  CM_PWC->FPRC = (0xA500 | (CM_PWC->FPRC & 0xFFFE)); // disbalbe clock reg write
	
		/* sram init include read/write wait cycle setting */	
	CM_SRAMC->WTPR = 0x77;	//	SRAM_WT_Enable
  CM_SRAMC->CKPR = 0x77;	//	SRAM_CK_Enable
	/*
		SRAMBWWT[30:28]	=	1
		SRAMBRWT[26:24]	=	1,Ret SRAM RW 1 wait
		SRAMHWWT[22:20]	=	0
		SRAMHRWT[18:16]	=	0,SRAMH RW 0 wait
		SRAM0WWT[6:4]		=	0
		SRAM0RWT[2:0]		=	0,SRAM0 RW 0 wait
	*/
	CM_SRAMC->WTCR = 1<<28|1<<24;
	CM_SRAMC->WTPR = 0x76;	//	SRAM_WT_Disable
	CM_SRAMC->CKPR = 0x76;	//	SRAM_CK_Disable
	CM_PWC->RAMOPM = 0x8043;	//	RAM Work at high speed
	
	/* flash read wait cycle setting */
	CM_EFM->FAPRT = 0x0123;
  CM_EFM->FAPRT = 0x3210;	//	EFM_Unlock
	CM_EFM->FRMC = 3<<0|1<<16|1<<17|1<<18;// FLWT[3:0]=3,ICACHE[16]=1,DCACHE[17]=1,PREFETE[18]=1
	CM_EFM->FAPRT = 0x3210;
	CM_EFM->FAPRT = 0x3210;	//	EFM_Lock

	/* MPLL config (XTAL / pllmDiv * plln / PllpDiv = 200M). */
	CM_PWC->FPRC = 0xA501;	//	ENABLE_CLOCK_REG_WRITE
	CM_CMU->PLLHCFGR &= 0xFFFFFF7F;	//	choose external oscillator as PLL input clock source,PLLSRC[7]=0
	CM_PWC->FPRC = (0xA500 | (CM_PWC->FPRC & 0xFFFE)); // disbalbe clock reg write

	CM_PWC->FPRC |= 0xA501;	//	ENABLE_CLOCK_REG_WRITE
	/*
	PLLHP[31:28]=1,PLLP = VCO/2
	PLLHQ[27:24]=1,PLLQ = VCO/2,2~16 divider
	PLLHR[23:20]=1,PLLR = VCO/2,2~16 divider
	PLLHN[15:8] =99,VCO = 800MHz,25~150 Multiplier, [600,1200]
	PLLHM[1:0]	= 1,1~4 divider,PLL input clock = XOSC/PLLM = 8/1 = 8MHz
	*/
	CM_CMU->PLLHCFGR = (PLL_P-1)<<28|(PLL_Q-1)<<24|(PLL_R-1)<<20|(PLL_N-1)<<8|(PLL_M-1);
	CM_PWC->FPRC = (0xA500 | (CM_PWC->FPRC & 0xFFFE)); // disbalbe clock reg write
	/* Enable MPLL. */
	CM_PWC->FPRC |= 0xA501;	//	ENABLE_CLOCK_REG_WRITE
	CM_CMU->PLLHCR = 0;// PLLHOFF=1,PLL Start
  while((CM_CMU->OSCSTBSR&0x20)==0)// PLLHSTBF[5]=0,XTAL stop or unstable
		;// wait for PLL Stable
  CM_PWC->FPRC = (0xA500 | (CM_PWC->FPRC & 0xFFFE)); // disbalbe clock reg write

	/* Switch system clock source to MPLL. */
	CM_PWC->FCG0PC = 0xA5A50001;	//	ENABLE_FCG0_REG_WRITE
	CM_PWC->FCG0 = 0xFFFFFA0E;
	CM_PWC->FCG1 = 0xFFFFFFFF;
	CM_PWC->FCG2 = 0xFFFFFFFF;
	CM_PWC->FCG3 = 0xFFFFFFFF;/* Close fcg0~fcg3. */
	/* Wait stable after close fcg. */
	timeout = 0;
	do
	{
			timeout++;
	}while(timeout < 0x200);
	
	/* Switch to target system clock source.*/
	CM_PWC->FPRC |= 0xA501;	//	ENABLE_CLOCK_REG_WRITE
	CM_CMU->CKSWR = 5;//CKSW[2:0]=5, Choose PLLH as system clk
	CM_PWC->FPRC = (0xA500 | (CM_PWC->FPRC & 0xFFFE)); // disbalbe clock reg write
	timeout = 0;
    do
    {
        timeout++;
    }while(timeout < 0x200);

    /* Open fcg0~fcg3. */
    CM_PWC->FCG0 = fcg0;
    CM_PWC->FCG1 = fcg1;
    CM_PWC->FCG2 = fcg2;
    CM_PWC->FCG3 = fcg3;

		CM_PWC->FCG0PC = 0xA5A50000;	// DISABLE_FCG0_REG_WRITE();

    /* Wait stable after open fcg. */
    timeout = 0ul;
    do
    {
        timeout++;
    }while(timeout < 0x200);
	
	SysTick->CTRL = 0x00000000;
	SysTick->LOAD = 0x00FFFFFF;
	SysTick->VAL  = 0x00000000;
	SysTick->CTRL|= 0x00000004;//choose processor clock,200MHz
	CM_PWC->FCG2 &= (~((uint32_t)1<<20));	//	TimerA Unit1 peripheral enable,for Delay timer
	CM_TMRA_1->CNTER = 0;	//	Clear CNTER
	/*
		CKDIV[7:4] = 0,PCLK1:100MHz
		SYNST[3] = 0,Async
		MODE[2] = 0,Saw-tooth mode
		DIR[1] = 1,down count
		BCSTRH.UDFF[7] = 0,clear udff
		BCSTRH.OVSTP[0] = 1,stop count when overflow or underflow
	*/
	CM_TMRA_1->BCSTRL	=	0<<4|0<<3|0<<2|1<<1|0;
	CM_TMRA_1->BCSTRH	=	0|1<<0;
}

void Delay(uint32_t tick)
{
 while(tick--);
}

void Delay_us(uint32_t ticku) //max 83886.08us
{
uint32_t prdu;
	while(ticku>500)
	{
		CM_TMRA_1->CNTER = 50000; // 500us
		CM_TMRA_1->BCSTRL = 1;// START[0]=1,start tmr_A1
		while((CM_TMRA_1->BCSTRH&0x80)==0);
		CM_TMRA_1->BCSTRH &= 0x7F; // clear udff
		ticku -= 500;
	}
	prdu=(100*ticku);
	CM_TMRA_1->CNTER = prdu;
	CM_TMRA_1->BCSTRL = 1;// START[0]=1,start tmr_A1
	while((CM_TMRA_1->BCSTRH&0x80)==0);
	CM_TMRA_1->BCSTRH &= 0x7F; // clear udff
}

void Delay_ms(uint32_t tickm)//max 83.88608ms
{
uint32_t prdm;
	prdm = tickm*2;
	while(prdm>0)
	{
		CM_TMRA_1->CNTER = 50000;//500us
		CM_TMRA_1->BCSTRL = 1;// START[0]=1,start tmr_A1
		while((CM_TMRA_1->BCSTRH&0x80)==0);
		CM_TMRA_1->BCSTRH &= 0x7F; // clear udff
		prdm--;
	}
}
