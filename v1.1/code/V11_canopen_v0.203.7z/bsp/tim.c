#include "bsp.h"
#include <math.h>

#define Dead_Time 80
void PWM_Init(void)
{
	 /******* PWM GPIO Configuration    
    PB13     ------> TIM4_1_OUL
    PB14     ------> TIM4_1_OVL
    PB15     ------> TIM4_1_OWL
    PA8      ------> TIM4_1_OUH,FUNC2
    PA9      ------> TIM4_1_OVH
    PA10     ------> TIM4_1_OWH
   ********************************/
	CM_PWC->FCG2 &= (~(uint32_t)(1<<9));	//	Timer4 Unit1 peripheral enable
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	CM_GPIO->PFSRA8		=	2;	//	TIM4_1_OUH
	CM_GPIO->PFSRA9		=	2;	//	TIM4_1_OVH
	CM_GPIO->PFSRA10	=	2;	//	TIM4_1_OWH
	CM_GPIO->PFSRB13	=	2;	//	TIM4_1_OUL
	CM_GPIO->PFSRB14	=	2;	//	TIM4_1_OVL
	CM_GPIO->PFSRB15	=	2;	//	TIM4_1_OWL	
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock
	/*	TIM4 unit config	*/
	/*	buffer: 
		CPSR,CCSR.BUFFEN=0, Disable buffer
		[OCCR,OCMR],OCER.CxBUFEN = 0b01(underflow),OCER.LMCx=0
		[SCCR,SCMR],SCSR.BUFEN=0x0b01(underflow),SCSR.LMCx=0
	*/
	/***** CCSR register config
		ECKEN[15]=0,Inner PCLK0
		HST[13]=0,Hard start disble
		BUFEN[7]=0,CPSR buffer disable,period
		STOP[6]=1,still stop timer
		MODE[5]=1,Triangular Mode
		CLEAR[4]=1,Clear counter
		CKDIV[3:0]=0,counter clock is PCLK0=200MHz
	*/
	CM_TMR4_1->CCSR = 0<<15|0<<13|0<<7|1<<6|1<<5|1<<4|0;
	CM_TMR4_1->CVPR = 0;
	CM_TMR4_1->CPSR = 5000;//Set TMR4 period
	
	/* Set output polarity when OC is disabled. */
	CM_TMR4_1->OCSRU = 0xFF00;
	CM_TMR4_1->OCSRV = 0xFF00;
	CM_TMR4_1->OCSRW = 0xFF00;

	/* Set OCMR&&OCCR buffer function */
	/*
		MLBUFEN[7:6]=0,directly write to OCMR*L
		CLBUFEN[3:2]=2,write to OCCR*L when overflow
		other ignore
	*/
	CM_TMR4_1->OCERU = 0<<6|2<<2;
	CM_TMR4_1->OCERV = 0<<6|2<<2;
	CM_TMR4_1->OCERW = 0<<6|2<<2;
	/* Set OC compare value */
	CM_TMR4_1->OCCRUL = 2500;
	CM_TMR4_1->OCCRVL = 2500;
	CM_TMR4_1->OCCRWL = 2500;
	/* complementary */
	/*
		POCR.PWMMD=01,In this mode,OCCR*L generate in_op*L,TIM4_1_O*H = in_po*L,TIM4_1_O*L = !in_po*L
	*/
	/*
	EOPNZRL[31:30]=00,in_op*L keep,if(underflow,counter≠occr*l,counter=occr*h)
	EOPNPKL[29:28]=00,in_op*L keep,if(overflow,counter≠occr*l,counter=occr*h)
	EOPZRL[27:26]=00,in_op*L keep,if(underflow,counter=occr*l,counter=occr*h)
	EOPUCL[25:24]=11,in_op*L toggle,if(up count,counter=occr*l,counter=occr*h)
	EOPPKL[23:22]=00,in_op*L keep,if(overflow,counter=occr*l,counter=occr*h)
	EOPDCL[21:20]=11,in_op*L toggle,if(down count,counter=occr*l,counter=occr*h)
	EOPNUCL[19:18]=00,in_op*L keep,if(up count,counter≠occr*l,counter=occr*h)
	EOPNDCL[17:16]=00,in_op*L keep,if(down count,counter≠occr*l,counter=occr*h)
	
	OPNZRL[15:14]=00,in_op*L keep,if(underflow,counter≠occr*l,counter≠occr*h)
	OPNPKL[13:12]=00,in_op*L keep,if(overflow,counter≠occr*l,counter≠occr*h)
	OPZRL[11:10]=00,in_op*L keep,if(underflow,counter=occr*l,counter≠occr*h)
	OPUCL[9:8]=11,in_op*L toggle,if(up count,counter=occr*l,counter≠occr*h)
	OPPKL[7:6]=00,in_op*L keep,if(overflow,counter=occr*l,counter≠occr*h)
	OPDCL[5:4]=11,in_op*L toggle,if(down count,counter=occr*l,counter≠occr*h)
		//till now,the timer works in independent mode
	OCFZRL[3]=1,OCSR.OCFL set,if(underflow,counter=occr*l)
	OCFUCL[2]=1,OCSR.OCFL set,if(up count,counter=occr*l)
	OCFPKL[1]=1,OCSR.OCFL set,if(overflow,counter=occr*l)
	OCFDCL[0]=1,OCSR.OCFL set,if(down count,counter=occr*l)
	*/
	CM_TMR4_1->OCMRLUL = 0x0330033F;
	CM_TMR4_1->OCMRLVL = 0x0330033F;
	CM_TMR4_1->OCMRLWL = 0x0330033F;
	/* TMR4 OC low channel: enable */
	CM_TMR4_1->OCSRU |= 0xFF02;// OCEL[1]=1,compare out enable,the in_op*l state is decided by OCMR*L and OCFL[7]
	CM_TMR4_1->OCSRV |= 0xFF02;
	CM_TMR4_1->OCSRW |= 0xFF02;
	/************************* Configure TMR4 PWM *****************************/
	/*
		LVLS[7:6]=00,PWM output polarity both keep
		PWMMD[5:4]=01,PWM output mode 0:passthough 1:deadtime 2:deadtime with filter 3:not allowed
		DIVCK[2:0]=00,fitler and deadtime clock divider 0:pclk1(100MHz) 1:/2 2:/4...
	*/
	CM_TMR4_1->POCRU = 0<<6|1<<4|0;
	CM_TMR4_1->POCRV = 0<<6|1<<4|0;
	CM_TMR4_1->POCRW = 0<<6|1<<4|0;
	CM_TMR4_1->RCSR = 0;
	
	/* TMR4 PWM: set dead time count */
	CM_TMR4_1->PDARU = Dead_Time;//400ns,falling edge
	CM_TMR4_1->PDARV = Dead_Time;
	CM_TMR4_1->PDARW = Dead_Time;
	CM_TMR4_1->PDBRU = Dead_Time;//400ns,rising edge
	CM_TMR4_1->PDBRV = Dead_Time;
	CM_TMR4_1->PDBRW = Dead_Time;
	/* TMR4 PWM: set port output normal 
	ODT[11:10]=0,Imdiately active
	OEXL[7],OEWL[5],OEVL[3],OEUL[1]=1,
	OEXH[6],OEWH[4],OEVH[2],OEUH[0]=1,Output enable
	*/
	CM_TMR4_1->PSCR = 0x555502FF;
	/*	Config TMR4_1_INTENSAD interrupt to trigger ADC	*/
	CM_TMR4_1->SCCRUL	=	120; // Trigger ADC Sampling,Delay is 600ns,5ns/LSB
	CM_TMR4_1->SCMRUL = 0xFF00;//disable period interval response
	
	/*
		UEN[14]=1,UP count,EVTMS=0 & SCCR compare math & SCMR match,EVT active
		EVTMS[8]=0,immediately output
		LMC[5]=0,periodly interval respose link inactive
		EVTOS[4:2]=0,special event 0 output actively
		BUFEN[1:0]=0,SCCR,SCMR write directly
	*/
	CM_TMR4_1->SCSRUL = 1<<12|0<<8|0<<5|0<<2|0;
	/*	Config TMR61_UDFF interrupt to trigger SPI,read angle	*/
	CM_TMR4_1->CCSR	|=	1<<10; // IRQZEN[10]=1,Enable underflow interrupt
	CM_INTC->INTSEL1	=	INT_SRC_TMR4_1_UDF;	// TMR4_1_UDF
	NVIC_SetPriority(TIM41_IRQn, 1);	//Default Priority for IRQ, Possible values are 0 (high priority) to 15 (low priority)
	NVIC_ClearPendingIRQ(TIM41_IRQn);
	NVIC_EnableIRQ(TIM41_IRQn);
	
	/* TMR4 PWM: enable main output  */
	CM_TMR4_1->PSCR |= 1<<8;
	CM_TMR4_1->CCSR	&=	0xFFBF;	//	STOP[6]=0,start TIMER 4 uint 1
}

__RAM_FUNC void Timer01_Init(void)
{
	CM_PWC->FCG2 &= ~PWC_FCG2_TMR0_2;
	
	// PCLK1 = 100Mhz
	
//	CM_PWC->FCG2 &= ~PWC_FCG2_TMR0_1;
//	
//	// PCLK1 = 100Mhz
//	CM_TMR0_1->BCONR = 0x40450000;
//	CM_TMR0_1->CMPBR = 0x0000186A;
	
	CM_INTC->INTSEL8	=	INT_SRC_TMR0_1_CMP_B;
	NVIC_SetPriority(TIM01B_IRQn, 1);	//Default Priority for IRQ, Possible values are 0 (high priority) to 15 (low priority)
	NVIC_ClearPendingIRQ(TIM01B_IRQn);
	NVIC_EnableIRQ(TIM01B_IRQn);
	
	
	CM_TMR0_2->BCONR = 0x40454045;
	CM_TMR0_2->CMPAR = 0x0000186A;
	CM_TMR0_2->CMPBR = 0x0000186A;
	
	CM_INTC->INTSEL5	=	INT_SRC_TMR0_2_CMP_A;
	NVIC_SetPriority(TIM02A_IRQn, 5);	//Default Priority for IRQ, Possible values are 0 (high priority) to 15 (low priority)
	NVIC_ClearPendingIRQ(TIM02A_IRQn);
	NVIC_EnableIRQ(TIM02A_IRQn);
	
	CM_INTC->INTSEL6	=	INT_SRC_TMR0_2_CMP_B;
	NVIC_SetPriority(TIM02B_IRQn, 5);	//Default Priority for IRQ, Possible values are 0 (high priority) to 15 (low priority)
	NVIC_ClearPendingIRQ(TIM02B_IRQn);
	NVIC_EnableIRQ(TIM02B_IRQn);
	
}

__RAM_FUNC void SVPWM(float ual,float ube)
{
volatile  uint16_t Vec,duty_int;
	float tmp1,tmp2,tmp3;
volatile	float Tu,Tv,Tw;
	/* Disk jugement */
	tmp1=ube;
	tmp2=0.8660254037844f*ual+0.5f*ube;
	tmp3=tmp2-tmp1;
  Vec=(tmp2 > 0.0f)?2:3;
  Vec=(tmp3 > 0.0f)?( Vec-1):Vec;
  Vec=(tmp1 < 0.0f)?(7-Vec) :Vec;

	switch(Vec)
	{
		case 1:
		case 4:
           Tu=tmp2;Tv=tmp1-tmp3;Tw=-tmp2;break;
    case 2:
    case 5:
           Tu=tmp3+tmp2;Tv=tmp1;Tw=-tmp1;break;
    case 3:
    case 6:
           Tu=tmp3;Tv=-tmp3;Tw=-(tmp1+tmp2);break;
    default: Tu=0.0f;Tv=0.0f;Tw=0.0f;break;
	}
	/* PWM Output */
	duty_int=(uint16_t)((1.0f-Tw)*2500.0f);//PHASE_W
	CM_TMR4_1->OCCRWL = duty_int;
	
	duty_int=(uint16_t)((1.0f-Tv)*2500.0f);//PHASE_V
	CM_TMR4_1->OCCRVL = duty_int;
	
	duty_int=(uint16_t)((1.0f-Tu)*2500.0f);//PHASE_U
	CM_TMR4_1->OCCRUL = duty_int;
}

void sing(void)
{
float freq[8]={783.99f,587.33f,659.25f,659.25f,532.25f,659.25f,532.25f,698.46f};
uint16_t lasttime[8]={150,150,150,150,150,150,150,150};
float volume_array[8]={0.02f,0.02f,0.02f,0.02f,0.02f,0.02f,0.02f,0.02f};
float volume=0.0f;
uint16_t i,j;

	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	CM_GPIO->PORRB				 |= (1<<13|1<<14|1<<15);	//  PB13,14,15 	= 0
	CM_GPIO->PORRA				 |= (1<<8 |1<<9 |1<<10);	//  PA 8, 9,10	= 0
	/* 
		DDIS[15]=0,Enable Digital function
		DRV[4]=1,Mid level drive strength
		POUTE[1]=1,Enable output
	*/
	CM_GPIO->PCRA8 	= 0<<15|1<<4|1<<1;
	CM_GPIO->PCRA9 	= 0<<15|1<<4|1<<1;
	CM_GPIO->PCRA10 = 0<<15|1<<4|1<<1;
	CM_GPIO->PCRB13 = 0<<15|1<<4|1<<1;
	CM_GPIO->PCRB14 = 0<<15|1<<4|1<<1;
	CM_GPIO->PCRB15 = 0<<15|1<<4|1<<1;
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock
	CM_GPIO->POSRB = 0x4000;//SET PB14,OPEN V_L
	for(j=0;j<7;j++)
	for(i=0;i<lasttime[j];i++)
	{
		CM_GPIO->PORRB = 0x2000;//CLOSE U_L
		Delay(100);
		CM_GPIO->POSRA = 0x0100;//SET PA8,OPEN U_H
	  SysTick->LOAD =(uint32_t)(2.0e8f*volume_array[j]/freq[j]);
		SysTick->VAL=0;
	  SysTick->CTRL |= 0x00000001;//enable systick timer
		while(((SysTick->CTRL)&0x00010000)==0);
		SysTick->CTRL &= 0xFFFEFFFE;//Disable systick timer and clear countflag
		CM_GPIO->PORRA = 0x0100;//CLOSE U_H
		Delay(100);
		CM_GPIO->POSRB = 0x2000;//OPEN U_L
		SysTick->LOAD=(uint32_t)(2.0e8f*(1.0f-volume_array[j])/freq[j]);
		SysTick->VAL=0;
		SysTick->CTRL |= 0x00000001;//enable systick timer
		while(((SysTick->CTRL)&0x00010000)==0);
		SysTick->CTRL &= 0xFFFEFFFE;//Disable systick timer and clear countflag
	}
	volume=volume_array[7];
	for(i=0;i<1000;i++)
	{
		CM_GPIO->PORRB = 0x2000;//CLOSE U_L
		Delay(100);
		CM_GPIO->POSRA = 0x0100;//SET PA8,OPEN U_H
	  SysTick->LOAD =(uint32_t)(2.0e8f*volume/freq[7]);
		SysTick->VAL=0;
	  SysTick->CTRL |= 0x00000001;//enable systick timer
		while(((SysTick->CTRL)&0x00010000)==0);
		SysTick->CTRL &= 0xFFFEFFFE;//Disable systick timer and clear countflag
		CM_GPIO->PORRA = 0x0100;//CLOSE U_H
		Delay(100);
		CM_GPIO->POSRB = 0x2000;//OPEN U_L
		SysTick->LOAD=(uint32_t)(2.0e8f*(1.0f-volume)/freq[7]);
		SysTick->VAL=0;
		SysTick->CTRL |= 0x00000001;//enable systick timer
		while(((SysTick->CTRL)&0x00010000)==0);
		SysTick->CTRL &= 0xFFFEFFFE;//Disable systick timer and clear countflag
		volume=volume*exp(-0.00001*i);
	}
	Delay(20000);
	CM_GPIO->PORRB = 0x2000;//CLOSE PB13,OPEN U_L
	CM_GPIO->PORRB = 0x4000;//CLOSE V_L
}
