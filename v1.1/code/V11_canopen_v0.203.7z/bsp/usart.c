#include "bsp.h"
#include "stdio.h"

#if 1                          
//struct __FILE 
//{ 
//	int handle; 
//}; 

//FILE __stdout;

int fputc(int ch, FILE *f)
{ 
	while((CM_USART1->SR&0x00000080) == 0) //TXE[7]=0, TDR is not empty
		;	//TX is full 
	CM_USART1->TDR = (uint8_t) ch;
	return ch;
}
#endif

/* TIM0 init function */
void TIM0_Init(void)
{
	CM_PWC->FCG2 &= (~((uint32_t)1<<12));	//	Timer0 Unit1 peripheral enable,for USART1 timeout(CHA)
	CM_TMR0_1->CNTAR = 0;	//	Clear CNTAR register for CHA
	/*
		HICPA[15]=0,inner hardware trig don't active input capture
		HCLEA[14]=1,inner hardware trig to clear timer
		HSTPA[13]=0,inner hardware trig don't stop timer
		HSTAA[12]=1,inner hardware trig to start timer
		ASYNCLKA[10]=1, when usart1 timeout is active,then the clk is supplied by usart1
		SYNCLKA[9]=0,PCLK1
		SYNSA[8]=1,asynchronous count mode
		CKDIVA[7:4]=3, ck source/8,alph=3
		CAPMDA[1]=0,input capture
		CSTA[0]=0,close CHA timer
	*/
	CM_TMR0_1->BCONR	=	0<<15|1<<14|0<<13|1<<12|1<<10|1<<8|3<<4|0;
	CM_TMR0_1->CMPAR	=	100;	//	set timer compare value
	CM_TMR0_1->STFLR	=	0;		//	TIMER0_ClearFlag
}

uint8_t RXD_BUF[RCV_LEN];
void USART1_Init(uint32_t baud)
{
	  /**USART1 GPIO Configuration    
    PA11     ------> USART1_TX
    PA12     ------> USART1_RX 
    */
	uint32_t OVER8 = 0ul;
	float DIV = 0.0f;
	uint64_t u64Tmp = 0;
	uint32_t DIV_Integer = 0;
	uint32_t DIV_Fraction = 0xFFFFFFFF;
	
	TIM0_Init();

	CM_PWC->FCG3 &= (~(1<<20));	//	Enable USART1 Clock
	CM_GPIO->PWPR = 0xA501;	//	Port_Unlock
	CM_GPIO->PFSRA11	=	32;	//	USART1_TX
	CM_GPIO->PFSRA12	=	33;	//	USART1_RX
	CM_GPIO->PWPR = 0xA500;	//	Port_Lock
	
	/* Set default value */
	CM_USART1->CR1 	= (uint32_t)0x801B0000;
	CM_USART1->CR2 	= (uint32_t)0x00000000;
	CM_USART1->CR3 	= (uint32_t)0x00000000;
	CM_USART1->BRR 	= (uint32_t)0x0000FFFF;
	CM_USART1->PR 	= (uint32_t)0x00000000;

	/* Set USART mode */
	CM_USART1->CR3 &= 0xFFFFFFDF;	//	SCEN[5]=0,Disable Smart-Card
	CM_USART1->PR = 0;	//	fuart=PCLK1=100MHz
	/*
			SBS[31]=1,Dected falling edge as start.
			ML[28]=0,LSB
			MS[24]=0,UART mode
			OVER8[15]=0,16 bit sampling
			M[12]=0,8bit data length
			PCE[10]=0,no parity
	*/
	CM_USART1->CR1 = (uint32_t)1<<31|0<<28|0<<24|0<<15|0<<12|0<<10;
	/*
		STOP[13] = 0,			1 stop bit
		CLKC[12:11] = 1,	inner clock,output
	*/
	CM_USART1->CR2 = 0<<13|1<<11;
	/*
		CTSE[9] = 0,Disable CTSE
		RTSE[8] = 0,Disable RTSE
	*/
	CM_USART1->CR3 = 0<<9|0<<8;
	
	/* Set Baudrate */
		OVER8 = (CM_USART1->CR1&0x00008000)>>15;
		/* FBME = 0 Calculation formula */
		/* B = C / (8 * (2 - OVER8) * (DIV_Integer + 1)) */
		/* DIV_Integer = (C / (B * 8 * (2 - OVER8))) - 1 */
		DIV = 100000000.0f / ((float)baud * 8.0f * (2.0f - (float)OVER8)) - 1.0f;
		DIV_Integer = (uint32_t)(DIV);

		if (!((DIV < 0.0f) || (DIV_Integer > 0xFF)))
		{
				if ((DIV - (float)DIV_Integer) > 0.00001f)
				{
				/* FBME = 1 Calculation formula */
				/* B = C * (128 + DIV_Fraction) / (8 * (2 - OVER8) * (DIV_Integer + 1) * 256) */
				/* DIV_Fraction = ((8 * (2 - OVER8) * (DIV_Integer + 1) * 256 * B) / C) - 128 */
				/* E = (C * (128 + DIV_Fraction) / (8 * (2 - OVER8) * (DIV_Integer + 1) * 256 * B)) - 1 */
				/* DIV_Fraction = (((2 - OVER8) * (DIV_Integer + 1) * 2048 * B) / C) - 128 */
				u64Tmp = (uint64_t)(((uint64_t)2 - (uint64_t)OVER8) * ((uint64_t)DIV_Integer + 1) * (uint64_t)baud);
				DIV_Fraction = (uint32_t)(2048 * u64Tmp / 100000000.0f - 128);
				CM_USART1->CR1 |= (DIV_Fraction > 0x7F) ? 0 : 0x20000000;//FBME[29]
				/*
					DIV_Integer[15:8]
					DIV_Fraction[6:0]
				*/
				CM_USART1->BRR = DIV_Integer<<8|DIV_Fraction;
				}
		}
		
/*************** DMA Config	***************/
	CM_PWC->FCG0PC = 0xA5A50001;	//	ENABLE_FCG0_REG_WRITE
	CM_PWC->FCG0 &= (~(1<<14));	//	Enable DMA1 Clock
	CM_PWC->FCG0PC = 0xA5A50000;	//	DISABLE_FCG0_REG_WRITE
	CM_DMA1->EN	=	1;	//	Enable DMA1
	/* Initialize DMA. */
	CM_DMA1->CHCTL0	&= 0xFFFFEFFF;	//	IE[12]=0,Disable CH0 interrupt
	CM_DMA1->SAR0	=	(uint32_t)(&CM_USART1->RDR);	//	SAR=USART1.RDR
	CM_DMA1->DAR0	=	(uint32_t)RXD_BUF;						//	DAR=buf
	/*
		BLKSIZE[9:0]=1,One data one transfer
		CNT[31:16]
	*/
	CM_DMA1->DTCTL0	=	1|RCV_LEN<<16;
	/*
		LLPRUN[11]=0,don't transfer immediately,wait for next transfer,if link transfer enabled
		LLPEN[10]=0,Disable link transfer
		HSIZE[9:8]=0,8 bit length
		DNSEQEN[7]=0,don't allow dest	 add discontinous transfer
		SNSEQEN[6]=0,don't allow source add discontinous transfer
		DRPTEN[5]=0,Disable dest repeat
		SRPTEN[4]=0,Disable source repeat
		DINC[3:2]=1,Dest ADD increase
		SINC[1:0]=0,Source ADD fix
	*/	
	CM_DMA1->CHCTL0 =	0<<11|0<<10|0<<8|0<<7|0<<6|0<<5|0<<4|1<<2|0;
	CM_DMA1->CHEN	=	1;	//	Enable DMA1_CH0
	/* Clear DMA flag. */
	CM_DMA1->INTCLR0	=	0x000F000F;	// clear REQERR,TRNERR flag
	CM_DMA1->INTCLR1	=	0x000F000F;	// clear BTC,TC flag

	CM_PWC->FCG0PC = 0xA5A50001;	//	ENABLE_FCG0_REG_WRITE
	CM_PWC->FCG0 &= (~(1<<17));	//	Enable AOS Clock
	CM_AOS->DMA1_TRGSEL0	=	EVT_SRC_USART1_RI;
	CM_PWC->FCG0PC = 0xA5A50000;	//	DISABLE_FCG0_REG_WRITE	
	/*
		RTOIE[1]=1,Receiver timeout interrupt Enable
		RTOE[0]=1,Receiver timeout Enable
	*/
	CM_USART1->CR1 |= (1<<1|1);
		
	/* Set USART RX timeout error IRQ */
	CM_INTC->INTSEL4	=	INT_SRC_USART1_RTO;	// USART1_RTOI
	NVIC_SetPriority(USART1_IRQn, 4);	//Default Priority for IRQ, Possible values are 0 (high priority) to 15 (low priority)
	NVIC_ClearPendingIRQ(USART1_IRQn);
	NVIC_EnableIRQ(USART1_IRQn);
	
	/*
		TE[3]=1,Transmitter Enable
		RE[2]=1,Receiver Enable
	*/	
	CM_USART1->CR1 |= (1<<3|1<<2);
}

void USART1_send_buf(uint8_t *pbuf,uint16_t data_len)
{
 uint16_t i;
 for(i=0;i<data_len;i++)
	{
		while((CM_USART1->SR&0x00000080) == 0) //TXE[7]=0, TDR is not empty
		;	//TX is full 
		CM_USART1->TDR = *pbuf++; 
	}
}
