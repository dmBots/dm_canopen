#ifndef _CO_APP_H__
#define _CO_APP_H__

#include "bsp.h"
#include "cia402device.h"
extern cia402_axis_t cia402axis;

extern uint16_t status_word;
extern uint16_t control_word;
extern uint16_t al_status;

int canopen_init(void);
void canopen_app(void);
uint8_t canopen_write_clock(uint16_t _year, uint8_t _mon, uint8_t _day, uint8_t _hour, uint8_t _min, uint8_t _sec, uint32_t _ms, uint32_t _Interval_ms);


































#endif

