#include "udefine.h"
#include "stdlib.h"


__RAM_FUNC void foc_volt(float vd_set, float vq_set, float pos)
{
	sincos(pos,&ctrler.Sin,&ctrler.Cos);
	
	/* current PARK Transform */
	ctrler.Ialph =  ctrler.I_U;
	ctrler.Ibeta = (ctrler.I_U+ctrler.I_V*2.0f)*0.57735026918963f;//1/sqrt(3) = 0.57735026918963
	//Idq=I����*e^j(-��)
	ctrler.ID = ctrler.Cos*ctrler.Ialph + ctrler.Sin*ctrler.Ibeta;
	ctrler.IQ = ctrler.Cos*ctrler.Ibeta - ctrler.Sin*ctrler.Ialph;
	
	limit_norm(&vd_set,&vq_set,0.98f);
	
	/* U����=Udq*e^j(��) */
//	ctrler.Ualph	= ctrler.Cos*vd_set - ctrler.Sin*vq_set;
//	ctrler.Ubeta	= ctrler.Sin*vd_set + ctrler.Cos*vq_set;
//	SVPWM(ctrler.Ualph,ctrler.Ubeta);
}

__RAM_FUNC void foc_curr(float id_set, float iq_set, float pos)
{
	sincos(pos,&ctrler.Sin,&ctrler.Cos);
	
	/* current PARK Transform */
	ctrler.Ialph =  ctrler.I_U;
	ctrler.Ibeta = (ctrler.I_U+ctrler.I_V*2.0f)*0.57735026918963f;//1/sqrt(3) = 0.57735026918963
	//Idq=I����*e^j(-��)
	ctrler.ID = ctrler.Cos*ctrler.Ialph + ctrler.Sin*ctrler.Ibeta;
	ctrler.IQ = ctrler.Cos*ctrler.Ibeta - ctrler.Sin*ctrler.Ialph;
	
	ctrler.IQref	= sat_datf(iq_set,-TMP.OC_Value,TMP.OC_Value);
	IDx_Loop.yk 	= ctrler.ID;
	IDx_Loop.ref	= id_set;
	IQx_Loop.yk 	= ctrler.IQ;
	IQx_Loop.ref	= ctrler.IQref;
	CC_CTRL(&IDx_Loop);
	CC_CTRL(&IQx_Loop);
	
	limit_norm(&IDx_Loop.out,&IQx_Loop.out,0.98f);
	
	/* U����=Udq*e^j(��) */
//	ctrler.Ualph	= ctrler.Cos*IDx_Loop.out - ctrler.Sin*IQx_Loop.out;
//	ctrler.Ubeta	= ctrler.Sin*IDx_Loop.out + ctrler.Cos*IQx_Loop.out;
//	SVPWM(ctrler.Ualph,ctrler.Ubeta);
}

__RAM_FUNC void foc_torque(float tor_set, float tor_limit, float pos)
{
	sincos(pos,&ctrler.Sin,&ctrler.Cos);
	
	/* current PARK Transform */
	ctrler.Ialph =  ctrler.I_U;
	ctrler.Ibeta = (ctrler.I_U+ctrler.I_V*2.0f)*0.57735026918963f;//1/sqrt(3) = 0.57735026918963
	//Idq=I����*e^j(-��)
	ctrler.ID = ctrler.Cos*ctrler.Ialph + ctrler.Sin*ctrler.Ibeta;
	ctrler.IQ = ctrler.Cos*ctrler.Ibeta - ctrler.Sin*ctrler.Ialph;
	//torque calc
	MTR.IQF	=	MTR.filt_a*MTR.IQF + MTR.filt_b*ctrler.IQ;
	MTR.Te 	= MTR.KT_Base*MTR.IQF;
	
	if(++ctrler.tick==20)  //1KHz
	{
		MTR.spd_mea = ma.angle*1000;// rad/s
		MTR.v_r	=	MTR.v_r*MTR.filt_a+MTR.spd_mea*MTR.filt_b;
		MTR.v_m = MTR.v_r*MTR.ODG;
		ctrler.tick=0;
		ma.angle=0.0f;
//		FFC.F1K=1;
	}
	
	ctrler.IQref=tor_set/MTR.KT_Base;
	float iq_limit = tor_limit/MTR.KT_Base;
	
	iq_limit = min(iq_limit, TMP.OC_Value);
	
	ctrler.IQref	=	sat_datf(ctrler.IQref, -iq_limit, iq_limit);
	IDx_Loop.yk 	= ctrler.ID;
	IDx_Loop.ref	= 0.0f;
	IQx_Loop.yk 	= ctrler.IQ;
	IQx_Loop.ref	= ctrler.IQref;
	CC_CTRL(&IDx_Loop);
	CC_CTRL(&IQx_Loop);
	
	limit_norm(&IDx_Loop.out,&IQx_Loop.out,0.98f);
	
	/* U����=Udq*e^j(��) */
	ctrler.Ualph	= ctrler.Cos*IDx_Loop.out - ctrler.Sin*IQx_Loop.out;
	ctrler.Ubeta	= ctrler.Sin*IDx_Loop.out + ctrler.Cos*IQx_Loop.out;
	SVPWM(ctrler.Ualph,ctrler.Ubeta);
}

__RAM_FUNC void foc_vel(float vel_set, float tor_set, float pos)
{
	sincos(pos,&ctrler.Sin,&ctrler.Cos);
	
	ctrler.Ialph =  ctrler.I_U;
	ctrler.Ibeta = (ctrler.I_U+ctrler.I_V*2.0f)*0.57735026918963f;//1/sqrt(3) = 0.57735026918963
	//Idq=I����*e^j(-��)
	ctrler.ID = ctrler.Cos*ctrler.Ialph + ctrler.Sin*ctrler.Ibeta;
	ctrler.IQ = ctrler.Cos*ctrler.Ibeta - ctrler.Sin*ctrler.Ialph;
	//torque calc
	MTR.IQF	=	MTR.filt_a*MTR.IQF + MTR.filt_b*ctrler.IQ;
	MTR.Te 	= MTR.KT_Base*MTR.IQF;
	
	if(++ctrler.tick==20)  //1KHz
	{
		MTR.spd_mea = ma.angle*1000;// rad/s
		MTR.v_r	=	MTR.v_r*MTR.filt_a+MTR.spd_mea*MTR.filt_b;
		MTR.v_m = MTR.v_r*MTR.ODG;
		ctrler.tick=0;
		ma.angle=0.0f;
//		FFC.F1K=1;
		
		ctrler.spd_ref=vel_set;	
		ctrler.spd_ref=sat_datf(ctrler.spd_ref,-TMP.MAX_SPD,TMP.MAX_SPD);
		
		MTR.IQF	=	MTR.filt_a*MTR.IQF + MTR.filt_b*ctrler.IQ;
		MTR.Te 	= MTR.KT_Base*MTR.IQF;

		dmc.yk  = MTR.v_r;
		dmc.uk  = ctrler.IQ;
		ESO_upd(&dmc);
		
		SPD_Loop.e_k	=	ctrler.spd_ref - dmc.z[0];
		SPD_Loop.out = SPD_Loop.Kp*SPD_Loop.e_k - dmc.out;
	}
	
	ctrler.IQref	= SPD_Loop.out;
	float iq_set	= tor_set/MTR.KT_Base;
	ctrler.IQref	= sat_datf(ctrler.IQref,-iq_set, iq_set);//-TMP.OC_Value,TMP.OC_Value);
	IDx_Loop.yk 	= ctrler.ID;
	IDx_Loop.ref	= 0.0f;
	IQx_Loop.yk 	= ctrler.IQ;
	IQx_Loop.ref	= ctrler.IQref;
	CC_CTRL(&IDx_Loop);
	CC_CTRL(&IQx_Loop);
	
	limit_norm(&IDx_Loop.out,&IQx_Loop.out,0.98f);
	
	/* U����=Udq*e^j(��) */
//	ctrler.Ualph	= ctrler.Cos*IDx_Loop.out - ctrler.Sin*IQx_Loop.out;
//	ctrler.Ubeta	= ctrler.Sin*IDx_Loop.out + ctrler.Cos*IQx_Loop.out;
//	SVPWM(ctrler.Ualph,ctrler.Ubeta);
}

__RAM_FUNC void foc_pos(float pos_set, float vel_set, float tor_set, float pos)
{
	sincos(pos,&ctrler.Sin,&ctrler.Cos);
	
	ctrler.Ialph =  ctrler.I_U;
	ctrler.Ibeta = (ctrler.I_U+ctrler.I_V*2.0f)*0.57735026918963f;//1/sqrt(3) = 0.57735026918963
	//Idq=I����*e^j(-��)
	ctrler.ID = ctrler.Cos*ctrler.Ialph + ctrler.Sin*ctrler.Ibeta;
	ctrler.IQ = ctrler.Cos*ctrler.Ibeta - ctrler.Sin*ctrler.Ialph;
	//torque calc
	MTR.IQF	=	MTR.filt_a*MTR.IQF + MTR.filt_b*ctrler.IQ;
	MTR.Te 	= MTR.KT_Base*MTR.IQF;
	
	if(++ctrler.tick==20)  //1KHz
	{
		MTR.spd_mea = ma.angle*1000;// rad/s
		MTR.v_r	=	MTR.v_r*MTR.filt_a+MTR.spd_mea*MTR.filt_b;
		MTR.v_m = MTR.v_r*MTR.ODG;
		ctrler.tick=0;
		ma.angle=0.0f;
//		FFC.F1K=1;
		
		ctrler.Pref = pos_set;
		POS_Loop.e_k = ctrler.Pref - MTR.p_m;
		POS_Loop.out = POS_Loop.Kp*POS_Loop.e_k;
		
		ctrler.spd_ref=POS_Loop.out;	
		ctrler.spd_ref=sat_datf(ctrler.spd_ref,-vel_set,vel_set);
		ctrler.spd_tar= ctrler.spd_ref;
//		ctrler.spd_diff = ctrler.spd_ref - ctrler.spd_tar;
//		if(ctrler.spd_diff>TMP.ACC)
//				ctrler.spd_tar += TMP.ACC;
//		else if(ctrler.spd_diff<TMP.DEC)
//				ctrler.spd_tar += TMP.DEC;
//		else ctrler.spd_tar= ctrler.spd_ref;
		
		MTR.IQF	=	MTR.filt_a*MTR.IQF + MTR.filt_b*ctrler.IQ;
		MTR.Te 	= MTR.KT_Base*MTR.IQF;

		dmc.yk  = MTR.v_r;
		dmc.uk  = ctrler.IQ;
		ESO_upd(&dmc);
		
		SPD_Loop.e_k	=	ctrler.spd_tar - dmc.z[0];
		SPD_Loop.out = SPD_Loop.Kp*SPD_Loop.e_k - dmc.out;
	}
	
	ctrler.IQref	= SPD_Loop.out;
	float iq_set	= tor_set/MTR.KT_Base;
	ctrler.IQref	= sat_datf(ctrler.IQref,-iq_set, iq_set);//-TMP.OC_Value,TMP.OC_Value);
	ctrler.IQref	= sat_datf(ctrler.IQref,-iq_set,iq_set);//-TMP.OC_Value,TMP.OC_Value);
	IDx_Loop.yk 	= ctrler.ID;
	IDx_Loop.ref	= 0.0f;
	IQx_Loop.yk 	= ctrler.IQ;
	IQx_Loop.ref	= ctrler.IQref;
	CC_CTRL(&IDx_Loop);
	CC_CTRL(&IQx_Loop);
	
	limit_norm(&IDx_Loop.out,&IQx_Loop.out,0.98f);
	
	/* U����=Udq*e^j(��) */
//	ctrler.Ualph	= ctrler.Cos*IDx_Loop.out - ctrler.Sin*IQx_Loop.out;
//	ctrler.Ubeta	= ctrler.Sin*IDx_Loop.out + ctrler.Cos*IQx_Loop.out;
//	SVPWM(ctrler.Ualph,ctrler.Ubeta);
}




















