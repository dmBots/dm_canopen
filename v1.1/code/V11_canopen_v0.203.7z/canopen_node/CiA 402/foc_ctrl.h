#ifndef __FOC_CTRL_H_
#define __FOC_CTRL_H_


#include "hc32f448.h"


void foc_volt(float vd_set, float vq_set, float pos);
void foc_curr(float id_set, float iq_set, float pos);
void foc_torque(float tor_set, float tor_limit, float pos);
void foc_vel(float vel_set, float tor_set, float pos);
void foc_pos(float pos_set, float vel_set, float tor_set, float pos);




#endif

