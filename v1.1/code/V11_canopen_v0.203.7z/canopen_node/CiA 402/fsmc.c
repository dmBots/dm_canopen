#include "fsmc.h"
#include "udefine.h"
#include "stdlib.h"
#include "fsmc.h"
#include "co_app.h"
#include "foc_ctrl.h"
#include "api_mode.h"
#include "OD.h"

uint32_t time = 0;
uint32_t flagg = 1;
__RAM_FUNC void fsmc_loop(void)
{
    switch (cia402axis.state)
    {
		case NOT_READY_TO_SWITCH_ON:
		{

		} break;

		case SWITCH_ON_DISABLED:
		{
			al_status = 0;
//			MTR.state = REST_MODE;
			flag.qs = 1;
			flag.fault = 1;
		}
		break;

		case READY_TO_SWITCH_ON:
		{
			al_status = 0;
//			MTR.state = REST_MODE;
		}
		break;

		case SWITCHED_ON:
		{
			al_status = 0;
//			MTR.state = REST_MODE;
		}
		break;

		case OPERATION_ENABLED:
		{
			al_status = AL_STATUS_OP;
			mode_ctrl();
		}
		break;

		case QUICK_STOP_ACTIVE:
		{
			al_status = AL_STATUS_OP;	
			profile_qs_stop();	
		}
		break;

		case FAULT_REACTION_ACTIVE:
		{
			al_status = AL_STATUS_OP;
			profile_fault_stop();
		}
		break;

		case FAULT:
		{
			al_status = 1;
//			MTR.state = REST_MODE;
			if(control_word == 0x80)
			{
				FFC.rst = 0;// clear fault
				FFC.com = 0;
				al_status = 0;
				ctrler.ERR_STATE = 0;
				OD_RAM.x603F_errorCode = 0;
				MTR.state = REST_MODE;
				MTR.st_change = 1;
			}
			
	//			printf("FAULT \r\n");
		}
		break;
    }
}

__RAM_FUNC void mode_ctrl(void)
{
    switch(ctrler.CTRL_MODE)
    {
		case tor_mode:
			profile_tor_mode();
			break;
		case vel_mode:
			profile_vel_mode();
			break;
		case pos_mode:
			profile_pos_mode();
			break;
		case hom_mode:
			break;
		default:
			break;
    }
}

