#ifndef _FSMC_H__
#define _FSMC_H__

#include "bsp.h"

#include <stdio.h>
#include <stdbool.h>


typedef enum
{
	pos_mode = 1,
	vel_mode = 3,
    tor_mode = 4,
    hom_mode = 6,

//	cyc_pos_mode,
//	cyc_vel_mode,
//	cyc_tor_mode,

    /* test mode */
//	dragvf_mode,
//	dragif_mode,
//	volt_mode,

} mode_e;

void fsmc_loop(void);
void mode_ctrl(void);


#endif






