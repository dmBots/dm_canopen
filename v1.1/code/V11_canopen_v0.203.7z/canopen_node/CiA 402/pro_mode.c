#include "fsmc.h"
#include "udefine.h"
#include "stdlib.h"
#include "fsmc.h"
#include "co_app.h"
#include "foc_ctrl.h"
#include "pro_mode.h"
#include "api_mode.h"
#include "OD.h"

in_para_t pin;
out_para_t pout;
mid_para_t mid;
flag_t flag;

float tor_diff;
float tor_limit;
float tor_win = 0.01f;
uint8_t tar_reached;
float vel_ref_last; 
float pos_ref_last = 0.0f; 
float zero_win = 0.5f;

void pro_mode_init(void)
{
	pin.tor_ref = &com_od.x6071_tor_ref.f_val;
	pin.vel_ref = &com_od.x60FF_vel_ref.f_val;
	pin.pos_ref = &com_od.x607A_pos_ref.f_val;
	
	pin.curve	 = &OD_RAM.x6086_motionProfileType;
	pin.tor_ramp = &com_od.x6087_tor_ramp.f_val;
	pin.vel_acc  = &com_od.x6083_vel_acc.f_val;
	pin.vel_dec  = &com_od.x6084_vel_dec.f_val;
	pin.qs_dec	 = &com_od.x6085_qs_dec.f_val;
	
	pout.state_word = &OD_RAM.x6041_statusword;
	pout.tor_act = &MTR.Te;
	pout.vel_act = &MTR.v_m;
	pout.pos_act = &MTR.p_m;
	pout.pos_follow_err = &com_od.x60F4_follow_err_value.f_val;
	
	pout.target_reached = &tar_reached;
	
	mid.spd_max = &com_od.x6080_spd_max.f_val;
	mid.tor_max = &com_od.x6072_tor_max.f_val;
	
	mid.tor_step = &tor_limit;//(float *)malloc(sizeof(float));
	mid.tor_set =  &tor_diff;
	
	mid.tor_win = &tor_win;
	mid.vel_win = &com_od.x606D_vel_win.f_val;
	mid.pos_win = &com_od.x6067_pos_win.f_val;
	mid.zero_vel = &com_od.x606F_zero_vel_win.f_val;
	mid.vel_time_win = &com_od.x606E_vel_win_time.f_val;
	mid.pos_time_win = &com_od.x6068_pos_win_time.f_val;
	mid.pos_max_win  = &com_od.x6065_follow_err_win.f_val;
	
	mid.vel_ref_last = &vel_ref_last;
	mid.vel_ref_last = &vel_ref_last;
	mid.pos_ref_last = &pos_ref_last;
	
	mid.dec_mode	= &OD_RAM.x605A_quickStopOptionCode;
}


__RAM_FUNC void profile_tor_mode(void)
{
	sat_datf(*pin.vel_ref, -*mid.spd_max, *mid.spd_max);
	sat_datf(*pin.tor_ref, -*mid.tor_max, *mid.tor_max);
	
	*mid.tor_set = (*pin.vel_ref - *pout.vel_act);
	
	if (*pin.tor_ref > *mid.tor_step)
	{
		*mid.tor_step += *pin.tor_ramp*CURRENT_MEASURE_PERIOD;
		if (*mid.tor_step > *pin.tor_ref)
			*mid.tor_step = *pin.tor_ref;
	}
	else if (*pin.tor_ref < *mid.tor_step)
	{
		*mid.tor_step -= *pin.tor_ramp*CURRENT_MEASURE_PERIOD;
		if (*mid.tor_step < *pin.tor_ref)
			*mid.tor_step = *pin.tor_ref;
	}
	
	api_tor_mode(*mid.tor_set, *mid.tor_step);
	
	if (fabs(*pout.tor_act - *pin.tor_ref) < *mid.tor_win) 
	{
		*pout.target_reached = 1;
		*pout.state_word |= 1<<10;
	}
	else 
	{
		*pout.target_reached = 0;
		*pout.state_word |= 0<<10;
	}
	
}


__RAM_FUNC void profile_vel_mode(void)
{
	if(*pin.vel_ref != *mid.vel_ref_last)
	{
		spd_traj_plan(	*pout.vel_act,	// satrt velocity
						*pin.vel_ref, 	// target velocity
						*pin.vel_acc,   // acceleration
						*pin.vel_dec, 	// deceleration
						*pin.curve);   		// curve
		*pout.target_reached = 0;
		*mid.vel_ref_last = *pin.vel_ref;
	}
	spd_traj_eval();
	
	api_vel_mode(Traj.spd_step, *pin.tor_ref);
	
	if (fabs(*pout.vel_act - *pin.vel_ref) < *mid.vel_win)
	{
		if(Traj.tick * 0.00005f - Traj.t_total < *mid.vel_time_win) 
		{
			*pout.target_reached = 1;
			*pout.state_word |= 1<<10;
		}
	}
	else 
	{
		*pout.target_reached = 0;
		*pout.state_word |= 0<<10;
	}
	if(fabs(*pout.vel_act - 0) < *mid.zero_vel)
		*pout.state_word |= 1<<12;
	else
		*pout.state_word |= 0<<12;
}



__RAM_FUNC void profile_pos_mode(void)
{
	if(*pin.pos_ref != *mid.pos_ref_last)
	{
		pos_traj_plan(	*pout.pos_act,	// start pos
						*pin.pos_ref,	// target pos
						*pout.vel_act,	// satrt velocity
						*pin.vel_ref, 	// target velocity
						*pin.vel_acc,   // acceleration
						*pin.vel_dec, 	// deceleration
						*pin.curve);   		// curve
		*pout.target_reached = 0;
		*mid.pos_ref_last = *pin.pos_ref;
	}
	pos_traj_eval();
	
	api_pos_mode(Traj.pos_step, *pin.vel_ref, *pin.tor_ref);
	
	*pout.pos_follow_err = fabs(*pout.pos_act - *pin.pos_ref);
	
	if (fabs(*pout.pos_act - *pin.pos_ref) < *mid.pos_win) 
	{
		if(Traj.tick * 0.00005f - Traj.t_total < *mid.pos_time_win) 
		{
			*pout.target_reached = 1;
			*pout.state_word |= 1<<10;
		}
	}
	else 
	{
		*pout.target_reached = 0;
		*pout.state_word |= 0<<10;
	}
	
	if (fabs(*pout.pos_act - *pin.pos_ref) > *mid.pos_max_win) 
	{
		if((Traj.tick * 0.00005f) > (Traj.t_total + *mid.pos_time_win)) 
			*pout.err = 1;
	}
}

__RAM_FUNC void profile_qs_stop(void)
{
	float dec = 0;
	static float pos_ref;
	if((*mid.dec_mode == 1) || (*mid.dec_mode == 3))
		dec = *pin.vel_dec;
	if((*mid.dec_mode == 2) || (*mid.dec_mode == 4))
		dec = *pin.qs_dec;
	*pin.vel_ref = 0;
	if(flag.qs == 1)
	{
		flag.qs = 0;
		spd_traj_plan(	*pout.vel_act,	// satrt velocity
						*pin.vel_ref,   // target velocity
						0,   	// acceleration
						dec, 	// deceleration
						*pin.curve);   	// curve
		*pout.target_reached = 0;
		*mid.vel_ref_last = *pin.vel_ref;
	}
	spd_traj_eval();
	
	if(Traj.spd_step > 0)
	{
		pos_ref = MTR.p_m;
		api_vel_mode(Traj.spd_step, *pin.tor_ref);
	}
	
	if(Traj.spd_step == 0)
	{
		if((*mid.dec_mode == 1) || (*mid.dec_mode == 2))
		{
			if(++flag.time > 1000)	// wait for the speed to arrive
			{
				flag.time = 0;
				cia402axis.state = SWITCH_ON_DISABLED;
			}
		}
		if((*mid.dec_mode == 3) || (*mid.dec_mode == 4))
		{
			api_pos_mode(pos_ref, *pin.vel_ref, *pin.tor_ref);
			if(control_word == 0x0F)
				cia402axis.state = SWITCH_ON_DISABLED;
		}
	}
}

__RAM_FUNC void profile_fault_stop(void)
{
	*pin.vel_ref = 0;
	if(flag.fault == 1)
	{
		flag.fault = 0;
		spd_traj_plan(	*pout.vel_act,	// satrt velocity
						*pin.vel_ref, 	// target velocity
						0,   	// acceleration
						*pin.qs_dec, 	// deceleration
						*pin.curve);   	// curve
		*pout.target_reached = 0;
		*mid.vel_ref_last = *pin.vel_ref;
	}
	spd_traj_eval();
	
	if(Traj.spd_step >= 0)
		api_vel_mode(Traj.spd_step, *pin.tor_ref);
	
	if(++flag.time > 1000)	// wait for the speed to arrive
	{
		flag.time = 0;
		if(Traj.spd_step == 0)
		{
//			if((*mid.dec_mode == 1) || (*mid.dec_mode == 2))
//			{
				cia402axis.state = FAULT;
//			}
		}
	}
}


