#ifndef _PRO_MODE_H__
#define _PRO_MODE_H__

#include "bsp.h"

#include <stdio.h>
#include <stdbool.h>



typedef struct
{
	float *mode;
	uint16_t *ctrl_word;
	int16_t  *curve;
	
	float *tor_ref;
	float *tor_ramp;
	
	float *vel_ref;
	float *vel_acc;
	float *vel_dec;
	float *qs_dec;
	
	float *pos_ref;

} in_para_t;

typedef struct
{
	float *mode;
	uint16_t *state_word;
	uint8_t *target_reached;
	
	float *tor_act;
	float *vel_act;
	float *pos_act;
	float *pos_follow_err;
	
	uint8_t *err;
} out_para_t;


typedef struct
{
	float *spd_max;
	float *tor_max;
	
	float *tor_step;
	float *tor_set;
	float *tor_win;
	
	float *vel_ref_last;
	float *vel_win;
	float *vel_time_win;
	float *zero_vel;
	
	float *pos_ref_last;
	float *pos_win;
	float *pos_max_win;
	float *pos_time_win;
	
	int16_t *dec_mode;
	
} mid_para_t;


typedef struct
{
	uint8_t qs;
	uint8_t fault;
	
	uint16_t errtime;
	uint16_t time;
}flag_t;

extern in_para_t pin;
extern out_para_t pout;
extern mid_para_t mid;

extern flag_t flag;

void pro_mode_init();
void profile_tor_mode(void);
void profile_vel_mode(void);
void profile_pos_mode(void);
void profile_qs_stop(void);
void profile_fault_stop(void);
	
#endif






