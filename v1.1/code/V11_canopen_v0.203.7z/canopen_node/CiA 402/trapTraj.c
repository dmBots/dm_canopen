#include "trapTraj.h"
#include <math.h>

Traj_t Traj;

float A1,B1,C1,F1;
float A2,B2,C2,F2;
// A sign function where input 0 has positive sign (not 0)
static inline float sign_hard(float val)
{
    return (signbit(val)) ? -1.0f : 1.0f;
}

void spd_traj_plan(float vel_init, float vel_end, float acc, float dec, float curve_mode)
{
    Traj.curve_mode = curve_mode;
    Traj.vel_init 	= vel_init;
    Traj.vel 		= vel_end;

    if(vel_init>=0 && vel_end>=0 && vel_init<vel_end)  // �������
    {
        Traj.flag = 1;
        Traj.acc = acc;
    }
    if(vel_init>=0 && vel_end>=0 && vel_init>vel_end) // �������
    {
        Traj.flag = 2;
        Traj.dec = -dec;
    }

    if(vel_init<=0 && vel_end<=0 && vel_init>vel_end) // �������
    {
        Traj.flag = 3;
        Traj.acc = -acc;
    }
    if(vel_init<=0 && vel_end<=0 && vel_init<vel_end) // �������
    {
        Traj.flag = 4;
        Traj.dec = dec;
    }
    if(vel_init<0 && vel_end>0 && vel_init<vel_end) // ������� �������
    {
        Traj.flag = 5;
        Traj.acc = acc;
        Traj.dec = dec;
    }
    if(vel_init>0 && vel_end<0 && vel_init>vel_end) // ������� �������
    {
        Traj.flag = 6;
        Traj.acc = -acc;
        Traj.dec = -dec;
    }

    // Calculate acceleration and deceleration times
    if (Traj.flag==1||Traj.flag==3) {
        Traj.t_acc = (vel_end - vel_init) / Traj.acc;
        Traj.t_dec = 0;

        if (Traj.curve_mode == scurve) {
            A1 = 6.0f * (Traj.vel - Traj.vel_init) / 6.0f;
            B1 = 15.0f * (Traj.vel_init - Traj.vel) / 5.0f;
            C1 = 10.0f * (Traj.vel - Traj.vel_init) / 4.0f;
            F1 = Traj.vel_init;
        }
		
    }
    if (Traj.flag==2||Traj.flag==4) {
        Traj.t_acc = 0;
        Traj.t_dec = (vel_end - vel_init) / Traj.dec;

        if (Traj.curve_mode == scurve) {
            A1 = 6.0f * (Traj.vel - Traj.vel_init) / 6.0f;
            B1 = 15.0f * (Traj.vel_init - Traj.vel) / 5.0f;
            C1 = 10.0f * (Traj.vel - Traj.vel_init) / 4.0f;
            F1 = Traj.vel_init;
        }
    }
    if (Traj.flag==5||Traj.flag==6) {
        Traj.t_acc = (vel_end - 0) / Traj.acc;
        Traj.t_dec = (0 - vel_init) / Traj.dec;

        if (Traj.curve_mode == scurve) {
            A1 = 6.0f * (0 - Traj.vel_init) / 6.0f;
            B1 = 15.0f * (Traj.vel_init - 0) / 5.0f;
            C1 = 10.0f * (0 - Traj.vel_init) / 4.0f;
            F1 = Traj.vel_init;

            A2 = 6.0f * (Traj.vel - 0) / 6.0f;
            B2 = 15.0f * (0 - Traj.vel) / 5.0f;
            C2 = 10.0f * (Traj.vel - 0) / 4.0f;
            F2 = 0;
        }
    }

    // For speed planning, we only consider acceleration and then maintaining target speed
    Traj.t_total = Traj.t_acc + Traj.t_dec;

    Traj.tick = 0;
    Traj.profile_done = false;
    Traj.spd_step = vel_init;
}


void spd_traj_eval(void)
{
    if (Traj.profile_done) {
        return;
    }

    Traj.tick++;
    float t = Traj.tick * 0.00005f;
    if(Traj.flag <= 4) {
        if (t < Traj.t_acc) { // Accelerating
            if (Traj.curve_mode == tcurve)
                Traj.spd_step = Traj.vel_init + Traj.acc * t;
            if (Traj.curve_mode == scurve)
                Traj.spd_step = (6.0f * A1 * powf(t / Traj.t_acc, 5.0f) + 5.0f * B1 * powf(t / Traj.t_acc, 4.0f) + 4.0f * C1 * powf(t / Traj.t_acc, 3.0f) + F1);

        } else if (t < Traj.t_dec) { // Decelerating
            if (Traj.curve_mode == tcurve)
                Traj.spd_step = Traj.vel_init + Traj.dec * t;
            if (Traj.curve_mode == scurve)
                Traj.spd_step = (6.0f * A1 * powf(t / Traj.t_dec, 5.0f) + 5.0f * B1 * powf(t / Traj.t_dec, 4.0f) + 4.0f * C1 * powf(t / Traj.t_dec, 3.0f) + F1);
        } else { // Final Condition
            Traj.spd_step = Traj.vel;
            Traj.profile_done = true;
        }
    }

    if(Traj.flag == 5 || Traj.flag == 6)
    {
        if (t < Traj.t_dec) { // Decelerating
            if (Traj.curve_mode == tcurve)
                Traj.spd_step = Traj.vel_init + Traj.dec * t;
            if (Traj.curve_mode == scurve)
                Traj.spd_step = (6.0f * A1 * powf(t / Traj.t_dec, 5.0f) + 5.0f * B1 * powf(t / Traj.t_dec, 4.0f) + 4.0f * C1 * powf(t / Traj.t_dec, 3.0f) + F1);

        } else if (t < Traj.t_total) { // Accelerating
            float t_acc = t - Traj.t_dec;
            if (Traj.curve_mode == tcurve)
                Traj.spd_step = 0 + Traj.acc * t_acc;
            if (Traj.curve_mode == scurve)
                Traj.spd_step = (6.0f * A2 * powf(t_acc / Traj.t_acc, 5.0f) + 5.0f * B2 * powf(t_acc / Traj.t_acc, 4.0f) + 4.0f * C2 * powf(t_acc / Traj.t_acc, 3.0f) + F2);

        } else { // Final Condition
            Traj.spd_step = Traj.vel;
            Traj.profile_done = true;
        }
    }
}



void pos_traj_plan(float pos_init, float pos_end, float vel_init, float v_max, float acc, float dec, float curve_mode)
{
    float distance  = pos_end - pos_init;           // Distance to travel
    float stop_dist = SQ(vel_init) / (2.0f * dec);  // Minimum stopping distance
    float dXstop    = copysign(stop_dist, vel_init); // Minimum stopping displacement
    float s         = sign_hard(distance - dXstop);        // Sign of coast velocity (if any)
    Traj.acc        = s * acc;                            // Maximum Acceleration (signed)
    Traj.dec        = -s * dec;                           // Maximum Deceleration (signed)
    Traj.vel        = s * v_max;                            // Maximum Velocity (signed)

    Traj.curve_mode = curve_mode;

    // If we start with a speed faster than cruising, then we need to decel instead of accel aka "double deceleration move" in the paper
    if ((s * vel_init) > (s * Traj.vel)) {
        Traj.acc = -s * acc;
    }

    // Time to accel/decel to/from Vr (cruise speed)
    Traj.t_acc = (Traj.vel - vel_init) / Traj.acc;
    Traj.t_dec = -Traj.vel / Traj.dec;

    // Integral of velocity ramps over the full accel and decel times to get
    // minimum displacement required to reach cuising speed
    float dXmin = 0.5f * Traj.t_acc * (Traj.vel + vel_init) + 0.5f * Traj.t_dec * Traj.vel;

    // Are we displacing enough to reach cruising speed?
    if (s * distance < s * dXmin) {
        // Short move (triangle profile)
        Traj.vel = s
                   * sqrtf(fmax((Traj.dec * SQ(vel_init) + 2.0f * Traj.acc * Traj.dec * distance)
                                / (Traj.dec - Traj.acc),
                                0.0f));
        Traj.t_acc = fmax(0.0f, (Traj.vel - vel_init) / Traj.acc);
        Traj.t_dec = fmax(0.0f, -Traj.vel / Traj.dec);
        Traj.t_vel = 0.0f;
    } else {
        // Long move (trapezoidal profile)
        Traj.t_vel = (distance - dXmin) / Traj.vel;
    }

    if (Traj.curve_mode == scurve) {
        A1 = 6.0f * (Traj.vel - Traj.vel_init) / 6.0f;
        B1 = 15.0f * (Traj.vel_init - Traj.vel) / 5.0f;
        C1 = 10.0f * (Traj.vel - Traj.vel_init) / 4.0f;
        F1 = Traj.vel_init;

        A2 = 6.0f * (0.0f - Traj.vel) / 6.0f;
        B2 = 15.0f * (Traj.vel - 0.0f) / 5.0f;
        C2 = 10.0f * (0.0f - Traj.vel) / 4.0f;
        F2 = Traj.vel;
    }

    // Fill in the rest of the values used at evaluation-time
    Traj.t_total        = Traj.t_acc + Traj.t_vel + Traj.t_dec;
    Traj.pos_init = pos_init;
    Traj.vel_init = vel_init;
    Traj.pos_end   = pos_end;
    Traj.acc_distance   = pos_init + vel_init * Traj.t_acc
                          + 0.5f * Traj.acc * SQ(Traj.t_acc); // pos at end of accel phase

    Traj.tick         = 0;
    Traj.profile_done = false;
}



void pos_traj_eval(void)
{
    if (Traj.profile_done) {
        return;
    }

    Traj.tick++;
    float t = Traj.tick * CURRENT_MEASURE_PERIOD;

    if (t < 0.0f) { // Initial Condition
        Traj.pos_step   = Traj.pos_init;
        Traj.spd_step  = Traj.vel_init;
        Traj.tor_step = 0.0f;
    } else if (t < Traj.t_acc) { // Accelerating
        if (Traj.curve_mode == tcurve) {
            Traj.pos_step   = Traj.pos_init + Traj.spd_step * Traj.vel_init * t + 0.5f * Traj.acc * SQ(t);
            Traj.spd_step  = Traj.vel_init + Traj.acc * t;
            Traj.tor_step = Traj.acc;
        }
        if (Traj.curve_mode == scurve) {
            Traj.pos_step = Traj.pos_init + Traj.t_acc * (A1 * powf(t / Traj.t_acc, 6.0f) + B1 * powf(t / Traj.t_acc, 5.0f) + C1 * powf(t / Traj.t_acc, 4.0f) + F1 * t
                                                   / Traj.t_acc);
            Traj.spd_step = (6.0f * A1 * powf(t / Traj.t_acc, 5.0f) + 5.0f * B1 * powf(t / Traj.t_acc, 4.0f) + 4.0f * C1 * powf(t / Traj.t_acc, 3.0f) + F1);
            Traj.tor_step = (5.0f * 6.0f * A1 * powf(t / Traj.t_acc, 4.0f) + 4.0f * 5.0f * B1 * powf(t / Traj.t_acc, 3.0f) + 3.0f * 4.0f * C1 *
                        powf(t / Traj.t_acc, 2.0f)) / Traj.t_acc;
        }

    } else if (t < Traj.t_acc + Traj.t_vel) { // Coasting
        Traj.pos_step   = Traj.acc_distance + Traj.vel * (t - Traj.t_acc);
        Traj.spd_step  = Traj.vel;
        Traj.tor_step = 0.0f;
    } else if (t < Traj.t_total) { // Deceleration
        if (Traj.curve_mode == tcurve) {
            float td = t - Traj.t_total;
            Traj.pos_step  = Traj.pos_end + Traj.spd_step * 0.5f * Traj.dec * SQ(td);
            Traj.spd_step  = Traj.dec * td;
            Traj.tor_step = Traj.dec;
        }
        if (Traj.curve_mode == scurve) {
            float Tb = Traj.t_acc + Traj.t_vel;
            float Tc = Traj.t_total;
            float x = (t - Tb) / (Tc - Tb);
            Traj.pos_step = Traj.acc_distance + Traj.vel * Traj.t_vel + (Tc - Tb) * (A2 * powf(x, 6.0f) + B2 * powf(x, 5.0f) + C2 * powf(x, 4.0f) + F2 * x);
            Traj.spd_step = (6.0f * A2 * powf(x, 5.0f) + 5.0f * B2 * powf(x, 4.0f) + 4.0f * C2 * powf(x, 3.0f) + F2);
            Traj.tor_step = (5.0f * 6.0f * A2 * powf(x, 4.0f) + 4.0f * 5.0f * B2 * powf(x, 3.0f) + 3.0f * 4.0f * C2 * powf(x, 2.0f)) / (
                           Tc - Tb);
        }
    }
    else if (t >= Traj.t_total) { // Final Condition
        Traj.pos_step            = Traj.pos_end;
        Traj.spd_step           = 0.0f;
        Traj.tor_step          = 0.0f;
        Traj.profile_done = true;
    }
}




