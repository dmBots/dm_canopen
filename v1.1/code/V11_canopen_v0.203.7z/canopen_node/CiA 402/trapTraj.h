/*
    Copyright 2021 codenocold codenocold@qq.com
    Address : https://github.com/codenocold/dgm
    This file is part of the dgm firmware.
    The dgm firmware is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    The dgm firmware is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _TRAP_TRAJ_H
#define _TRAP_TRAJ_H

#include "bsp.h"
#include <stdbool.h>

#define SQ(x)        ((x)*(x))
#define ABS(x)         ( (x)>0?(x):-(x) )
#define PWM_FREQUENCY          20000
#define CURRENT_MEASURE_HZ     PWM_FREQUENCY
#define CURRENT_MEASURE_PERIOD 0.00005f//(float) (1.0f / (float) CURRENT_MEASURE_HZ)

typedef struct
{
    uint8_t curve_mode;
	
	// Step
	float pos_step;	// Current pos at the given tick
    float spd_step; // Current speed at the given tick
	float tor_step; // Current torque at the given tick

    float pos_init;
    float pos_end;

    float vel_init;
    float vel_end;

    float acc;
    float vel;
    float dec;

    float acc_distance;

    float t_acc;
    float t_vel;
    float t_dec;
    float t_total;

    uint32_t tick;

    bool profile_done;
	
	uint8_t flag;
	
} Traj_t;

typedef enum
{
	tcurve,
    scurve  
} curve_e;

extern Traj_t Traj;

void spd_traj_plan(float vel_init, float vel_end, float acc, float dec, float curve_mode);
void spd_traj_eval(void);

void pos_traj_plan(float pos_init, float pos_end, float vel_init, float v_max, float acc, float dec, float curve_mode);
void pos_traj_eval(void);

#endif
