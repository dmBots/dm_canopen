#include "fsmc.h"
#include "udefine.h"
#include "stdlib.h"
#include "fsmc.h"
#include "co_app.h"
#include "foc_ctrl.h"
#include "pro_mode.h"
#include "api_com.h"
#include "OD.h"

#include "bsp.h"
#include "301/CO_ODinterface.h"

com_od_t com_od;
__RAM_FUNC void com_para(void)
{
    ctrler.CTRL_MODE = OD_RAM.x6060_modesOfOperation;
    OD_RAM.x6061_modesOfOperationDisplay = ctrler.CTRL_MODE;
    control_word = OD_RAM.x6040_controlword;
	
	com_od.x200A_mos_temp.f_val   = ctrler.TMOS;
    com_od.x200A_motor_temp.f_val = MTR.T_CEL;
    com_od.x60FF_vel_ref.i32_val = OD_RAM.x60FF_targetVelocity;
    com_od.x607A_pos_ref.i32_val = OD_RAM.x607A_targetPosition;
    com_od.x6071_tor_ref.i32_val = OD_RAM.x6071_targetTorque<<16;
	
	if(OD_RAM.x607E_polarity == 2)
	{
		com_od.x607A_pos_ref.f_val = -com_od.x607A_pos_ref.f_val;
		com_od.x60FF_vel_ref.f_val = -com_od.x60FF_vel_ref.f_val;
		com_od.x6071_tor_ref.f_val = -com_od.x6071_tor_ref.f_val;
	}
	
	com_od.x6083_vel_acc.u32_val = OD_RAM.x6083_profileAcceleration;
    com_od.x6084_vel_dec.u32_val = OD_RAM.x6084_profileDeceleration;
    com_od.x6064_pos_fbk.f_val 		= MTR.p_m;
    com_od.x606C_vel_fbk.f_val 		= MTR.v_m;
    com_od.x6077_tor_fbk.f_val 		= MTR.Te;
	com_od.x6078_current_fbk.f_val 	= MTR.IQF*IBase;
	
    OD_RAM.x6064_positionActualValue = com_od.x6064_pos_fbk.i32_val;
    OD_RAM.x606C_velocityActualValue = com_od.x606C_vel_fbk.i32_val;
    OD_RAM.x6077_torqueActualValue   = com_od.x6077_tor_fbk.i32_val>>16;
	OD_RAM.x6078_currentActualValue  = com_od.x6078_current_fbk.u32_val;
	
	OD_RAM.x6062_positionDemandValue = com_od.x607A_pos_ref.i32_val;
	OD_RAM.x606B_velocityDemandValue = com_od.x60FF_vel_ref.i32_val;
    OD_RAM.x200A_temperatureDetection.mosTemperature   = com_od.x200A_mos_temp.u32_val;
    OD_RAM.x200A_temperatureDetection.motorTemperature = com_od.x200A_motor_temp.u32_val;
	OD_RAM.x60F4_followingErrorActualValue = com_od.x60F4_follow_err_value.i32_val;
	
	sat_datf(com_od.x6083_vel_acc.f_val, 0, com_od.x60C5_acc_max.f_val);
	sat_datf(com_od.x6084_vel_dec.f_val, 0, com_od.x60C6_dec_max.f_val);
	
	TMP.ACC		= com_od.x6083_vel_acc.f_val;
	TMP.DEC		= com_od.x6084_vel_dec.f_val;
	
    if (cia402axis.flags.config_allowed == 1)	//
    {
        TMP.h_time = OD_PERSIST_COMM.x1017_producerHeartbeatTime;
        TMP.ESC_ID = OD_RAM.x2003_communicationParameter.CAN_Node_ID;
        TMP.can_br = OD_RAM.x2003_communicationParameter.CANCommunicationSpeed;
		
        com_od.x2004_ibw.u32_val = OD_RAM.x2004_currentControlParameter.bandwidth;
        com_od.x2005_spd_kp.u32_val   = OD_RAM.x2005_speedControlParameter.KP;
        com_od.x2005_spd_ki.u32_val   = OD_RAM.x2005_speedControlParameter.KI;
        com_od.x2005_spd_deta.u32_val = OD_RAM.x2005_speedControlParameter.dampingFactor;
        com_od.x2006_pos_kp.u32_val   = OD_RAM.x2006_positionControlParameter.KP;
        com_od.x2006_pos_ki.u32_val   = OD_RAM.x2006_positionControlParameter.KI;
        com_od.x2008_iitover.u32_val  = OD_RAM.x2008_IITOverCurrentDetection.overCurrentThreshold;
        com_od.x200A_mos_temp_limit.u32_val = OD_RAM.x200A_temperatureDetection.mosTemperatureLimit;
        com_od.x200A_motor_temp_limit.u32_val = OD_RAM.x200A_temperatureDetection.motorTemperatureLimit;
		
		com_od.x6065_follow_err_win.u32_val = OD_RAM.x6065_followingErrorWindow;
		com_od.x6067_pos_win.u32_val 		= OD_RAM.x6067_positionWindow;
		com_od.x6068_pos_win_time.u32_val 	= OD_RAM.x6068_positionWindowTime<<16;
		com_od.x606D_vel_win.u32_val		= OD_RAM.x606D_velocityWindow<<16;
		com_od.x606E_vel_win_time.u32_val	= OD_RAM.x606E_velocityWindowTime<<16;
		com_od.x606F_zero_vel_win.u32_val	= OD_RAM.x606F_velocityThreshold<<16;
        com_od.x6072_tor_max.u32_val		= OD_RAM.x6072_maxTorque<<16;
		com_od.x6080_spd_max.u32_val 		= OD_RAM.x6080_maxMotorSpeed;
		com_od.x6083_vel_acc.u32_val 		= OD_RAM.x6083_profileAcceleration;
		com_od.x6084_vel_dec.u32_val 		= OD_RAM.x6084_profileDeceleration;
		com_od.x6085_qs_dec.u32_val			= OD_RAM.x6085_quickStopDeceleration;
		com_od.x6087_tor_ramp.u32_val 		= OD_RAM.x6087_torqueSlope;
		com_od.x60C5_acc_max.u32_val		= OD_RAM.x60C5_maxAcceleration;
		com_od.x60C6_dec_max.u32_val		= OD_RAM.x60C6_maxDeceleration;
		
        TMP.I_BW = com_od.x2004_ibw.f_val;
        TMP.KP_ASR = com_od.x2005_spd_kp.f_val;
        TMP.KI_ASR = com_od.x2005_spd_ki.f_val;
        TMP.Deta   = com_od.x2005_spd_deta.f_val;
        TMP.KP_APR = com_od.x2006_pos_kp.f_val;
        TMP.KI_APR = com_od.x2006_pos_ki.f_val;
        TMP.OC_Value = com_od.x2008_iitover.f_val;
        TMP.OV_Value = OD_RAM.x2009_voltageDetection.overVoltage;
        TMP.UV_Value = OD_RAM.x2009_voltageDetection.underVoltage;
        TMP.OT_Value = com_od.x200A_mos_temp_limit.f_val;
        TMP.MAX_SPD = com_od.x6080_spd_max.f_val;
		TMP.ACC		= com_od.x6083_vel_acc.f_val;
		TMP.DEC		= com_od.x6084_vel_dec.f_val;
		
		if(OD_RAM.x200B_driver.clearFault == 1)
		{
			FFC.rst = 0;// clear fault
			FFC.com = 0;
			ctrler.ERR_STATE=0;
			OD_RAM.x603F_errorCode = 0;
			cia402axis.state = SWITCH_ON_DISABLED;
			OD_RAM.x200B_driver.clearFault = 0;
		}
		
		if(OD_RAM.x200B_driver.saveZero == 1)
		{
			NVIC_DisableIRQ(ADC_IRQn);
			MTR.M_OFF=0.0f;
			MTR.rev	=	MTR.rev-(int32_t)(MTR.rev*MTR.ODG)*MTR.Gr;
			Xsens.rev = 0;
			MTR.M_OFF=(ma.ps+MTR.rev*two_pi)*MTR.ODG;
			MTR.p_m  = 0.0f;
			Htmp.M_OFF	=	MTR.M_OFF;
			Xsens.x_off = Xsens.raw;
			Htmp.X_OFF	=	Xsens.raw;
			MTR.p_m  = 0.0f;
			__disable_irq();
			Push_ROM((uint32_t*)&Hallm,(uint32_t*)&Htmp,6);
			__enable_irq();
			CM_ADC1->ISCLRR = 0x01;
			CM_ADC2->ISCLRR = 0x01;
			NVIC_ClearPendingIRQ(ADC_IRQn);
			NVIC_EnableIRQ(ADC_IRQn);
			OD_RAM.x200B_driver.saveZero = 0;
		}
		
        if (OD_RAM.x1010_storeParameters[0] == 0)
        {
            FFC.fwr = 1;
            OD_RAM.x1010_storeParameters[0] = 1;
            cia402axis.state = SWITCH_ON_DISABLED;
        }
    }
}


void com_para_init(void)
{
    OD_PERSIST_COMM.x1017_producerHeartbeatTime = TMP.h_time;
    com_od.x2002_rs.f_val = TMP.Rs;
    com_od.x2002_ls.f_val = TMP.Ls;
    com_od.x2002_flux.f_val = TMP.Flux;
    com_od.x2002_damp.f_val = TMP.Damp;
    com_od.x2002_jx.f_val = TMP.Inertia;
    com_od.x2004_ibw.f_val = TMP.I_BW;
    com_od.x2005_spd_kp.f_val = TMP.KP_ASR;
    com_od.x2005_spd_ki.f_val = TMP.KI_ASR;
    com_od.x2005_spd_deta.f_val = TMP.Deta;
    com_od.x2006_pos_kp.f_val = TMP.KP_APR;
    com_od.x2006_pos_ki.f_val = TMP.KI_APR;
    com_od.x2008_iitover.f_val = TMP.OC_Value;
    com_od.x200A_mos_temp_limit.f_val = TMP.OT_Value;
    com_od.x200A_motor_temp_limit.f_val = TMP.OT_Value;
	
    com_od.x6080_spd_max.f_val = TMP.MAX_SPD;
    com_od.x6083_vel_acc.f_val = TMP.ACC;
    com_od.x6084_vel_dec.f_val = TMP.DEC;
	com_od.x6072_tor_max.f_val = TMP.OC_Value*MTR.KT_Base;
	
    OD_RAM.x2002_motorParameter.rs = com_od.x2002_rs.u32_val;
    OD_RAM.x2002_motorParameter.ls = com_od.x2002_ls.u32_val;
    OD_RAM.x2002_motorParameter.flux = com_od.x2002_flux.u32_val;
    OD_RAM.x2002_motorParameter.pas = com_od.x2002_damp.u32_val;
    OD_RAM.x2002_motorParameter.jx = com_od.x2002_jx.u32_val;
    OD_RAM.x2002_motorParameter.pn = TMP.POLE;
    OD_RAM.x2002_motorParameter.gr = TMP.Gr;
    OD_RAM.x2003_communicationParameter.CAN_Node_ID = TMP.ESC_ID;
    OD_RAM.x2003_communicationParameter.CANCommunicationSpeed = TMP.can_br;
    OD_RAM.x2004_currentControlParameter.bandwidth = com_od.x2004_ibw.u32_val;
    OD_RAM.x2005_speedControlParameter.dampingFactor = com_od.x2005_spd_deta.u32_val;
    OD_RAM.x2005_speedControlParameter.KP            = com_od.x2005_spd_ki.u32_val;
    OD_RAM.x2005_speedControlParameter.KI            = com_od.x2005_spd_kp.u32_val;
    OD_RAM.x2006_positionControlParameter.KP = com_od.x2006_pos_kp.u32_val;
    OD_RAM.x2006_positionControlParameter.KI = com_od.x2006_pos_ki.u32_val;
    OD_RAM.x2008_IITOverCurrentDetection.overCurrentThreshold = com_od.x2008_iitover.u32_val;
    OD_RAM.x2009_voltageDetection.overVoltage  = TMP.OV_Value;
    OD_RAM.x2009_voltageDetection.underVoltage = TMP.UV_Value;
    OD_RAM.x200A_temperatureDetection.mosTemperatureLimit   = com_od.x200A_mos_temp_limit.u32_val;
    OD_RAM.x200A_temperatureDetection.motorTemperatureLimit = com_od.x200A_motor_temp_limit.u32_val;
    OD_RAM.x607E_polarity  = MTR.Order;
	OD_RAM.x6072_maxTorque = com_od.x6072_tor_max.u32_val>>16;
	OD_RAM.x6080_maxMotorSpeed = com_od.x6080_spd_max.u32_val;
    OD_RAM.x6083_profileAcceleration = com_od.x6083_vel_acc.u32_val;
    OD_RAM.x6084_profileDeceleration = com_od.x6084_vel_dec.u32_val;
	
}

