#ifndef _API_COM_H__
#define _API_COM_H__

#include "bsp.h"
#include "util.h"
#include <stdio.h>
#include <stdbool.h>



typedef struct
{
	data_u x60FF_vel_ref;
	data_u x6083_vel_acc;
	data_u x6084_vel_dec;
	data_u x6071_tor_ref;
	data_u x607A_pos_ref;
	
	data_u x6064_pos_fbk;
	data_u x606C_vel_fbk;
	data_u x6077_tor_fbk;
	data_u x6080_spd_max;
	
	data_u x6065_follow_err_win;
	data_u x6066_follow_time;
	data_u x6067_pos_win;
	data_u x6068_pos_win_time;
	
	data_u x606D_vel_win;
	data_u x606E_vel_win_time;
	
	data_u x606F_zero_vel_win;
	data_u x6072_tor_max;
	
	data_u x6078_current_fbk;
	data_u x6085_qs_dec;
	data_u x6087_tor_ramp;
	
	data_u x60C5_acc_max;
	data_u x60C6_dec_max;
	
	data_u x60F4_follow_err_value;
	
	data_u x2002_rs;
	data_u x2002_ls;
	data_u x2002_flux;
	data_u x2002_damp;
	data_u x2002_jx;
	
	data_u x2004_ibw;
	data_u x2005_spd_kp;
	data_u x2005_spd_ki;
	data_u x2005_spd_deta;
	
	data_u x2006_pos_kp;
	data_u x2006_pos_ki;
	
	data_u x2008_iitover;
	
	data_u x200A_mos_temp;
	data_u x200A_motor_temp;
	data_u x200A_mos_temp_limit;
	data_u x200A_motor_temp_limit;
	
}com_od_t;

extern com_od_t com_od;

void com_para(void);
void com_para_init(void);

#endif






