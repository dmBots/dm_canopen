#include "fsmc.h"
#include "udefine.h"
#include "stdlib.h"
#include "fsmc.h"
#include "co_app.h"
#include "foc_ctrl.h"
#include "pro_mode.h"
#include "api_mode.h"

__RAM_FUNC void api_tor_mode(float tor_set, float tor_lim)
{
	foc_torque(tor_set, tor_lim, MTR.p_e);
}

__RAM_FUNC void api_vel_mode(float vel_set, float tor_set)
{
	foc_vel(vel_set*MTR.Gr, tor_set, MTR.p_e);
}

__RAM_FUNC void api_pos_mode(float pos_set, float vel_set, float tor_set)
{
	foc_pos(pos_set, vel_set*MTR.Gr, tor_set, MTR.p_e);
}

__RAM_FUNC void api_clear(void)
{
	if(al_status == 1)
	{
		com_od.x607A_pos_ref.f_val = 0.0f;
		com_od.x60FF_vel_ref.f_val = 0.0f;
		com_od.x6071_tor_ref.f_val = 0.0f;
		IDx_Loop.out = 0;
		IQx_Loop.out = 0;
//		LED_G_OFF();
	}
	if(al_status == AL_STATUS_OP)
	{
		LED_G_ON();
	}
	if(al_status == 0)
	{
		com_od.x607A_pos_ref.f_val = 0.0f;
		com_od.x60FF_vel_ref.f_val = 0.0f;
		com_od.x6071_tor_ref.f_val = 0.0f;
		IDx_Loop.out = 0;
		IQx_Loop.out = 0;
		reset_ctrler2();
		LED_G_OFF();
	}
}
