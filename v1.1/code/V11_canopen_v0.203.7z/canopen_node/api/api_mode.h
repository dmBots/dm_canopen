#ifndef _API_MODE_H__
#define _API_MODE_H__

#include "bsp.h"

#include <stdio.h>
#include <stdbool.h>


void api_tor_mode(float tor_set, float tor_lim);
void api_vel_mode(float vel_set, float tor_set);
void api_pos_mode(float pos_set, float vel_set, float tor_set);
void api_clear(void);

#endif






