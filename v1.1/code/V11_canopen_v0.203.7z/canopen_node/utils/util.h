#ifndef __UTIL_H__
#define __UTIL_H__

#include "bsp.h"
#include <math.h>

// Return the sign of the argument. -1.0 if negative, 1.0 if zero or positive.
#define SIGN(x)				(((x) < 0.0) ? -1.0 : 1.0)
// Two-norm of 2D vector
#define NORM2_f(x,y)		(sqrtf(SQ(x) + SQ(y)))

// nan and infinity check for floats
#define UTILS_IS_INF(x)		((x) == (1.0 / 0.0) || (x) == (-1.0 / 0.0))
#define UTILS_IS_NAN(x)		((x) != (x))
#define UTILS_NAN_ZERO(x)	(x = UTILS_IS_NAN(x) ? 0.0 : x)

#define MIN_MAX_LIMT(in,low,high)  (in = in>high? high:in<low?low:in)
#define MAX_LIMT(in,outmax)  (in = in>outmax? outmax:in<(-outmax)?(-outmax):in)
#define SQ(x)        ((x)*(x))
#define ABS(x)         ( (x)>0?(x):-(x) ) 
#define MAX(x, y)     (((x) > (y)) ? (x) : (y))
#define MIN(x, y)     (((x) < (y)) ? (x) : (y))
#define min(x, y) (((x) < (y)) ? (x) : (y)) // ȡ��Сֵ
#define max(x, y) (((x) > (y)) ? (x) : (y)) // ȡ�ϴ�ֵ
#define CLAMP(x, lower, upper)      (MIN(upper, MAX(x, lower)))
#define FLOAT_EQU(floatA, floatB)   ((ABS((floatA)-(floatB))) < 0.000001f)

#define M_PI (3.14159265358f)         // Բ����
#define M_2PI (6.28318530716f)        // 2��Բ����
#define SQRT3 (1.73205080757f)        // 3��ƽ����
#define SQRT3_BY_2 (0.86602540378f)   // 3��ƽ������һ��
#define ONE_BY_SQRT3 (0.57735026919f) // 1����3��ƽ����
#define TWO_BY_SQRT3 (1.15470053838f) // 2����3��ƽ����
/**
 * A simple low pass filter.
 *
 * @param value
 * The filtered value.
 *
 * @param sample
 * Next sample.
 *
 * @param filter_constant
 * Filter constant. Range 0.0 to 1.0, where 1.0 gives the unfiltered value.
 */
#define UTILS_LP_FAST(value, sample, filter_constant)    (value -= (filter_constant) * ((value) - (sample)))

/**
 * A fast approximation of a moving average filter with N samples. See
 * https://en.wikipedia.org/wiki/Moving_average#Exponential_moving_average
 * https://en.wikipedia.org/wiki/Exponential_smoothing
 *
 * It is not entirely the same as it behaves like an IIR filter rather than a FIR filter, but takes
 * much less memory and is much faster to run.
 */
#define UTILS_LP_MOVING_AVG_APPROX(value, sample, N)    UTILS_LP_FAST(value, sample, 2.0f / ((N) + 1.0f))


#define wrap_pm_pi(theta) theta = (theta > M_PI)  ? theta - M_2PI : theta; theta = (theta < -M_PI) ? theta + M_2PI : theta;
#define wrap_0_2pi(theta) theta = (theta > M_2PI) ? theta - M_2PI : theta; theta = (theta < 0.0f ) ? theta + M_2PI : theta;


typedef union
{
	float f_val;
	uint32_t u32_val;
	int32_t i32_val;
	uint8_t u8_val[4];
} data_u;





float sat1_datf(float val, float up, float low);
float fast_atan2(float y, float x);

float sin_f32(float x);
float cos_f32(float x);

uint8_t crc8(const uint8_t *data, const uint32_t size);
uint32_t crc32(const uint8_t *data, uint32_t size);

void set_float_value(data_u *data, float value);
void set_uint32_value(data_u *data, uint32_t value);
void set_int32_value(data_u *data, uint32_t value);

float get_float_value(data_u *data);
uint32_t get_uint32_value(data_u *data);
int32_t get_int32_value(data_u *data);

int float_map_int(float x_float, float x_min, float x_max, int bits);
float int_map_float(int x_int, float x_min, float x_max, int bits);

#endif

