#ifndef __MC_H_
#define __MC_H_

/****
Version:V3.2
Create Time:2024/05/30
Author:Kelvin.Liu
Item:
		2023/10/14: V1.0,first edition,derivatived from f460 mclib-v7.0
		2023/12/19: V1.1,based on V1.0,change flux id from arithmetic method to mras
		2024/01/24: V2.0,based on V1.1,add some variables of ESC_INC for adapting FDCAN edtion
		2024/01/30: V3.0,based on V2.0,modify ADC reading,from double ADCs to triple ADCs
									externed state observer type is based on Velocity
		2024/03/18: V3.01,based on V3.0,reactive IDQ_Loop.b2
		2024/05/08: V3.1,based on V3.01,add variable 'can_err' for FFC
																		add 'Ualph'&'Ubeta' of CTRL_BOX
																		add 'Sin'&'Cos' of CTRL_BOX
																		add 'tick' of CTRL_BOX
																		add 'spd_mea' of Motor_BOX
		2024/05/30: V3.2,based on V3.1,Add canopen support
*/
#include "hc32f448.h"
#include <math.h>
#include "mctypes.h"

#define pi     3.14159265358979f
#define two_pi 6.28318530717959f

typedef struct{
    float Kp;
		float Ki;
    float e_k;       // pi error input
	  float Up;        // pi proportional output
    float Ui;        // pi integral output
	  float v1; 			 // pre-saturated output
		float out;       // pid output
	  float SatErr;
		float min;
		float max;
}PI_PARA;
extern PI_PARA ID_Loop;
extern PI_PARA IQ_Loop;
extern PI_PARA SPD_Loop;
extern PI_PARA POS_Loop;

typedef struct{
		float kp;    //	controller gain
		float ref;   //	input
    float yk;    //	state of measure
		float e_o;	 // error of estimation
		float T;
    float z[2];  // observer state
	  float w0;		 // observer bandwidth
		float b0;    // output gain
		float b1;		 //	1/b0
		float b2;		 //	b0*T
		float beta[2];
		float e_c;	//	error of control
		float u0;
		float uk;
	  float out;
		float min;
		float max;
}CC_PARA;
extern CC_PARA IDx_Loop,IQx_Loop;
void CC_CTRL(CC_PARA *v);

typedef struct{
	float yk;	//	observer input
	float uk; //	observer input
	float ek;	//	error between state input and observer
	float ek1;
	float de;
	float z[2];	//	state z0
  float T;	//	sample time
	float beta[2];  //	coefficient of beta0
	float b0;			//	initial value
	float b1;			//	1/b0
	float out;
	float min;
	float max;
}ESO_Type;
extern ESO_Type dmc;
void ESO_upd(ESO_Type *a);

void init_ctrler(void);
void reset_ctrler(void);
void reset_ctrler2(void);
void Reclc_PI(void);
void PI_CTRL(PI_PARA *v);
void mp_id(void);//motor parameters identify

void order_phase(void);
void calibration(void);
void verifyid(void);
/* input radian,range [-π,π] */
void sincos(float radian, float *PtrSin, float *PtrCos);
float sat_datf(float in, float low, float up);
void lim_datf(float* in, float min, float max);
float lim_angf(float ang);/* lim input angle to [-π,π] */
void limit_norm(float *x, float *y, float limit);
int float_to_uint(float x, float x_min, float x_max, int bits);
float uint_to_float(int x_int, float x_min, float x_max, int bits);

extern float sinTable[2049];

#endif
