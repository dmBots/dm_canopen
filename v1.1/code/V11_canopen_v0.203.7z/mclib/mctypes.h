#ifndef __MCTYPES_H_
#define __MCTYPES_H_

/****
Version:V3.2
Create Time:2024/05/30
Author:Kelvin.Liu
Item:
2023/10/14: V1.0,first edition,derivatived from f460 mclib-v7.0
2023/12/19: V1.1,based on V1.0,change flux id from arithmetic method to mras
2024/01/24: V2.0,based on V1.1,add some variables of ESC_INC for adapting FDCAN edtion
2024/01/30: V3.0,based on V2.0,modify ADC reading,from double ADCs to triple ADCs
									externed state observer type is based on Velocity
2024/03/18: V3.01,based on V3.0,reactive IDQ_Loop.b2
2024/05/08: V3.1,based on V3.01,add variable 'can_err' of FFC
																add 'Ualph'&'Ubeta' of CTRL_BOX
																add 'Sin'&'Cos' of CTRL_BOX
																add 'tick' of CTRL_BOX
																add 'spd_mea' of Motor_BOX
2024/05/30: V3.2,based on V3.1,Add canopen support
*/
#include "hc32f448.h"

typedef struct{
	/* id parameters*/
	float VBUS_GAIN;//	bus voltage gain(Volt/LSB)
	float VB;				//	voltage base value,equal to peak phase voltage(V)
	float IB;				//	current base value,equal to peak phase current(A)
	float Tc;       //	current control time(s)
	float VCAL;			//	calibration voltage(percent)
	float INJ_I; 		//	inject current(A)
	float kp_rl;		//	kp for rl identify,2.0
	float lim_ual;		//	limit of ualph,0.3
	float ki_flux;		//	ki for flux para,0.05
	float vel_set;		//	speed set for flux id,300
	float lim_uq;		//	limit of uq,0.8
	float IQJ;    	//	inject q-axis current for inertia id(A)
	float JX_F;			//	inject frequency for inertia(Hz)
	float IVS;			//	inject iq for velocity sweep(A)
	float IPS;			//	inject iq for position sweep(A)
	/* controller parameters */
	float VBW;			//	Speed filter frequency(Hz)
	float IcBW;			//	current control bandwidth(rad/s)
	float IoBW;			//	current observer bandwidth(rad/s)
	float npp;			//	number of pole-pairs
	float rs;				//	phase resistor(��)
	float ls;				//	phase inductor(H)
	float flux;			//	motor flux(Wb)
	float inertia;	//	para inertia(Kg*m^2)
	float delta;		//	damp ratio for speed controller
	
	/* observer parameters */
	float beta0;		//	speed observer para beta0
	float beta1;		//	speed observer para beta1
}MC_PARA;

typedef struct{
    float lut[256];   //  1~256:0x00
    float e_offset;   //  257:0x00
    float filling;   	//  258:0x00
		float dir;				//	259:0x00
}CAL_DATA;
extern CAL_DATA CALDATA;
//length should less than 200;
#pragma pack(1)
typedef struct{
  uint8_t   sof;      //0x64  'd'
	float     data[15];
	uint8_t   len;      //length of data
	uint8_t  cnt;
}CAL_PKG_DATA;
#pragma pack()

extern CAL_PKG_DATA _cal_data;
extern float cal_data[256+3];

#define ESC_INF_LEN 38
typedef struct{
  float UV_Value;   	//  0:0x00
	float KT_Value;   	//  1:0x04
	float OT_Value;			//  2:0x08
	float OC_Value;			//  3:0x0C
	float ACC;					//  4:0x10
	float DEC;					//  5:0x14
	float MAX_SPD;			//  6:0x18
  uint32_t MST_ID;    //  7:0x1C
	uint32_t ESC_ID;		//  8:0x20
	uint32_t TIMEOUT;   //  9:0x24
	uint32_t cmode;     // 10:0x28
	float  	 Damp;		  // 11:0x2C
	float    Inertia;	  // 12:0x30
	uint32_t hw_ver;	  // 13:0x34
	uint32_t sw_ver;		// 14:0x38
	uint32_t SN;      	// 15:0x3C
	uint32_t POLE;		  // 16:0x40
	float    Rs;				// 17:0x44
	float    Ls;				// 18:0x48
	float    Flux;    	// 19:0x4C
	float    Gr;  			// 20:0x50
	float    PMAX;			// 21:0x54
	float    VMAX;			// 22:0x58
	float    TMAX;			// 23:0x5C
	float    I_BW;     	// 24:0x60
	float    KP_ASR;		// 25:0x64
	float    KI_ASR;		// 26:0x68
	float    KP_APR;		// 27:0x6C
	float    KI_APR;		// 28:0x70
	float    OV_Value;  // 29:0x74
	float    GREF;      // 30:0x78
	float    Deta;      // 31:0x7C
	float 	 V_BW;			// 32:0x80
	float 	 Io_BW;			// 33:0x84
	float    Vo_BW;			// 34:0x88
	uint32_t can_br;		// 35:0x8C
	uint32_t sub_ver;		// 36:0x90
	uint32_t h_time;		// 37:
}ESC_INF;

typedef struct{
  float Pref;   		//  mechanical position ref
	float Vref;   		//  mechanical position velocity
	float Tref;				//  output torque after gear
	float kp;					//  mit mode,kp
	float kd;			  	//  mit mode,kd
	float acc;				//  acc
	float dec;				//  dec
	float spd_ref;		//	speed ref
	float spd_tar;		//  speed target
	float spd_diff;		//	speed difference
	float IDref;			//	ID reference
	float IQref;			//	IQ reference
	float ISref;
	uint32_t tick;
	uint32_t CTRL_MODE;	//  ctrl mode
	float I_U_OFF;
	float I_V_OFF;
	float I_W_OFF;
	float I_U;
	float I_V;
	float I_W;
	float Ialph;
	float Ibeta;
	float ID;
	float IQ;
	float V_BUS;
	float V_Base;
	float Ualph;
	float Ubeta;
	float Sin;
	float Cos;
  uint32_t ERR_STATE;
	float TMOS;	// mos temperature
	float Vsn;
}CTRL_BOX;

typedef struct{
  float p_r;   				//  rotor position
	float v_r;   				//  rotor velocity
	int   rev;				  //	revolution
	float p_e;			  	//  electrical position
	float v_e;					//  electrical velocity
	float E_OFF;				//  electrical offset
	float p_m;					//  mechanical position
	float v_m;					//  mechanical velocity
	float spd_mea;			//	speed measurement
	float M_OFF;				//	mechanical offset
	float Jx;						//  Inertia
	float Tl;						//	load torque
	float Te;						//	electrical torque
	float Order;			  //	phase order
	uint32_t state;			//	state,motion,rest,cal or sensor mode
	uint32_t st_change; //  state change flag
	float T_CEL;				//	stator coil temperature,Celsius
	float KT_Base;			//	torque base,equal 1.5*NPP*Flux*IBase*Gr*GREF
	float Gr;						//	gear ratio
	float GREF;					//	gear efficient
	uint32_t NPP;				//	pole pairs
	float NDT;					//	NPP/2�ЦD
	float ODG;					//	1/GR
	float NMG;					//	NPP*GR
	float ODN;					//	1/Np
	float filt_a;				// 	filter for speed
	float filt_b;
	float IQF;
	float filt_c;				//	filter for rotor temperature
	float filt_d;
}Motor_BOX;

typedef struct{
	uint16_t raw;	//	raw data
	uint32_t upd;	// 	update flag
	float ps;			//	position sensor angle
	float ps_lst;	//	ps last
	float angle;	//	angle acc value
	float dth;
}Sen_BOX;

/* Flag & Counter */
typedef struct{
	uint32_t com; 	// 	communication
	uint32_t rst;		//	reset
  uint32_t mod;		//	modify
	uint32_t fwr;		//	flash write
	uint32_t cal;		//	calibration
	uint32_t xcal;
	uint32_t swp;		// 	0: no operation 1:current loop sweep 2:velocity loop sweep 3:position loop sweep
	uint32_t cdt;		//	cal data
	uint32_t prcv;	//	parameter_receiver_flag
	uint32_t id;		//	identify para
	uint32_t rdp;		//	read_param_flag
	uint32_t F1K;		//	1KHz flag
	uint32_t can_err;
	
	uint32_t UVcnt;
	uint32_t OVcnt;
	uint32_t OCcnt;
	uint32_t OTcnt;
	uint32_t CTcnt;
	uint32_t tog_cnt;
}FLAG_Type;

extern MC_PARA mp;
extern ESC_INF TMP;//temperory variable
extern Motor_BOX MTR;
extern CTRL_BOX ctrler;
extern Sen_BOX ma;	//	ma702
extern FLAG_Type FFC; // flag fault count
extern float lutTable[256];

#endif
