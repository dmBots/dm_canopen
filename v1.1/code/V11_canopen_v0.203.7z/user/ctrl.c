#include "udefine.h"
#include "stdlib.h"
#include "fsmc.h"
#include "co_app.h"
#include "OD.h"
#include "api_mode.h"
/*
	iu,iv,iw,vbus,temperature rotor & mosfet
*/
#define IU_CHN 0
#define IV_CHN 1
#define IW_CHN 2
#define VB_CHN 3
#define H1_CHN 4
#define H2_CHN 5
#define TS_CHN 6
#define TM_CHN 7
#define Vr_CHN 8
uint16_t ADC_D[9];
uint8_t TmpPnt;



//#define TPTEST
#ifdef TPTEST
uint32_t t_prog;
uint32_t t_max=0;
#endif

struct{
  float Ia;
	float Ib;
	float Ic;
	float Ialp;
	float Ibeta;
	float Idref;
	float Iqref;
	float Id;
	float Iq;
	float we;
	float theta;
}obsv;

CC_PARA IDx_Loop,IQx_Loop;

PI_PARA ID_Loop={ 0.8f,    0.001f,   0.0f, 0.0f,  0.0f,0.0f,  0.0f,  0.0f,  -1.0f,  1.0f}; 
                 //Kp        Ki       e_k   Up     Ui   v1     Out   SatErr   min     max	
PI_PARA IQ_Loop={ 0.8f,    0.001f,   0.0f, 0.0f,  0.0f,0.0f,  0.0f,  0.0f,  -1.0f,  1.0f}; 
                 //Kp        Ki       e_k   Up     Ui   v1     Out   SatErr   min     max	
PI_PARA SPD_Loop={ 0.4f,   0.002f,   0.0f, 0.0f,  0.0f,0.0f,  0.0f,  0.0f,  -1.0f,  1.0f}; 
                 //Kp        Ki       e_k   Up     Ui   v1     Out   SatErr   min     max	
PI_PARA POS_Loop={ 2.0f,   0.000f,   0.0f, 0.0f,  0.0f,0.0f,  0.0f,  0.0f,  -600.0f,  600.0f}; 
                 //Kp        Ki       e_k   Up     Ui   v1     Out   SatErr   min     max	
extern float err_pos;
float pos_ref;
float input_update = 1;
float target_reached;
float pos_setpoint;
float vel_setpoint = 50;
float torque_setpoint;
float input_position = 0.0f;
float pos_meas;
float pos_setpoint_last;
float vdtest=0.0f,vqtest=0.0f;

float torque_ref = 0.3f;

__RAM_FUNC void FOC_LOOP(void)
{
	#ifdef TPTEST
	SysTick->LOAD = 0x00FFFFFF;
	SysTick->VAL=0;
	SysTick->CTRL |= 0x00000001;//enable systick timer
	#endif
//	ctrler.tick++;
	FFC.com++;
	ADC_D[IU_CHN] = CM_ADC1->DR0;
	ADC_D[IV_CHN] = CM_ADC2->DR0;
	ADC_D[IW_CHN] = CM_ADC3->DR0;
	ADC_D[VB_CHN] = CM_ADC1->DR1;
	ADC_D[TS_CHN]	=	CM_ADC2->DR1;
	ADC_D[TM_CHN]	= CM_ADC3->DR1;
	ADC_D[H1_CHN]	=	CM_ADC1->DR2;
	ADC_D[H2_CHN]	= CM_ADC2->DR2;
	ADC_D[Vr_CHN]	= CM_ADC3->DR2;
	
	TmpPnt			=	ADC_D[TS_CHN] >>4;
	ctrler.TMOS	=	TempTable[TmpPnt];
	
	TmpPnt			=	ADC_D[TM_CHN] >>4;
	MTR.T_CEL		=	MTR.T_CEL*MTR.filt_c+MTR.filt_d*TempTable[TmpPnt];
	
	ctrler.V_BUS  = ADC_D[VB_CHN]*V_BUS_GAIN;
	
	ctrler.I_U = (ctrler.I_U_OFF	-	ADC_D[IU_CHN])*0.00048828125f;
	ctrler.I_V = (ctrler.I_V_OFF	-	ADC_D[IV_CHN])*0.00048828125f;

	ctrler.I_U = sat_datf(ctrler.I_U,-1.0f,1.0f);
	ctrler.I_V = sat_datf(ctrler.I_V,-1.0f,1.0f);
	
	Xsens.u = (ADC_D[H1_CHN]-Xsens.u_off);
	Xsens.v = (ADC_D[H2_CHN]-Xsens.v_off)*Xsens.Kv;
	upd_hall_upd(&Xsens);
	
	if(++flag.errtime > 20)
	{
		flag.errtime = 0;
		FFC.F1K = 1;
	}
	
	if(ma.upd)
	{
		ma.upd=0;
		MTR.p_e=ma.ps*MTR.NPP-(uint32_t)(ma.ps*MTR.NDT)*two_pi + MTR.E_OFF;// theta∈[0,2π]
		lim_datf(&MTR.p_e,-pi,pi);
		sincos(MTR.p_e,&ctrler.Sin,&ctrler.Cos);
	}
	
    fsmc_loop();      
	protect();
	api_clear();
	
	/* Uαβ=Udq*e^j(θ) */
	ctrler.Ualph	= ctrler.Cos*IDx_Loop.out - ctrler.Sin*IQx_Loop.out;
	ctrler.Ubeta	= ctrler.Sin*IDx_Loop.out + ctrler.Cos*IQx_Loop.out;
	SVPWM(ctrler.Ualph,ctrler.Ubeta);
	
	CM_ADC1->ISCLRR = 0x01;
	NVIC_ClearPendingIRQ(ADC_IRQn);
	#ifdef TPTEST
	SysTick->CTRL &= 0xFFFEFFFE;//Disable systick timer and clear countflag
	t_prog=0x00FFFFFF-SysTick->VAL;
	if(t_prog>t_max)
		t_max=t_prog;
	#endif
}

__RAM_FUNC void protect(void)
{
	/* Communication lost proctect */
	if(FFC.com>TMP.TIMEOUT&&TMP.TIMEOUT>0) // 1s
	{
		FFC.com=TMP.TIMEOUT;
		FFC.rst = 1;
		ctrler.ERR_STATE=0x0D;//com lost
		OD_RAM.x603F_errorCode = 0x0D;
	}
	
	/* coil protect */
	if(MTR.T_CEL>TMP.OT_Value)
	{
	  FFC.CTcnt++;
		if(FFC.CTcnt>8000)
		{
			ctrler.ERR_STATE = 0x0C;//Coil over tempreture
			OD_RAM.x603F_errorCode = 0x0C;
			FFC.rst = 1;
			FFC.CTcnt = 8000;
		}
	}
	else
	{
	  if(!FFC.rst)
			FFC.CTcnt=0;
	}

	/* MOS protect */
	if(ctrler.TMOS>120.0f)
	{
	  FFC.OTcnt++;
		if(FFC.OTcnt>8000)
		{
			ctrler.ERR_STATE = 0x0B;//MOS over tempreture
			OD_RAM.x603F_errorCode = 0x0B;
			FFC.rst = 1;
			FFC.OTcnt = 8000;
		}
	}
	else
	{
	  if(!FFC.rst)
			FFC.OTcnt=0;
	}
	
	/* Over current protect */
	if(fabsf(ctrler.IQ)>TMP.OC_Value)
	{
	  FFC.OCcnt++;
		if(FFC.OCcnt>5000)
		{
			ctrler.ERR_STATE=0x0A;//over current
			OD_RAM.x603F_errorCode = 0x0A;
			FFC.rst=1;
			FFC.OCcnt = 5000;
		}
	}
	else
	{
	  if(!FFC.rst)
			FFC.OCcnt=0;
	}
	
	/* Under voltage protect*/
	if(ctrler.V_BUS<=TMP.UV_Value)
	{
		FFC.UVcnt++;
		if(FFC.UVcnt>5000)
		{
			ctrler.ERR_STATE=0x09;//under voltage
			OD_RAM.x603F_errorCode = 0x09;
			FFC.rst=1;
			FFC.UVcnt = 5000;
		}
	}
	else
	{
		if(!FFC.rst)
		FFC.UVcnt=0;
	}

	/* Over voltage protect*/
	if(ctrler.V_BUS>TMP.OV_Value)
	{
		FFC.OVcnt++;
		if(FFC.OVcnt>20000)
		{
			FFC.OVcnt = 20000;
			FFC.rst   = 1;
			ctrler.ERR_STATE = 0x08;//over voltage
			OD_RAM.x603F_errorCode = 0x08;
		}
	}
	else
	{
		if(!FFC.rst)
		FFC.OVcnt=0;
	}

	if(ctrler.ERR_STATE >7 && flag.fault == 1)
	{
		MTR.state = REST_MODE;
		cia402axis.state = FAULT_REACTION_ACTIVE;
		MTR.st_change = 1;
	}
}
