#ifndef __CTRL_H_
#define __CTRL_H_

#include "hc32f448.h"

void protect(void);

#endif
