#include "iap.h" 
#include <string.h>

BOOTPARAMETER Boot_Para __attribute__((at(0x0001E000)));//PAGE15
BOOTPARAMETER Boot_Para_tmp; //ram

void boot_parameter_flash_write(void);

void verify_app_version(uint32_t ver)
{
	uint32_t _app;
	_app = ver - 0x30303030;
    if(_app !=  Boot_Para.app)
    {
        loader_parameter_temp();
				Boot_Para_tmp.app = _app;
        boot_parameter_flash_write();
    }
}

void set_loader_flag() //set loader flag
{
    loader_parameter_temp();
    Boot_Para_tmp.bootflag 		= 1; // set boot flag
		Boot_Para_tmp.bootokflag 	= 0; // set boot ok flag
    boot_parameter_flash_write();
}

void reset_loader_flag() //reset loader flag
{
    loader_parameter_temp();//set boot flag//����������־λ
    boot_parameter_flash_write();
}

void set_app_flag() //set app run ok flag
{
    loader_parameter_temp();
    Boot_Para_tmp.bootokflag = 1; // set boot ok flag
    Boot_Para_tmp.bootflag = 0; // reset boot flag
    boot_parameter_flash_write();
}

void reset_app_flag()             // reset run ok flag
{
    loader_parameter_temp();
    Boot_Para_tmp.bootokflag = 0; // reset boot ok flag
    boot_parameter_flash_write();
}


void loader_parameter_temp()
{
    memcpy(&Boot_Para_tmp, &Boot_Para, sizeof(BOOTPARAMETER));
}


__RAM_FUNC void boot_parameter_flash_write(void)
{
	uint32_t *p,*src;
	uint32_t i,cache_tmp;
	
	__disable_irq();
	CM_EFM->FAPRT	=0x0123;
	CM_EFM->FAPRT	=0x3210;
	CM_EFM->KEY1 = 0x01234567;
	CM_EFM->KEY1 = 0xFEDCBA98; // unclock EFM_KEY1
	
	cache_tmp	=	CM_EFM->FRMC&0x00070000;	//	read back CACHE
	CM_EFM->FRMC &= 0xFFF0FFFF;	//	Diable ICACHE,DCACHE,PREFETE
	CM_EFM->FSCLR	=	0x0000003F;	//	CLear the error flag
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
		;//wait until flash is idle
	CM_EFM->FWMC = (CM_EFM->FWMC&0xFFFFFFF8)|4;	//	PEMOD[2:0]=4,Set sector erase mode
	CM_EFM->F0NWPRT = 1<<15;// remove writing protection lock
	Boot_Para.bootflag	=	0;
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
		;//wait until flash is idle
	CM_EFM->FSCLR	=	0x00000010;	//	Clear the OPTEND flag
	
	/* Sequence program. */
	CM_EFM->FWMC = (CM_EFM->FWMC&0xFFFFFFF8)|3;	//	PEMOD[2:0]=3,Set continuously program
	/* program data. */
	p=(uint32_t*)&Boot_Para;
  src=(uint32_t*)&Boot_Para_tmp;
	for(i=0;i<(sizeof(BOOTPARAMETER)/4);i++)
	{
	 *p++	=	*src++;
		while((CM_EFM->FSR&0x00000010)==0)// OPTEND[4]=0,programming is not end
			;//wait until operation is end
		CM_EFM->FSCLR	=	0x00000010;	//	Clear the EOP flag
	}
	
	CM_EFM->FWMC &= 0xFFFFFFF8;//pemod[2:0]=0,read-only mode
	while((CM_EFM->FSR&0x00000100)==0)//RDY[8]=0,FLASH is busy
	CM_EFM->FSCLR	=	0x00000010;	//	Clear the EOP flag
	CM_EFM->F0NWPRT = 0;// writing protection
	/* recover CACHE */
	CM_EFM->FRMC |= cache_tmp;
	/*	EFM LOCK	*/
	CM_EFM->FWMC |= 0x00010000;// lock EFM_KEY1 register
	CM_EFM->FAPRT	=0x3210;
	__enable_irq();
}
