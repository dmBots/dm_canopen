#ifndef __IAP_H__
#define __IAP_H__
  
#include "hc32f448.h"
  
typedef struct  
{
    uint32_t bootflag ;      	//  firmware boot flag
    uint32_t bootokflag ;    	//  firmware run ok flag
    uint32_t bootloader;     	//  bootloader version x.x.x.x
    uint32_t app;            	//  app version x.x.x.x
	uint32_t  disable_swd_flag;	//	4Bytes access 0: enable 1:disable
}BOOTPARAMETER;

extern BOOTPARAMETER Boot_Para;

void verify_app_version(uint32_t ver);
void verify_loader_version(uint8_t *version);
void reset_loader_flag(void);
void set_app_flag(void);
void set_loader_flag(void);
void loader_parameter_temp(void);
void iap_load_app(uint32_t appxaddr);			//	jump to app
void iap_write_appbin(uint32_t appxaddr,uint8_t *appbuf,uint32_t applen);	// write to designated address

#endif
