#include "int.h"
#include "iap.h"
#include "co_app.h"
#include "co_bsp.h"
#include "co_drv.h"
#include "OD.h"

__RAM_FUNC void TIM41_IRQHandler(void)
{
	if((CM_TMR4_1->CCSR&0x0800)==0x0800)// if TIM41 IRQZF[11]=1
			CM_SPI3->DR = 0x0000;
	CM_TMR4_1->CCSR &= 0xF5FF;	//	Clear status flag,IRQZF[11]=IRQPF[9]=0
	NVIC_ClearPendingIRQ(TIM41_IRQn);
}

float lutTable[256];
__RAM_FUNC void DMA2_CH0_IRQHandler(void)
{
	uint8_t index;
	float off_1,off_2,off_interp;
	float d_theta=0.0f;
	if((CM_DMA2->INTSTAT1&0x00000001)	==	1)// if dma2_ch0 transfer complete
	{
		if(MTR.Order==1.0f)
		 ma.raw 		= 16383 - (SPI_DATA[0]>>2);
		else
		 ma.raw   	= SPI_DATA[0]>>2;
		index    		= ma.raw>>6;
		off_1				=	lutTable[index];
		index++;
		off_2				=	lutTable[index];
		off_interp	=	off_1+(off_2-off_1)*(ma.raw*0.015625f-(uint16_t)(ma.raw*0.015625f)); // 1/64
		ma.ps 		= (ma.raw+off_interp)*3.8349519697141e-4f;//2��/2^14,[0,2��]
    lim_datf(&ma.ps,0.0f,two_pi); // ma.ps �� [0,2��]

		d_theta = ma.ps - ma.ps_lst;
		if(d_theta>5.5f)
			{
				d_theta -= two_pi;
				MTR.rev--;
			}
		if(d_theta<-5.5f)
			{
				d_theta += two_pi;
				MTR.rev++;
			}
		MTR.p_r = ma.ps+MTR.rev*two_pi;
		MTR.p_m	= MTR.p_r*MTR.ODG - MTR.M_OFF;
		ma.ps_lst = ma.ps;
		ma.dth = d_theta;
		ma.angle += d_theta;
		ma.upd=1;
		CM_DMA2->DTCTL0 = (CM_DMA2->DTCTL0&0x0000FFFF)|1<<16;
		CM_DMA2->CHEN	=	1;	//	Enable DMA2_CH0
	}
	CM_DMA2->INTCLR1	=	0x000F000F;	// clear BTC,TC flag
	NVIC_ClearPendingIRQ(DMA2_CH0_IRQn);
}

int16_t rcv_len;
uint16_t temp = sizeof(CAL_PKG_DATA);
uint8_t  txtemp[20]={0x00};//'d'+count
void USART1_IRQHandler(void)
{
    if((CM_USART1->SR&0x00000100)	== 0x00000100)//RTOF[8]=1,Receiver timeout
    {
				CM_DMA1->CHENCLR |=	1;	//	Disable DMA1_CH0
        rcv_len					= RCV_LEN - (CM_DMA1->MONDTCTL0>>16);
        CM_DMA1->DTCTL0 = (CM_DMA1->DTCTL0&0x0000FFFF)|RCV_LEN<<16;
				CM_DMA1->DAR0	=	(uint32_t)RXD_BUF;	//	DAR=buf
        if(RXD_BUF[0]==27)     //ESC
        {
            MTR.state = REST_MODE;
						if(ctrler.ERR_STATE == 0x01)
							ctrler.ERR_STATE = 0;// return 0 if back from normal state
            MTR.st_change = 1;
        }
        if((RXD_BUF[0] == 0x58) && (rcv_len == 1))
        {
          __disable_irq();                
          set_loader_flag(); //set loader flag
					Delay_us(100);  
					NVIC_SystemReset();
        }
	 
        if(MTR.state == REST_MODE)
        {
            switch (RXD_BUF[0])
            {
                case 'm':
                    MTR.state = MOTOR_MODE;
					ctrler.ERR_STATE = 0x01;
                    MTR.st_change = 1;
                    break;
                case 's':
                    MTR.state = SETUP_MODE;
                    break;
                case 'z':
										NVIC_DisableIRQ(ADC_IRQn);
										MTR.M_OFF=0.0f;
										MTR.rev	=	MTR.rev-(int32_t)(MTR.rev*MTR.ODG)*MTR.Gr;
										Xsens.rev = 0;
										MTR.M_OFF=(ma.ps+MTR.rev*two_pi)*MTR.ODG;
										MTR.p_m  = 0.0f;				
										Htmp.M_OFF	=	MTR.M_OFF;
										Xsens.x_off = Xsens.raw;
										Htmp.X_OFF	=	Xsens.raw;
										MTR.p_m  = 0.0f;
										__disable_irq();
										Push_ROM((uint32_t*)&Hallm,(uint32_t*)&Htmp,6);
										__enable_irq();
										CM_ADC1->ISCLRR = 0x01;
										CM_ADC2->ISCLRR = 0x01;
										NVIC_ClearPendingIRQ(ADC_IRQn);
										NVIC_EnableIRQ(ADC_IRQn);
                    break;
            }
        }
        else if(MTR.state == SETUP_MODE)
        {
            if(RXD_BUF[0] == 'U') //setup mode
            {
                if(RXD_BUF[1] =='c')
                {
                   FFC.cal=1;
                }
                else if(RXD_BUF[1]=='l')
                    FFC.xcal = 1;
                else if((RXD_BUF[1]=='d') &&(rcv_len == (temp+1)))
                {
                    memcpy(&_cal_data,&RXD_BUF[1],rcv_len);
                    memcpy(&cal_data[15*_cal_data.cnt],_cal_data.data,_cal_data.len*4);
                    txtemp[0] = 'd';
                    txtemp[1] = _cal_data.cnt;
                    USART1_send_buf(txtemp,2); //'d'+count
                    if(_cal_data.cnt == 17) //receive complete,write data to flash
                    {
                        FFC.cdt = 1;
                        cal_data[258] = MTR.Order;
                    }
  
                }
								
                else if((RXD_BUF[1]=='M') &&(rcv_len == (temp+1)))  // outer sensor cal data
                {
                    memcpy(&_cal_data,&RXD_BUF[1],rcv_len);
                    memcpy(&hal_cal_data[30*_cal_data.cnt],_cal_data.data,_cal_data.len*2);
                    txtemp[0] = 'M';
                    txtemp[1] = _cal_data.cnt;
                    USART1_send_buf(txtemp,2); //'d'+count
                    if(_cal_data.cnt == 136) //receive complete,write data to flash
                        FFC.cdt = 2;
                }
								
                else if(RXD_BUF[1]=='e') //identify para
                {
                    if((RXD_BUF[2] == 0xaa) && (rcv_len == 3)) //0x55 + 'e' + 0xaa  upload identified para
                    {
                        txtemp[0] = RXD_BUF[1];
                        memcpy(&txtemp[1],&TMP.Rs, 12);
                        USART1_send_buf(txtemp,13);
                    }
                    if((RXD_BUF[2] == 0x55) && (rcv_len == 3)) //0x55 + 'e' + 0x55  reidentify para & upload
                    {
                        FFC.id = 1;
                    }
                } 
                else if(RXD_BUF[1]=='f') // read version 
                {
                    if((RXD_BUF[2] == 0xaa) && (rcv_len == 3)) //0x55 + 'f' + 0xaa  read version
                    {
                        txtemp[0] = RXD_BUF[1];
                        memcpy(&txtemp[1],&Boot_Para.bootloader , 8);
                        USART1_send_buf(txtemp,9);
                        MTR.state = REST_MODE;
//						OD_RAM.x200B_deiver.motorState = REST_MODE;
                    }
                }
                else if(RXD_BUF[1]=='g') // parameters setting cmd
                {
                    if((RXD_BUF[2] == 0xaa) && (rcv_len == 3))     //0x55 + 'g' + 0xaa   read all paras
                    {
                        FFC.rdp = 1;
                    }
                    else if((RXD_BUF[2] == 0x55) && (rcv_len == 131)) //0x55 + 'g' + 0x55  + data write all motor para
                    {
                        memcpy(&TMP,&RXD_BUF[3],rcv_len-3);
                        FFC.rdp = 2;
                    }
                    else if((RXD_BUF[2] == 0x5a) && (rcv_len == 131)) //0x55 + 'g' + 0x5a  write drive para
                    {
                        memcpy(&TMP,&RXD_BUF[3],rcv_len-3);
                        FFC.rdp = 4;
                    }
                    else if((RXD_BUF[2] == 0x51) && (rcv_len == 131)) //0x55 + 'g' + 0x51  write tuning para
                    {
                        memcpy(&TMP,&RXD_BUF[3],rcv_len-3);
                        FFC.rdp = 6;
                    }
                }                
            }
        }
        CM_DMA1->CHEN	=	1;	//	Enable DMA1_CH0
    }
	CM_TMR0_1->BCONR &= 0xFFFFFFFE; // CSTA[0]=0,STOP timer channel A
	CM_USART1->CR1	|=	0x001B0000;	// Clear RTOF[20],ORE[19],FE[17],PE[16] flag
	NVIC_ClearPendingIRQ(USART1_IRQn);
}
