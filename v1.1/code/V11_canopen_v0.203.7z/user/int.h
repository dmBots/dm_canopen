#ifndef __INT_H
#define __INT_H

#include "udefine.h"

#define KP_MIN 0.0f
#define KP_MAX 500.0f
#define KD_MIN 0.0f
#define KD_MAX 5.0f

extern float mech_off;
extern uint16_t ad_h1,ad_h2;

void TIM61_IRQHandler(void);
void DMA2_CH0_IRQHandler(void);
void CAN_IRQHandler(void);
void USART1_IRQHandler(void);

#endif
