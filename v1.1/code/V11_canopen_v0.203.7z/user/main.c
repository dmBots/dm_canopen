#include "udefine.h"
#include "iap.h"
#include "co_app.h"
#include "OD.h"

#define STR1(R)  #R
#define STR2(R)  STR1(R)

#define V_BW 100.0f

#define TBW 10.0f

#define XVER 5051
#define SVER 3

CAL_PKG_DATA _cal_data;
float  cal_data[256 + 3] = {0};
uint16_t hal_cal_data[4096] = {0};

HALL_Type Hallm	__attribute__((at(0x00038000)));//PAGE 28
HALL_Type Htmp;

uint16_t Hall[4096]	__attribute__((at(0x0003A000)));//PAGE 29
CAL_DATA CALDATA __attribute__((at(0x0003C000)));//PAGE 30
ESC_INF DM __attribute__((at(0x0003E000)));//PAGE 31
ESC_INF TMP;//temperory variable
Motor_BOX MTR;
CTRL_BOX ctrler;
Sen_BOX ma;	//	ma702
Hall_BOX Xsens;
FLAG_Type FFC; // flag fault count

ESO_Type dmc;
MC_PARA mp;//motor control para

uint8_t hw_ver;

void mos_check(void);
void ov_protect(void);

void Init_ESC_para(void);
uint32_t str_to_u32(char *x);
void Load_para(void);
void Modify_para(void);
void Load_cal_data(void);
void send_parameter(uint8_t flag);
void print_inf(void);

uint8_t can_tx[64] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
uint8_t ma_reg[10] = {0x00, 0x00, 0x00, 0x00, 0xC0, 0xFF, 0x1C, 0x00, 0x77, 0x9C};

int main(void)
{
#ifdef BOOT_APP
    SCB->VTOR = 0x00020000;
#endif
    SYS_Init();

    if (Boot_Para.bootokflag != 1)   //set run flag
    {
        set_app_flag();
    }

    verify_app_version(str_to_u32(STR2(XVER)));//verify app version
    __enable_irq();
    Delay_ms(500);
    hw_ver = GPIO_Init();
    USART1_Init(921600);
    ADC12_Init();
    mos_check();
    CRC_Init();
    //	sing();
    MA7xx_Init();
    Load_cal_data(); // load calibration data
    ADC_CAL(&ctrler.I_U_OFF);
    ctrler.V_BUS = ctrler.I_U *V_BUS_GAIN;
    Load_para();

    if (TMP.can_br > CAN_BR_1M)
    {
        TMP.can_br = CAN_BR_1M;
    }

    if (TMP.h_time == 0xFFFFFFFF)
    {
        TMP.h_time = 1000;
    }

    get_cur_pos();
    ov_protect();
    ma.upd = 0;
    ma.angle = 0.0f;

    MTR.state = REST_MODE;
    MTR.st_change = 1;
    canopen_init();
		print_inf();
    PWM_Init();
    cia402_initialize(&cia402axis, &OD_RAM.x6041_statusword, &al_status);
    cia402axis.state = SWITCH_ON_DISABLED;
    pro_mode_init();
	
	Delay_ms(1000);
    /* Set ADC1_EOCA IRQ */
    CM_INTC->INTSEL0	=	INT_SRC_ADC1_EOCA;	// ADC1_EOCA
    NVIC_SetPriority(ADC_IRQn, 0);	//Default Priority for IRQ, Possible values are 0 (high priority) to 15 (low priority)
    NVIC_ClearPendingIRQ(ADC_IRQn);
    NVIC_EnableIRQ(ADC_IRQn);// Set ADC interrupt priority and enable ADC interrupt

    while (1)
    {
        canopen_app();

        if (MTR.st_change == 1)
        {
            switch (MTR.state)
            {
            case REST_MODE:
                //										M4_TMR61->PCONR				 &=	0xFEFFFEFF;	//	Enable CHA,CHB output
                //										M4_TMR62->PCONR				 &=	0xFEFFFEFF;	//	Enable CHA,CHB output
                //										M4_TMR63->PCONR				 &=	0xFEFFFEFF;	//	Enable CHA,CHB output
                MTR.st_change = 0;
                ctrler.Pref = 0.0f;
                ctrler.Vref = 0.0f;
                ctrler.Tref	=	0.0f;
                ctrler.kp		=	0.0f;
                ctrler.kd		=	0.0f;
                printf("\n\r\n\r\n\r");
                printf(" Commands:\n\r");
                Delay_us(10);
                printf(" m - Motor Mode\n\r");
                Delay_us(10);
                printf(" z - Set Zero Position\n\r");
                Delay_us(10);
                printf(" esc - Exit to Menu\n\r");
                Delay_us(10);
//                LED_G_OFF();
                break;

            case MOTOR_MODE:
                MTR.st_change = 0;
                printf("\n\r Entering Motor Mode \n\r");
                //										M4_TMR61->PCONR				 |=	0x01000100;	//	Enable CHA,CHB output
                //										M4_TMR62->PCONR				 |=	0x01000100;	//	Enable CHA,CHB output
                //										M4_TMR63->PCONR				 |=	0x01000100;	//	Enable CHA,CHB output
//                LED_G_ON();
                break;

            default :
                break;
            }
        }

        if (FFC.F1K)
        {
            if (ctrler.ERR_STATE > 7)
            {
                FFC.tog_cnt++;

                if (FFC.tog_cnt > 250)
                {
                    FFC.tog_cnt = 0;
                    LED_R_Tog();
                }
            }

            FFC.F1K = 0;
        }

        if (FFC.can_err == 1)
        {
            printf("CAN Error 1\n\r");
            FFC.can_err = 0;
        }

        if (FFC.can_err == 2)
        {
            printf("CAN Error 2\n\r");
            FFC.can_err = 0;
        }

        if (FFC.fwr)
        {
            __disable_irq();
            Push_ROM((uint32_t *)&DM, (uint32_t *)&TMP, ESC_INF_LEN);
            FFC.fwr = 0;
            CM_ADC1->ISCLRR = 0x01;
            CM_ADC2->ISCLRR = 0x01;
            NVIC_ClearPendingIRQ(ADC_IRQn);
            CM_TMR4_1->CCSR &= 0xF5FF;	//	Clear status flag,IRQZF[11]=IRQPF[9]=0
            NVIC_ClearPendingIRQ(TIM41_IRQn);
            __enable_irq();
        }

        if (FFC.mod)
        {
            Modify_para();
            FFC.mod = 0;
        }

        if (FFC.cal)   // calibration
        {
            order_phase();
            calibration();
            FFC.cal = 0;
            MTR.state = REST_MODE; // return to rest
        }

        if (FFC.cdt)   // receive calibration data
        {
            __disable_irq();

            if (FFC.cdt == 1)
            {
                Push_ROM((uint32_t *)&CALDATA, (uint32_t *)&cal_data, 259);
            }

            if (FFC.cdt == 2)
            {
                Push_ROM((uint32_t *)&Hall, (uint32_t *)&hal_cal_data, 2048);
                Push_ROM((uint32_t *)&Hallm, (uint32_t *)&Htmp, 6);
            }

            FFC.cdt = 0;
            Load_cal_data(); // reload calibration data
            ma.angle = 0.0f;
            CM_ADC1->ISCLRR = 0x01;
            CM_ADC2->ISCLRR = 0x01;
            NVIC_ClearPendingIRQ(ADC_IRQn);
            CM_TMR4_1->CCSR &= 0xF5FF;	//	Clear status flag,IRQZF[11]=IRQPF[9]=0
            NVIC_ClearPendingIRQ(TIM41_IRQn);
            __enable_irq();
            MTR.state = REST_MODE;
        }

        if (FFC.id)
        {
            mp_id();
            FFC.id = 0;
            MTR.state = REST_MODE;
        }

        if (FFC.rdp)
        {
            send_parameter(FFC.rdp);
            FFC.rdp = 0;
            MTR.state = REST_MODE;
        }

        if (FFC.xcal)
        {
            cal_outsens();
            FFC.xcal = 0;
        }
    }//end while(1)
}//end main

void Load_para(void)
{
    float fs = 1000.0f; //1KHz
    float wf = 0.0f;
    float KtB;

    /* Read out ESC para */
    if ((DM.SN == 0xFFFFFFFF) || (DM.sw_ver == 0xFFFFFFFF) || (DM.ESC_ID == 0xFFFFFFFF))
    {
        Init_ESC_para();
        __disable_irq();
        Push_ROM((uint32_t *)&DM, (uint32_t *)&TMP, ESC_INF_LEN);
        __enable_irq();
    }

    /* Load para for ESC */
    TMP  =  DM;
    /* Load para for calibration and identifying*/
    mp.VBUS_GAIN 	= V_BUS_GAIN;
    mp.VB 				= VBase;
    mp.IB 				= IBase;
    mp.Tc 				= Ts;
    mp.VCAL 			= V_CAL;
    mp.INJ_I 			= INJ_Ialpha;
    mp.IQJ 				= IQ_JX;
    mp.JX_F 			= JX_FREQ;
    mp.IVS				=	IQ_VEL_SWEEP;
    mp.IPS				=	IQ_POS_SWEEP;
    mp.kp_rl			=	2.0f;//	default
    mp.lim_ual		=	0.3f;// default
    mp.ki_flux		=	0.5f;//
    mp.vel_set		=	250.0f;
    mp.lim_uq			=	0.8f;
    mp.VBW				=	V_BW;
    mp.IcBW				=	TMP.I_BW;
    mp.IoBW				=	2500.0f;
    mp.npp				=	(float)TMP.POLE;
    mp.rs					=	TMP.Rs;
    mp.ls					=	TMP.Ls;
    mp.flux				=	TMP.Flux;
    mp.inertia		=	TMP.Inertia;
    mp.delta			=	TMP.Deta;
    mp.beta0			=	1000.0f;
    mp.beta1			=	500.0f;
    /* u(k)=a*u(k-1)+b*y(k) */
    wf = 2 * pi *V_BW;
    MTR.filt_a	=	fs / (fs + wf);
    MTR.filt_b	=	1.0f - MTR.filt_a;
    init_ctrler();
    KtB = 1.5f * TMP.POLE *TMP.Flux *IBase;
    //	TMP.KP_ASR 	= 200.5f/KtB*TMP.Inertia;
    SPD_Loop.Kp   =  TMP.KP_ASR;
    SPD_Loop.Ki   =  TMP.KI_ASR;
    POS_Loop.Kp   =  TMP.KP_APR;
    POS_Loop.Ki   =  TMP.KI_APR;

    if (TMP.KT_Value == 0.0f)
    {
        MTR.KT_Base	=	KtB *TMP.Gr *TMP.GREF;
    }
    else
    {
        MTR.KT_Base = TMP.KT_Value *IBase;
    }

    MTR.NPP    	= TMP.POLE;
    MTR.NDT			=	MTR.NPP / two_pi;
    MTR.ODN     = 1.0f / MTR.NPP;
    MTR.ODG			=	1.0f / TMP.Gr;
    MTR.NMG			=	MTR.NPP *TMP.Gr;
    MTR.Gr			=	TMP.Gr;
    ctrler.CTRL_MODE = TMP.cmode;
    //	TMP.MAX_SPD = 0.9f*ctrler.V_BUS*0.57735026918963f/TMP.Flux/TMP.POLE;
    fs = 20000.0f;
    MTR.filt_c	=	fs / (fs + TBW);
    MTR.filt_d	=	1.0f - MTR.filt_c;
    /*Initiate para*/
    FFC.can_err = 0;
    ctrler.tick = 0;
    MTR.spd_mea = 0.0f;
}

void send_parameter(uint8_t flag)
{
    uint8_t temp = 32 * 4;
    uint8_t txtemp[temp + 2];

    if (flag == 1)   //read all parameters
    {
        txtemp[0] = 0x67;
        memcpy(&txtemp[1], &TMP.UV_Value, temp);
        txtemp[temp + 1] = 0xaa;
        USART1_send_buf(txtemp, temp + 2);
    }
    else if (flag == 2)     //write all parameters
    {
        __disable_irq();
        Push_ROM((uint32_t *)&DM, (uint32_t *)&TMP, ESC_INF_LEN);
        __enable_irq();
        txtemp[0] = 0x55;
        txtemp[1] = 'g';
        txtemp[2] = 0x55;
        USART1_send_buf(txtemp, 3); //0x55 +'g'+ 0x55
        __disable_irq();
        Delay_us(100);
        NVIC_SystemReset();
    }
    else if (flag == 6)     //modify controlling data
    {
        txtemp[0] = 0x55;
        txtemp[1] = 'g';
        txtemp[2] = 0x51;
        mp.IcBW = TMP.I_BW;
        init_ctrler();
        SPD_Loop.Kp = TMP.KP_ASR;
        SPD_Loop.Ki = TMP.KI_ASR;
        POS_Loop.Kp = TMP.KP_APR;
        POS_Loop.Ki = TMP.KI_APR;
        USART1_send_buf(txtemp, 3); //0x55 +'g'+ 0x51
    }
}

void Load_cal_data(void)  //loading calibration data
{
    for (uint16_t i = 0; i < 256; i++)
    {
        lutTable[i] = CALDATA.lut[i];

        if (isnan(lutTable[i]) == 1)
        {
            lutTable[i]	=	0.0f;
        }
    }

    MTR.E_OFF = CALDATA.e_offset;

    if (isnan(MTR.E_OFF) == 1)
    {
        MTR.E_OFF	=	0.0f;
    }

    MTR.Order = CALDATA.dir;

    if (isnan(MTR.Order) == 1)
    {
        MTR.Order	=	1.0f;    // 1:CW 2:CCW
    }

    Htmp = Hallm;

    if (isnan(Hallm.M_OFF))
    {
        Htmp.M_OFF = 0.0f;
    }

    if (isnan(Hallm.X_OFF))
    {
        Htmp.X_OFF = 0.0f;
    }

    MTR.M_OFF = Htmp.M_OFF;
    Xsens.x_off = Htmp.X_OFF;
    Xsens.u_off = Hallm.hoff_u;
    Xsens.v_off = Hallm.hoff_v;
    Xsens.Kv    = Hallm.Kv;
    sincos(Hallm.PH_V, &Xsens.sin, &Xsens.cos);
    memcpy((uint32_t *)&hal_cal_data, (uint32_t *)&Hall, 8192);
}

uint32_t str_to_u32(char *x)
{
    return ((*x) | (*(x + 1)) << 8 | (*(x + 2)) << 16 | (*(x + 3)) << 24);
}

void Init_ESC_para(void)
{
    TMP.UV_Value  =  15.0f;
    TMP.KT_Value  =  0.0f;
    TMP.OT_Value  =  100.0f;
    TMP.OC_Value  =  0.80f;
    TMP.ACC       =  2000.0f;
    TMP.DEC       =  2000.0f;
    TMP.MAX_SPD   =  600.0f;
    TMP.I_BW      =  1000.0f;
    TMP.KP_ASR    =  0.00372f;
    TMP.KI_ASR    =  0.002f;
    TMP.KP_APR    =  54.0f;
    TMP.KI_APR    =  0.0f;
    TMP.MST_ID    =  0;
    TMP.ESC_ID    =  1;
    TMP.TIMEOUT   =  0;
    TMP.cmode     =  1;//mit mode
    TMP.Damp      =  0.0f;
    TMP.Inertia   =  1.8e-5f;
    TMP.hw_ver    =  0x56303033; 	//V003
    TMP.sw_ver    =  0x00000000;
    TMP.SN        =  0x54303035;	//T005,dm technology
    TMP.POLE      =  14;
    TMP.Rs  	  =  0.85f;
    TMP.Ls        =  3.45e-4f;
    TMP.Flux      =  0.0045f;
    TMP.Gr        =  10.0f;
    TMP.PMAX			=	 12.5f;
    TMP.VMAX			=	 30.0f;
    TMP.TMAX			=	 10.0f;
    TMP.OV_Value  =  32.0f;
    TMP.GREF			=	 1.0f;
    TMP.Deta		  =  4.0f;
    TMP.can_br		  =  1000;
    TMP.h_time		  =  1000;
}

void Modify_para(void)
{
    ;
}

void ov_protect(void)
{
    if (ctrler.V_BUS > TMP.OV_Value)   //Over-Voltage protection
    {
        USART1_Init(921600);

        while (1)
        {
            LED_G_ON();
            Delay_ms(250);
            printf("Over Voltage!!!\r\n");
        }
    }
}

void print_inf(void)
{
	float can_baud;
	uint32_t brp,seg1,seg2;
	
	brp=((CM_MCAN1->NBTP>>16)&0x00FF)+1;
	seg1=((CM_MCAN1->NBTP>>8)&0x00FF)+1;
	seg2=((CM_MCAN1->NBTP)&0x000000FF)+1;
	can_baud=8.0e4f/brp/(seg1+seg2+1);
	
	printf("DMBOT Motor Driver");

	switch (hw_ver)
	{
	case 0:
			printf("--V2.0");
			break;

	case 1:
			printf("--V3.0");
			break;

	case 2:
			printf("--V4.0");
			break;

	case 3:
			printf("--V1.0");
			break;

	default:
			break;
	}

	printf("\n\r Debug Info:\n\r");
	printf("Firmware Version: %d\r\n", XVER);
	printf("Sub Version: %03d\r\n", SVER);
	printf("Imax: %f\r\n", IBase);
	printf(" I_U Offset:     %.4f\r\n", ctrler.I_U_OFF);
	printf(" I_V Offset:     %.4f\r\n", ctrler.I_V_OFF);
	printf(" I_W Offset:     %.4f\r\n", ctrler.I_W_OFF);
	printf(" Position Sensor Electrical Offset:   %.4f\n\r", MTR.E_OFF);
	printf(" Mechanical Offset:   %.4f\n\r", MTR.M_OFF);
	printf(" Output Position:  %.4f\n\r", MTR.p_m);
	printf(" CAN ID:  %d\n\r", TMP.ESC_ID);
	printf(" MASTER ID:  %d\n\r", TMP.MST_ID);
	if(can_baud<1000.0f)
		printf(" CAN Baud: %dKbps\n\r", (uint32_t)(can_baud));
	else
		printf(" CAN Baud: %dMbps\n\r", (uint32_t)(can_baud*0.001f));

	printf("\n\r Motor Info:\n\r");
	printf(" Rs  = %.4f m��\n\r", TMP.Rs * 1000.0f);
	printf(" Ls  = %.4f ��H\n\r", TMP.Ls * 1000000.0f);
	printf(" ��f = %.4f Wb\n\r", TMP.Flux);
	printf("V_BUS=%.4f\r\n", ctrler.V_BUS);
	printf("\n\r Control Mode : \r\n");

	if (ctrler.CTRL_MODE == 1)
	{
			printf("1:MIT Mode <----\n\r");
			printf("2:position-speed cascade Mode\n\r");
			printf("3:speed Mode\n\r");
	}

	if (ctrler.CTRL_MODE == 2)
	{
			printf("1:MIT Mode\n\r");
			printf("2:position-speed cascade Mode <----\n\r");
			printf("3:speed Mode\n\r");
	}

	if (ctrler.CTRL_MODE == 3)
	{
			printf("1:MIT Mode\n\r");
			printf("2:position-speed cascade Mode\n\r");
			printf("3:speed Mode <----\n\r");
	}
}
