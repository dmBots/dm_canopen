#include "sens.h"
#include <stdlib.h>

__RAM_FUNC void upd_hall_upd(Hall_BOX* t)
{
	float xd,xq;
	float angle,off_1;
	int xraw;
	xq = t->v	-	t->u*t->cos;    	// B*sin(theta)*sin(f_v) ?
  xd = t->u*t->sin;    				 	// B*cos(theta)*sin(f_v) ?
	angle	 = atan2f(xq,xd);
	xraw = (int)(angle*651.8986469f+2048); //raw=[0,4095]
	if(xraw<0) 		xraw += 4096;
	if(xraw>4095) xraw -= 4096;
	off_1 = hal_cal_data[xraw];
	t->raw = (off_1-2048)*0.0015339808f;
	if((t->raw - t->lst)>5.5f)
		t->rev--;
	if((t->raw - t->lst)<-5.5)
		t->rev++;
	t->lst = t->raw;
	t->out = t->raw + t->rev*two_pi - t->x_off;
}

void cal_obsv(void)
{
	uint32_t i,j;
	uint32_t n=4096*MTR.Gr;
	uint32_t n2=20;
	float delta=two_pi*MTR.NPP*MTR.Gr/(n*n2);
	float fake_angle,sin_angle,cos_angle;
	float ualp,ubet;
	float udd;
	float uqq;
	double theta_ref=0.0f;
	float error_angle;
	uint16_t ad_hallu,ad_hallv;
	float hall_u,hall_v,hall_d,hall_q;
	#pragma pack(1)
	 struct{
		uint8_t sof;//0x68
		float ref;
		float fbk;
		float err;
		uint16_t ad_h1;
		uint16_t ad_h2;
		uint32_t crc;
	}cal_dat;
	#pragma pack()
	
		udd = mp.VCAL;
    uqq = 0.0f;
		for(i = 0; i<20000; i++) // align rotor
		{
      ualp = udd;
			ubet = uqq;
			SVPWM(ualp,ubet);
      Delay_us(100);
    }
		
    /*   rotate forwards   */
    for(i = 0; i<n; i++)
    {
        for(j = 0; j<n2; j++)
        {   
            while((CM_ADC1->ISR&0x01)==0)
                ;// wait until ADC1 conversions complete
            ad_hallu = CM_ADC1->DR2;//HS1
            ad_hallv = CM_ADC2->DR2;//HS2
            
            hall_u = (ad_hallu-Xsens.u_off);
            hall_v = (ad_hallv-Xsens.v_off)*Xsens.Kv;
            hall_q = hall_v	-	hall_u*Xsens.cos;    // B*sin(theta)*sin(��_v)
            hall_d = hall_u*Xsens.sin;    				 // B*cos(theta)*sin(��_v)
            
            theta_ref += delta; // theta_ref��[0,2��]*POLE
            fake_angle = theta_ref-(uint32_t)(theta_ref*0.159154943092f)*two_pi; // 1/2��=0.1591549
            lim_datf(&fake_angle,-pi,pi);// fake_angle��[-��,��]
            sincos(fake_angle,&sin_angle,&cos_angle);
            /* U����=Udq*e^j(��) */
            ualp  = cos_angle*udd - sin_angle*uqq;
            ubet  = sin_angle*udd + cos_angle*uqq;
            SVPWM(ualp,ubet);
        }
				
        cal_dat.sof	= 'H';
        cal_dat.ref	= (float)(theta_ref/(MTR.NPP*MTR.Gr));
        cal_dat.fbk = atan2f(hall_q,hall_d);
        
        error_angle = cal_dat.ref - cal_dat.fbk;// rad
        if(error_angle>pi) error_angle -= two_pi;
        else if(error_angle<-pi) error_angle += two_pi;
        cal_dat.err = error_angle;
        cal_dat.ad_h1	= ad_hallu;
        cal_dat.ad_h2	= ad_hallv;
        cal_dat.crc	=	CRC32_Get((uint8_t*)&cal_dat,17);
        USART1_send_buf((uint8_t*)&cal_dat,21);
		}
		
    /* U����=Udq*e^j(��) */
    SVPWM(0.0f,0.0f);// reset output
}

void cal_outsens(void)
{
	uint32_t j=0;
	uint16_t ad_hallu,ad_hallv;

	float theta_stt,theta_end;
	float ddtheta;

	float fake_angle=0.0f,sin_angle,cos_angle;
	
	uint16_t hallu_max=0,hallu_min=4096;
	uint16_t hallv_max=0,hallv_min=4096;
	float mag_u,mag_v;
	float phz_u_up=0.0f,phz_v_up=0.0f;
	float phz_u_dn=0.0f,phz_v_dn=0.0f;
	float delta_up,delta_dn;
	float phz;
	
	float ualp,ubet;
	
#pragma pack(1)
struct{
            uint8_t sof;//0x68
            float ref;
            float fbk;
            float err;
            uint16_t ad_h1;
            uint16_t ad_h2;
            uint32_t crc;
}cal_dat;
#pragma pack()
	
	NVIC_DisableIRQ(ADC_IRQn);
	while((CM_ADC1->ISR&0x01)==0)
		;// wait until ADC1 conversions complete		
	ad_hallu = CM_ADC1->DR2;//HS1
	ad_hallv = CM_ADC2->DR2;//HS2
	theta_stt = MTR.p_m;
	theta_end = theta_stt+two_pi;
	
	do
	{
		while((CM_ADC1->ISR&0x01)==0)
			;// wait until ADC1 conversions complete
		ad_hallu = CM_ADC1->DR2;//HS1
		ad_hallv = CM_ADC2->DR2;//HS2
		
		if(ad_hallu>hallu_max)
		{
			hallu_max=ad_hallu;
			phz_u_up = MTR.p_m;
		}
		if(ad_hallu<hallu_min)
		{
			hallu_min=ad_hallu;
			phz_u_dn = MTR.p_m;
		}

		if(ad_hallv>hallv_max)
		{
			hallv_max=ad_hallv;
			phz_v_up = MTR.p_m;
		}
		if(ad_hallv<hallv_min)
		{
			hallv_min=ad_hallv;
			phz_v_dn = MTR.p_m;
		}
		
		if(ma.upd)
		{
			ma.upd=0;
			fake_angle = ma.ps*MTR.NPP-(uint32_t)(ma.ps*MTR.NDT)*two_pi + MTR.E_OFF;// theta[0,2pi]
			lim_datf(&fake_angle,-pi,pi);
			sincos(fake_angle,&sin_angle,&cos_angle);
		}
		
    j++;
	 if(j==20)
	 {
		j=0;
		cal_dat.sof	= 'h';
		cal_dat.ref	= 0.0f;
		cal_dat.fbk = 0.0f;
		cal_dat.err = 0.0f;
		cal_dat.ad_h1	= ad_hallu;
		cal_dat.ad_h2	= ad_hallv;
		cal_dat.crc	=	CRC32_Get((uint8_t*)&cal_dat,17);
		USART1_send_buf((uint8_t*)&cal_dat,21);
	 }
	 
		ddtheta = fabsf(MTR.p_m - theta_end);
	 
	 	 	/* U����=Udq*e^j(��) */
		ID_Loop.out = 0.0f;
		IQ_Loop.out = 0.2f;
		ualp  = cos_angle*ID_Loop.out - sin_angle*IQ_Loop.out;
		ubet  = sin_angle*ID_Loop.out + cos_angle*IQ_Loop.out;
		SVPWM(ualp,ubet);
	 
		CM_ADC1->ISCLRR = 0x01;
		CM_ADC2->ISCLRR = 0x01;
		CM_ADC3->ISCLRR = 0x01;
	}while(ddtheta>0.001f);//end cal!=1
	
		Xsens.u_off=(hallu_max+hallu_min)*0.5f;
		Xsens.v_off=(hallv_max+hallv_min)*0.5f;	
		mag_u = hallu_max - hallu_min;
		mag_v = hallv_max - hallv_min;
	
		delta_up = phz_v_up - phz_u_up;
		if(delta_up>pi)
			delta_up -= two_pi;
		else if(delta_up<-pi)
			delta_up += two_pi;
		
		delta_dn = phz_v_dn - phz_u_dn;
		if(delta_dn>pi)
			delta_dn -= two_pi;
		else if(delta_dn<-pi)
			delta_dn += two_pi;
		
		phz  = (delta_up + delta_dn)*0.5f;
		sincos(phz,&Xsens.sin,&Xsens.cos);
		Xsens.Kv = mag_u/mag_v;
		
		Htmp.hoff_u = Xsens.u_off;
		Htmp.hoff_v = Xsens.v_off;
		Htmp.Kv			=	Xsens.Kv;
		Htmp.PH_V   = phz;
		
		cal_dat.sof	= 'J';
		cal_dat.ref	= 0.0f;
		cal_dat.fbk = 0.0f;
		cal_dat.err = 0.0f;
		cal_dat.ad_h1	= (uint16_t)MTR.NPP;
		cal_dat.ad_h2	= (uint16_t)MTR.Gr;
		cal_dat.crc	=	CRC32_Get((uint8_t*)&cal_dat,17);
		USART1_send_buf((uint8_t*)&cal_dat,21);
		Delay_ms(1);
	
		cal_obsv();
	
		cal_dat.sof	= 0x5A;// 'h'
		cal_dat.ref	= 0.0f;
		cal_dat.fbk = 0.0f;
		cal_dat.err = 0.0f;
		cal_dat.ad_h1	= 0xFFFF;
		cal_dat.ad_h2	= 0xFFFF;
		cal_dat.crc	=	CRC32_Get((uint8_t*)&cal_dat,17);
		USART1_send_buf((uint8_t*)&cal_dat,21);
		Delay_ms(1);
		printf("u=%.4f v=%.4f  w=%.4f c=%.4f\r\n",Xsens.u_off,Xsens.v_off,Htmp.PH_V,Xsens.Kv);
		CM_ADC1->ISCLRR = 0x01;
		CM_ADC2->ISCLRR = 0x01;
		CM_ADC3->ISCLRR = 0x01;
		NVIC_ClearPendingIRQ(ADC_IRQn);
		NVIC_EnableIRQ(ADC_IRQn);
}

void get_cur_pos(void)
{
	uint16_t i;
	float rev_f;
	int rev_n;
	float sum_hu=0.0f,sum_hv=0.0f;
	
	Delay_ms(5);
	Xsens.rev = 0;
	
	for(i=0;i<1000;i++)
	{
		CM_ADC1->STR = 1;	//	ADC1 start of conversion
		CM_ADC2->STR = 1;	//	ADC2 start of conversion
		CM_ADC3->STR = 1;	//	ADC3 start of conversion
		CM_SPI3->DR = 0x0000;
		Delay_us(100);
		while((CM_ADC1->ISR&0x01)==0)
				;// wait until ADC1 conversions complete
		sum_hu	+=	(float)CM_ADC1->DR2;
		while((CM_ADC2->ISR&0x01)==0)
				;// wait until ADC1 conversions complete
		sum_hv	+=	(float)CM_ADC2->DR2;
		
	CM_ADC1->ISCLRR = 0x01;
	CM_ADC2->ISCLRR = 0x01;
	CM_ADC3->ISCLRR = 0x01;
	}

	Xsens.u = (sum_hu*0.001f-Xsens.u_off);
	Xsens.v = (sum_hv*0.001f-Xsens.v_off)*Xsens.Kv;
	upd_hall_upd(&Xsens);

	if(Xsens.out>pi)
	{
		Xsens.out -= two_pi;
		Xsens.rev--;
	}
	if(Xsens.out<-pi)
	{
		Xsens.out += two_pi;
		Xsens.rev++;
	}
	
	rev_f = (MTR.Gr*(Xsens.out+MTR.M_OFF) - ma.ps)/two_pi;
	if(rev_f>0.0f)
		rev_n = (int)(rev_f+0.5f);
	else
		rev_n =(int)(rev_f-0.5f);
	MTR.rev = rev_n;
	MTR.p_m = (ma.ps + rev_n*two_pi)*MTR.ODG - MTR.M_OFF;
	
	CM_PWC->FCG0PC = 0xA5A50001;	//	ENABLE_FCG0_REG_WRITE
	CM_PWC->FCG0 &= (~(1<<17));	//	Enable AOS Clock
	CM_PWC->FCG0PC = 0xA5A50000;	//	DISABLE_FCG0_REG_WRITE
	/* Select EVT_AOS_STRG as ADC1 sequence A trigger source. */
	CM_AOS->ADC1_TRGSEL0	=	EVT_SRC_TMR4_1_SCMP0;
	/*
		TRGENA[7]=1,Enable SeqA trigger.
		TRGSELA[1:0]=1,internal trig source 0
	*/
	CM_ADC1->TRGSR = 1<<7|1;

	/*
		SYNCDLY[15:8]=0,no delay
		SYNCMD[6:4]=011,SYNC ADC1,2&3
	*/
	CM_ADC1->SYNCCR = 0<<8|3<<4;
	CM_ADC1->SYNCCR |= 1;//SYNCEN=1,SYNC is active
	
	CM_ADC1->ICR	=	0x01;	// Enable EOCA(End Of Conversion) interrupts default.
}
