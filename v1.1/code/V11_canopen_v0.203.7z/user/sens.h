#ifndef __SENS_H
#define __SENS_H

#include "udefine.h"

typedef struct{
    float u;			//	hall u
    float u_off;	//	u offset
    float v;			//	hall v
    float v_off;	//	v offset
    float d;	//	hall d
    float q;	//	hall q
    float Kv;	//	compensation gain
    float sin;
    float cos;
		float raw;
		float x_off;
    float out;
		float lst;
	  int   rev;
}Hall_BOX;

typedef struct{
    float hoff_u;
    float hoff_v;
    float Kv;
    float PH_V;
    float X_OFF;
    float M_OFF;
}HALL_Type;

extern Hall_BOX Xsens;
extern HALL_Type Hallm;
extern HALL_Type Htmp;

void upd_hall_upd(Hall_BOX* t);
void cal_outsens(void);
void get_cur_pos(void);

#endif
