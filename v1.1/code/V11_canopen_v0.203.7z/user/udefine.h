#ifndef __udefine_H_
#define __udefine_H_

#include "hc32f448.h"
#include "bsp.h"
#include "mc.h"
#include "iap.h"
#include "stdio.h"
#include "string.h"
#include "sens.h"
#include "ctrl.h"
#include "foc_ctrl.h"
#include "trapTraj.h"
#include "cia402device.h"
#include "pro_mode.h"
#include "util.h"
#include "api_com.h"

#define CAN_BAUD CAN_BR_1M


#define REST_MODE 0
#define MOTOR_MODE 2
#define SETUP_MODE 4

/* 3.3/4096*(20+2)/2 */
#define V_BUS_GAIN 0.0088623046875f

// Define the base quantites
#define VBase    40.01037f   		// Base peak phase voltage (volt)
#define IBase    10.261194f  		// Base peak phase current (amp)
#define Ts       0.00005f

#define V_CAL 0.20f

#define INJ_Ialpha 	5.0f
#define IQ_JX 			1.0f
#define JX_FREQ     2.0f
#define IQ_VEL_SWEEP  0.1f
#define IQ_POS_SWEEP  1.0f

extern uint16_t hal_cal_data[4096];
extern float lutTable[256];

void FOC_LOOP(void);

#endif
